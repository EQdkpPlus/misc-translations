<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:49
//File: language/french/lang_install.php
//Source-Language: english

$lang = array( 
	"page_title" => 'Installation d\'EQDKP-PLUS %s',
	"back" => 'Sauvegarder et revenir',
	"continue" => 'Continuer',
	"language" => 'Langue',
	"inst_finish" => 'Terminer l\'installation',
	"error" => 'Erreur',
	"warning" => 'Avertissement',
	"success" => 'Bravo !',
	"yes" => 'Oui',
	"no" => 'Non',
	"retry" => 'Réessayer',
	"skip" => 'Ignorer',
	"step_order_error" => 'Step-Order error: Step not found. Please ensure that all files are uploaded correctly. For further information please visit our forums at <a href="http://eqdkp-plus.eu/forum">http://eqdkp-plus.eu/forum</a>.',
	"licence" => 'Accord de licence ',
	"php_check" => 'Vérification de Pré-installation',
	"ftp_access" => 'Paramètres FTP',
	"encryptionkey" => 'Clef de chiffrement',
	"data_folder" => 'Dossier des données',
	"db_access" => 'Accès à la base de données',
	"inst_settings" => 'Paramètres',
	"admin_user" => 'Compte administrateur',
	"end" => 'Terminer l\'installation',
	"welcome" => 'Bienvenue dans l\'outil d\'installation d\'EQdkp Plus. Nous avons beaucoup travaillé afin que cette étape soit la plus simple et la plus rapide possible. Pour commencer, veuillez accepter notre licence d\'utilisation en cliquant sur le bouton \'Accepter et commencer l\'installation\' ci-dessous.',
	"accept" => 'Accepter et commencer l\'installation',
	"license_text" => '<b>EQdkp Plus is published under AGPL v3.0 license.</b><br /><br /> The full license text can be found at <a href="http://opensource.org/licenses/AGPL-3.0" target="_blank">http://opensource.org/licenses/AGPL-3.0</a>.<br /><br />
	This is a summary of the most important terms of the AGPL v3.0. There is no claim to completeness and correctness.<br /><br />
	<h3><strong>You are permitted:</strong></h3>
<ul>
<li>to use this software for commercial use</li>
<li>to distribute this software</li>
<li>to modify this software</li>
</ul>
<h3><strong>You are required:</strong></h3>
<ul>
<li>to disclose the sourcecode of your complete application that uses EQdkp Plus, when you distribute your application</li>
<li>to disclose the sourcecode of your complete application that uses EQdkp Plus, if you don\'t distribute it, but users are using the software via network ("Hosting", "SaaS")</li>
<li>to remain the visible and unvisible Copyright Notices of this Project and to include a copy of the AGPL License at your application</li>
<li>to indicate significant changes made to the code</li>
</ul>
<h3><strong>It\'s forbidden:</strong></h3>
<ul>
<li>to held the author(s) of this software liable for any damages, the software is provided without warranty.</li>
<li>to license your application under another license than the AGPL</li>
</ul>',
	"table_pcheck_name" => 'Nom',
	"table_pcheck_required" => 'Requis',
	"table_pcheck_installed" => 'Courant',
	"table_pcheck_rec" => 'Recommandé',
	"module_php" => 'Version PHP',
	"module_mysql" => 'Base de données MySQL',
	"module_zLib" => 'Module PHP zLib',
	"module_safemode" => 'Mode de sécurité de PHP',
	"module_curl" => 'Module PHP cURL',
	"module_fopen" => 'Fonction PHP fopen',
	"module_soap" => 'Module PHP SOAP',
	"module_autoload" => 'Fonction PHP spl_autoload_register',
	"module_hash" => 'Fonction PHP hash',
	"module_memory" => 'limite de mémoire de PHP',
	"module_json" => 'Module PHP JSON',
	"module_gd" => 'Module d\'image GD',
	"module_pathinfo" => 'Support de PathInfo',
	"module_xml" => 'Module XML de PHP',
	"safemode_warning" => '<strong>WARNING</strong><br/>Because the PHP Safe mode is active, you have to use the FTP mode in the next Step in order to use EQdkp Plus!',
	"phpcheck_success" => 'Les exigences minimales pour l\'installation d\'EQDKP-Plus sont satisfaites. L\'installation peut continuer.',
	"phpcheck_failed" => 'The minimum requirements for the installation of EQDKP-Plus are not met.<br />A selection of suitable hosting companies can be found on our <a href="http://eqdkp-plus.eu" target="_blank">website</a>',
	"do_match_opt_failed" => 'Certaines des exigences recommandées ne sont pas remplies. EQDKP-Plus fonctionnera cependant sur ce système mais certaines fonctionnalités pourraient ne pas être disponibles.',
	"ftphost" => 'Hôte FTP',
	"ftpport" => 'Port FTP',
	"ftpuser" => 'Nom d\'utilisateur FTP',
	"ftppass" => 'Mot de passe FTP',
	"ftproot" => 'Repertoire de base FTP',
	"ftproot_sub" => '(Chemin vers le répertoire racine de l\'utilisateur FTP)',
	"useftp" => 'Gérer les fichiers en mode FTP',
	"useftp_sub" => '(Modifiable ultérieurement en éditant le fichier config.php)',
	"safemode_ftpmustbeon" => 'Le mode de sécurité PHP étant actif, vous devez renseigner les détails FTP pour continuer l\'installation.',
	"ftp_connectionerror" => 'La connexion FTP ne peut pas être établie. Merci de vérifier le nom d\'Hôte FTP et le port.',
	"ftp_loginerror" => 'L\'authentification FTP a échoué. Merci de vérifier votre n\'om d\'utilisateur et votre mot de passe FTP.',
	"plain_config_nofile" => 'The file <b>config.php</b> is not available and automatic creation failed. <br />Please create a blank text file with the name <b>config.php</b> and set the permissions with chmod 777',
	"plain_config_nwrite" => 'The <b>config.php</b> file is not writeable. <br /> Please set the correct permissions. <b>chmod 0777 config.php</b>.',
	"plain_dataf_na" => 'The folder <b>./data/</b> is not available.<br /> Please create this folder. <b>mkdir data</​​b>.',
	"plain_dataf_nwrite" => 'The folder <b>./data/</b> is not writeable.<br /> Please set the correct permissions. <b>chmod -R 0777 data</​​b>.',
	"ftp_datawriteerror" => 'Imposible de créer des fichiers dans le répertoire Data. Le chemin d\'accès vers la racine du FTP est-il correct ?',
	"ftp_info" => 'Pour améliorer la sécurité et la fonctionnalité, vous pouvez autoriser un compte ftp de votre choix à interagir sur les fichiers de votre serveur. Ceci évite l\'utilisation d\'autorisations trop ouvertes sur le serveur et peut s\'avérer nécessaire sur certaines configurations d\'hébergement. Pour utiliser cette fonctionnalité, indiquez un utilisateur ftp disposant des autorisations d\'accès à votre installation et activez le \'Mode FTP en cochant la case prévue. Si vous n\'utilisez pas le mode FTP cliquez simplement Continuer sur cette page.',
	"ftp_tmpinstallwriteerror" => 'The folder <b>./data/97384261b8bbf966df16e5ad509922db/tmp/</b> is not writable.<br />To write the config-file, CHMOD 777 is required. This folder will be deleted after the installation process.',
	"ftp_tmpwriteerror" => 'The folder <b>./data/%s/tmp/</b> is not writable.<br />Using FTP-Mode requires CHMOD 777 for this folder. This is the only folder needing writing permissions.',
	"dbtype" => 'Type de base de données',
	"dbhost" => 'Hôte de base de données',
	"dbname" => 'Nom de base de données',
	"dbuser" => 'Nom d\'utilisateur de base de données',
	"dbpass" => 'Mot de passe de base de données',
	"table_prefix" => 'Préfixe pour les tables EQDKP-Plus',
	"test_db" => 'Tester la base de données',
	"prefix_error" => 'Aucun préfixe valide de base de données détecté ! Merci d\'en saisir un.',
	"INST_ERR_PREFIX" => 'Une installation utilisant ce préfixe existe déjà. Supprimez toutes les tables ayant ce préfixe puis recommencez cette étape après avoir utilisé le bouton "Retour". Vous pouvez également choisir un autre préfixe si vous souhaitez installer plusieurs jeux de données dans une même base de données.',
	"INST_ERR_PREFIX_INVALID" => 'Le préfixe de table que vous avez indiqué est incorrect pour votre base de données. Merci d\'en essayer un autre en supprimant des caractères comme trait d\'union, apostrophe, slash ou anti-slash.',
	"dbcheck_success" => 'La base de données a bien été vérifiée. L\'installation peut continuer.',
	"encryptkey_info" => 'La clé de chiffrement permet de crypter les données sensibles de la base de données telles que les adresses e-mail de vos utilisateurs. Sans cette clé, vos données resteront donc codées et sécurisées si votre base de données était compromise. Il est donc primordial d\'utiliser une clé sûre et d\'en conserver une copie car, si vous la perdez ou que vous l\'oubliez, personne ne pourra jamais la retrouver.',
	"encryptkey" => 'Clé de chiffrement',
	"encryptkey_help" => '(min. 6 caractères de long)',
	"encryptkey_repeat" => 'Confirmer la clé de chiffrement',
	"encryptkey_no_match" => 'La clé de chiffrement ne correspond pas',
	"encryptkey_too_short" => 'La clé de chiffrement est trop courte. 6 caractères de long minimum.',
	"inst_db" => 'Installer la base de données',
	"lang_config" => 'Paramètres de langue',
	"default_lang" => 'Langue par défaut',
	"default_locale" => 'Emplacement par défaut',
	"game_config" => 'Paramètres du jeu',
	"default_game" => 'Jeu par défaut',
	"server_config" => 'Paramètres du serveur',
	"server_path" => 'Chemin d\'accès des Scripts',
	"grp_guest" => 'Invités',
	"grp_super_admins" => 'Super administrateurs',
	"grp_admins" => 'administrateurs',
	"grp_officers" => 'officiers',
	"grp_writers" => 'Rédacteurs',
	"grp_member" => 'Membres',
	"grp_guest_desc" => 'Les Visiteurs sont des membres non enregistrés',
	"grp_super_admins_desc" => 'Les Super administrateurs ont tous les droits',
	"grp_admins_desc" => 'Les Administrateurs n\'ont pas tous les droits d\'administration',
	"grp_officers_desc" => 'Les Officiers peuvent gérer les raids',
	"grp_writers_desc" => 'Les Rédacteurs peuvent écrire et gérer les news',
	"grp_member_desc" => 'membre',
	"game_info" => 'D\'autres jeux pourront être pris en charge après l\'installation en utilisant la gestion des extensions pour les télécharger.',
	"timezone" => 'Fuseau horaire du serveur',
	"startday" => 'Premier jour de la semaine',
	"sunday" => 'Dimanche',
	"monday" => 'Lundi',
	"time_format" => 'H:i',
	"date_long_format" => 'j. F Y',
	"date_short_format" => 'd/m/y',
	"style_jsdate_nrml" => 'DD/MM/YYYY',
	"style_jsdate_short" => 'D.M',
	"style_jstime" => 'HH:mm',
	"welcome_news_title" => 'Bienvenue sur EQDKP-PLUS',
	"welcome_news" => '<p>The installation of your EQdkp Plus was completed successfully - you can now set it up according to your wishes.</p>
<p>You can find assistance to administration and general use in our <a href="http://eqdkp-plus.eu/wiki/" target="_blank">Wiki</a>.</p>
<p>For further support, please visit our <a href="http://eqdkp-plus.eu/forum" target="_blank">Forum</a>.</p>
<p>Have fun with EQdkp Plus! Your EQdkp Plus team</p>',
	"feature_news_title" => 'Nouvelles fonctionnalités d\'EQdkp Plus',
	"feature_news" => '<p>EQdkp Plus 2.2 contains a lot of new Features. This article should introduce the most importent of them.</p> <h3>Articlesystem</h3> <p>Instead of news and infopages, we introduced a complete new article system. Each news and page is now an article. You can group your articles using article-categories. Moreover, you can realise for example blogs for your guild and users.</p> <p>You can divide a single article using the Readmore- and Pagebreak-Methods. Also, you can insert Image-Galeries, Items or Raidloot using the appropriate Editor-Buttons.</p> <h3>Media-Management</h3> <p>Using the new Media-Management in ACP or Editor, you can now easily insert Media into your articles. For example, files can be uploaded using Drag&Drop. Also, you can even edit images in the Filebrowser.</p> <h3>Menu-Management</h3> <p>We have removed all menus except one. And the last one could be totally configured. You can position the entries using Drag&Drop in 3 levels, so it\'s possible to create submenus. You can still create links to external pages, but also add direct links to articles or articlecategories.</p> <h3>Portal-Management</h3> <p>In former times, there was only one portallayout, you had on every page the same portal modules. That\'s why we implemented the portallayouts. Now you can assign a portallayout to each articlecategory.</p> <p>Furthermore, you can create own portal blocks that you can embedd in your template, for example for editing links in your footer.</p>',
	"category1" => 'Système',
	"category2" => 'Actualités',
	"category3" => 'Evénements',
	"category4" => 'Objets',
	"category5" => 'Raids',
	"category6" => 'Calendrier',
	"category7" => 'Roster',
	"category8" => 'Points',
	"category9" => 'Personnage',
	"article5" => 'Personnage',
	"article6" => 'Roster',
	"article7" => 'Evénements',
	"article8" => 'Objets',
	"article9" => 'Points',
	"article10" => 'Raids',
	"article12" => 'Evénements de calendrier',
	"article13" => 'Calendrier',
	"article14" => 'Règles de la guilde',
	"article15" => 'Politique de confidentialité',
	"article16" => 'Mentions légales',
	"role_healer" => 'Guérisseur',
	"role_tank" => 'Tank',
	"role_range" => 'DPS distant',
	"role_melee" => 'DPS mêlée',
	"create_user" => 'Créer un accès',
	"username" => 'Nom d\'utilisateur Administrateur',
	"user_password" => 'Mot de passe Administrateur',
	"user_pw_confirm" => 'Confirmer le mot de passe Administrateur',
	"user_email" => 'Adresse e-mail Administrateur',
	"auto_login" => 'Se souvenir de moi (cookie)',
	"user_required" => 'Utilisateur, e-mail et mot de passe sont des champs obligatoires',
	"no_pw_match" => 'Le mot de passe ne correspond pas.',
	"install_end_text" => 'L\'installation peut désormais être terminée avec succès.',
	"windows_apache_hint" => 'Vous semblez utiliser le serveur Apache sous Windows. EQdkp Plus ne fonctionnera que si vous augmentez le ThreadStackSize à 8388608 dans votre fichier de configuration d\'Apache.',
	"install_support_h1" => 'Soutenez EQdkp Plus',
	"install_support_text" => 'A project like EQdkp Plus can only exist, if we can get back some of the effort, time and love we invest in EQdkp Plus. You can give something back on the following ways:
						<ul>
							<li><i class="fa fa-puzzle-piece"></i> <a href="http://eqdkp-plus.eu/repository/">Publish a plugin or template, so every EQdkp Plus user can use it</a></li>
							<li><i class="fa fa-comments"></i> <a href="http://eqdkp-plus.eu/forum/">Support us at our board</a></li>
							<li><i class="fa fa-cogs"></i> <a href="https://eqdkp-plus.eu/en/development.html">Take part actively in the development of EQdkp Plus</a></li>
							<li><i class="fa fa-usd"></i> <a href="https://eqdkp-plus.eu/en/donate.html">Support us financially so we can continue offering you our services like LiveUpdate</a></li>
						</ul>
						So if you love EQdkp Plus as much as we do, think about supporting us!',
	
);

?>