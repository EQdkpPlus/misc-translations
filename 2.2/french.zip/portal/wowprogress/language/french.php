<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:49
//File: portal/wowprogress/language/french.php
//Source-Language: english

$lang = array( 
	"wowprogress" => 'WoWProgress',
	"wowprogress_desc" => 'Montrer le classement WoW depuis wowprogress.com',
	"wowprogress_name" => 'WoWProgress',
	"wp_tier" => 'Tier',
	"wowprogress_f_encounter" => 'Boss tués',
	"wowprogress_f_banner" => 'Afficher la bannière',
	"wowprogress_f_guild_id" => 'ID de guilde',
	"wowprogress_f_guild_id_help" => 'Insérer ici l\'ID de guilde depuis WoWProgress',
	"wp_ranking" => 'Classement',
	"wp_man" => 'Homme',
	"wp_world" => 'Classement mondial',
	"wp_rank" => 'Classement',
	"wp_realm" => 'Classement-Serveur',
	"wp_wow_only" => 'Ce module est pour le jeu "WoW" uniquement.',
	
);

?>