<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:49
//File: portal/realmstatus/language/french.php
//Source-Language: english

$lang = array( 
	"realmstatus" => 'Statut du serveur',
	"realmstatus_name" => 'Statut du serveur',
	"realmstatus_desc" => 'Afficher l\'état actuel du serveur',
	"realmstatus_f_realm" => 'Liste des serveurs',
	"realmstatus_f_help_realm" => 'Les serveurs multiples devront être séparés par une virgule.',
	"realmstatus_f_us" => 'Est-ce un serveur US ?',
	"realmstatus_f_help_us" => 'Ce paramètre n\'a d\'effet que pour les jeux RIFT et WoW.',
	"realmstatus_f_gd" => 'GD Lib (%s) trouvée. Souhaitez-vous l\'utiliser ?',
	"realmstatus_f_help_gd" => 'Ce paramètre n\'a d\'effet que pour WoW.',
	"rs_no_realmname" => 'Aucun serveur n\'a été spécifié',
	"rs_realm_not_found" => 'Serveur non trouvé',
	"rs_game_not_supported" => 'Le statut du serveur n\'est pas supporté pour le jeu actuel.',
	"rs_unknown" => 'Inconnu',
	"rs_realm_status_error" => 'Des erreurs sont survenues pendant la détermination de l\'état du serveure %1$s.',
	"rs_loading" => 'Chargement de l\'état...',
	"rs_loading_error" => 'Le chargement de l\'état a échoué',
	
);

?>