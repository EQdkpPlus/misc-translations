<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:49
//File: portal/nextevents/language/french.php
//Source-Language: english

$lang = array( 
	"nextevents" => 'Prochains événements',
	"nextevents_name" => 'Entrées du calendrier',
	"nextevents_desc" => 'Affiche sur votre portail des raids et événements à venir',
	"nr_nextevents_signon" => 'Inscrits',
	"nr_nextevents_confirmed" => 'Confirmés',
	"nr_nextevents_signoff" => 'Indisponibles',
	"nr_nextevents_missing" => 'Nécessaires',
	"nr_nextevents_notsigned" => 'Non-Inscrits',
	"nr_nextevents_noevents" => 'Pas d\'événement disponible',
	"nextevents_f_limit" => 'Afficher l\'échéance des prochains événements',
	"nextevents_f_hideclosed" => 'Masque les raids fermés',
	"nextevents_f_calendars" => 'Ne montrer que les événements des calendriers sélectionnés',
	"nextevents_f_types" => 'Choisissez le type d’événement',
	"nextevents_f_showweekday" => 'Afficher le jour de la semaine en face de la date',
	"nextevents_f_showendtime" => 'Afficher l\'heure de fin en plus de l\'heure de début',
	"nextevents_f_useflags" => 'Utiliser des drapeaux colorés au lieu des noms pour les statistiques de raid',
	"nextevents_f_showcalendarcolor" => 'Représenter le calendrier par un point de couleur en face de la date',
	"nextevents_f_raidcountdown" => 'Montrer le temps restant pour les raids',
	"nextevents_f_help_raidcountdown" => 'Affiche un compte à rebours au lieu de la date s\'il reste moins de 24h pour s\'inscrire à un raid',
	
);

?>