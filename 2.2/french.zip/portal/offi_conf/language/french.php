<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:49
//File: portal/offi_conf/language/french.php
//Source-Language: english

$lang = array( 
	"offi_conf" => 'Réunion d\'officiers - Sujets',
	"offi_conf_name" => 'Module de réunion d\'officiers',
	"offi_conf_desc" => 'Seuls les admins peuvent poster des sujets dans les réunions d\'officiers',
	"oc_f_day" => 'Jour de réunion des officiers',
	"oc_f_end_time" => 'Heure prévue de fin de réunion (HH:MM)',
	"oc_f_start_time" => 'Heure prévue de début de réunion (HH:MM)',
	"oc_f_time_type" => 'Definir le début ou la fin de la réunion des officiers ?',
	"oc_f_date" => 'Date de la prochaine réunion',
	"oc_f_period2" => 'Réunion d\'officiers toutes les X semaines',
	"oc_f_period3" => 'Réunion d\'officiers tous les X jour de la semaine du mois',
	"oc_f_type" => 'Type de répétition',
	"oc_weekday" => 'Un certain jour de la semaine',
	"oc_xmonthday" => 'Le x de chaque mois',
	"oc_manual" => 'Entrer la date manuellement',
	"oc_monday" => 'Lundi',
	"oc_tuesday" => 'Mardi',
	"oc_wednesday" => 'Mercredi',
	"oc_thursday" => 'Jeudi',
	"oc_friday" => 'Vendredi',
	"oc_saturday" => 'Samedi',
	"oc_sunday" => 'Dimanche',
	"oc_add_topic" => 'Ajouter un sujet',
	"oc_upd_topic" => 'Editer un sujet',
	"oc_next_topics" => 'Sujets suivant',
	"oc_topic_name" => 'Nom',
	"oc_topic_time" => 'Temps de parole (min)',
	"oc_topic_posi" => 'Trier',
	"oc_topic_desc" => 'Description',
	"oc_save" => 'Sauvegarder',
	"oc_delete" => 'Supprimer',
	"oc_save_success" => 'Sauvegarde réussie',
	"oc_save_no_success" => 'Sauvegarde échouée !',
	"oc_delete_success" => 'Suppression réussie',
	"oc_delete_no_success" => 'Suppression échouée!',
	"oc_no_name" => 'Sans nom',
	"oc_no_desc" => 'Pas de description',
	"oc_creator" => 'Créer par:',
	"oc_min" => 'min',
	"oc_next_oc" => 'Prochaine réunion d\'officiers',
	"oc_start" => 'Début',
	"oc_end" => 'Fin',
	
);

?>