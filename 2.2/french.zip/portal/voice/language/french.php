<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:49
//File: portal/voice/language/french.php
//Source-Language: english

$lang = array( 
	"voice" => 'Observateur de serveur vocal',
	"voice_name" => 'Observateur de serveur vocal',
	"voice_desc" => 'Observateur de serveur vocal tels que Teamspeak3, Mumble ou Ventrilo',
	"voice_f_module" => 'Choisissez votre serveur vocal',
	"mumble" => 'Mumble',
	"voice_f_mumble_datauri" => 'Data URI',
	"voice_f_help_mumble_datauri" => 'Saisissez le CVP Uniform Resource Identifier fourni par votre hébergeur',
	"voice_f_mumble_dataformat" => 'Data Format',
	"voice_f_help_mumble_dataformat" => 'Choisissez le data format spécifié par votre hébergeur',
	"voice_f_mumble_linkuri" => 'Lien URI',
	"voice_f_help_mumble_linkuri" => 'Optional: Enter the mumble:// link address to join your server. It is used only, when your servers data does not include it.',
	"voice_f_mumble_iconstyle" => 'Style d\'icônes',
	"voice_f_help_mumble_iconstyle" => 'Choisissez le style d\'icônes que vous préférez.',
	"ts3" => 'Teamspeak 3',
	"voice_f_ts3_ip" => 'Your Server IP (without Port)',
	"voice_f_ts3_port" => 'The port - Default: 9987',
	"voice_f_ts3_telnetport" => 'The Telnet Port of your Server - Default: 10011',
	"voice_f_ts3_id" => 'The ID from your Virtual Server - Default: 1',
	"voice_f_help_ts3_id" => 'Enter -1 to use the servers port to connect instead of the servers id.',
	"voice_f_ts3_cache" => 'Durée minimum entre les requêtes TS3 (en secondes)',
	"voice_f_help_ts3_cache" => 'Pendant combien de secondes les données de TS3 devront rester en cache avant d\'être rafraîchies. 0 pour désactiver le cache.',
	"voice_f_ts3_banner" => 'Afficher la bannière si son URL est disponible dans TS ?',
	"voice_f_ts3_join" => 'Afficher le lien pour rejoindre le serveur ?',
	"voice_f_ts3_jointext" => 'Lien texte permettant d\'accéder au serveur',
	"voice_f_ts3_legend" => 'Afficher les informations du groupe en dessous ?',
	"voice_f_ts3_cut_names" => 'Couper les noms d\'utilisateurs',
	"voice_f_help_ts3_cut_names" => 'Si vous voulez tronquer les noms d\'utilisateurs, indiquez la taille voulue - Aucune troncature = 0',
	"voice_f_ts3_cut_channel" => 'Couper les noms de canaux',
	"voice_f_help_ts3_cut_channel" => 'Si vous voulez tronquer les noms de canaux, indiquez la taille voulue - Aucune troncature = 0',
	"voice_f_only_populated_channel" => 'Ne montrer que les canaux occupés ?',
	"voice_f_ts3_useron" => 'Show Online User / Possible Users?',
	"voice_f_ts3_stats" => 'Afficher une boite de statistique en dessous de l\'observateur de TS ?',
	"voice_f_ts3_stats_showos" => 'Afficher l\'OS faisant tourner TS3 ?',
	"voice_f_ts3_stats_version" => 'Afficher la version du serveur TS3 ?',
	"voice_f_ts3_stats_numchan" => 'Afficher le nombre de canaux ?',
	"voice_f_ts3_stats_uptime" => 'Afficher le temps écoulé depuis le dernier démarrage ?',
	"voice_f_ts3_stats_install" => 'Afficher la date d\'installation du serveur ?',
	"voice_f_ts3_timeout" => 'Timeout (NE PAS changer)',
	"voice_f_help_ts3_timeout" => 'Laissez cette valeur vide à moins de vraiment savoir ce que vous faites.',
	"voice_f_ts3_show_spacer" => 'Afficher les séparateurs de canaux',
	"lang_ts3_user_online" => 'Utilisateur en ligne',
	"lang_ts3_stats" => 'Statistiques',
	"lang_ts3_legend" => 'Légende',
	"lang_ts3_uptime" => array(
	0 => 'Jours',
	1 => 'Heures',
	2 => 'Min',
	),
	"ventrilo" => 'Ventrilo',
	"voice_f_ventrilo_server" => 'Saisissez l\'adresse du serveur ventrilo',
	"voice_f_ventrilo_port" => 'Saisissez le port du serveur Ventrilo',
	"voice_f_ventrilo_backgroundc" => 'Enter the 6 digit hex color for the BACKGROUND (TTTTTT = transparent (http://www.computerhope.com/htmcolor.htm))',
	"voice_f_ventrilo_channelc" => 'Saisissez les 6 caractères héxa du code de la couleur de CANAL ',
	"voice_f_ventrilo_servercolor" => 'Saisissez les 6 caractères héxa du code de la couleur de SERVEUR',
	"voice_f_ventrilo_usercolor" => 'Saisissez les 6 caractères héxa du code de la couleur de NOM D\'UTILISATEUR',
	
);

?>