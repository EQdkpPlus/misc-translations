<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:49
//File: games/eso/language/french.php
//Source-Language: english

$french_array = array( 
	"factions" => array(
	"aldmeri" => 'Domaine Aldmeri',
	"daggerfall" => 'Alliance de Daguefilante',
	"ebonhard" => 'Pacte de Coeurébène',
	),
	"classes" => array(
	0 => 'Inconnue',
	1 => 'Chevalier Dragon',
	2 => 'Templier',
	3 => 'Sorcier',
	4 => 'Lamenoire',
	),
	"races" => array(
	0 => 'Inconnue',
	1 => 'Impérial',
	2 => 'Altmer',
	3 => 'Bosmer',
	4 => 'Khajiit',
	5 => 'Bréton',
	6 => 'Rougegarde',
	7 => 'Orque',
	8 => 'Nordique',
	9 => 'Dunmer',
	10 => 'Argonien',
	),
	"lang" => array(
	"eso" => 'The Elder Scrolls Online',
	"core_sett_fs_gamesettings" => 'Paramètres d\'Elder Scrolls Online',
	"uc_faction" => 'Faction',
	"uc_gender" => 'Sexe',
	"uc_male" => 'Mâle',
	"uc_female" => 'Femelle',
	"uc_guild" => 'Guilde',
	"uc_race" => 'Race',
	"uc_class" => 'Classe',
	"uc_level" => 'Niveau',
	"uc_championspoints" => 'Points Champions',
	),
	
);

?>