<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:49
//File: games/eos/language/french.php
//Source-Language: english

$french_array = array( 
	"classes" => array(
	0 => 'Inconnue',
	1 => 'Rôdeur
',
	2 => 'Guerrier',
	3 => 'Gardienne',
	4 => 'Archère',
	5 => 'Magicienne',
	),
	"skills" => array(
	0 => 'Inconnue',
	1 => 'Duelliste',
	2 => 'Assassin',
	3 => 'Sentinelle',
	4 => 'Berserker',
	5 => 'Aéris',
	6 => 'Telluris',
	7 => 'Chasseuse',
	8 => 'Barde',
	9 => 'Pyro',
	10 => 'Cryo',
	),
	"races" => array(
	0 => 'Humain',
	),
	"roles" => array(
	1 => 'Tank',
	2 => 'DPS',
	3 => 'Soutien',
	4 => 'JCJ',
	),
	"professions" => array(
	0 => 'Inconnue',
	"juwel" => 'Bijoutier',
	"collect" => 'Récupérateur',
	"alchem" => 'Alchimiste',
	),
	"professions2" => array(
	0 => 'Inconnue',
	"cook" => 'Cuisinier',
	"spirit" => 'Expert des âmes',
	),
	"lang" => array(
	"eos" => 'Echo of Soul',
	"uc_prof1_name" => 'Métier principal',
	"uc_prof_value" => 'Niveau',
	"uc_prof2_name" => 'Métier secondaire',
	"uc_class" => 'Classe',
	"uc_skill" => 'Spécialisation',
	"uc_level" => 'Niveau',
	"dryadenwald" => 'Forêt des Dryades',
	"hc_dryadenwald" => 'Forêt des Dryades (Difficile)',
	"tr_dryadenwald" => 'Forêt des Dryades (Entrainement)',
	),
	
);

?>