<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:49
//File: games/allods/language/french.php
//Source-Language: english

$french_array = array( 
	"classes" => array(
	0 => 'Inconnue',
	1 => 'Guerrier',
	2 => 'Paladin',
	8 => 'Éclaireur',
	3 => 'Guérisseur',
	6 => 'Tribaliste',
	5 => 'Mage',
	4 => 'Invocateur',
	7 => 'Psionique',
	9 => 'Barde',
	10 => 'Ingénieur',
	),
	"races" => array(
	0 => 'Inconnue',
	1 => 'Kanian',
	2 => 'Elfe',
	3 => 'Gibberling',
	4 => 'Xadaganien',
	5 => 'Orc',
	6 => 'Arisen',
	7 => 'Pridens',
	),
	"lang" => array(
	"allods" => 'Allods Online',
	"plate" => 'Plaque',
	"cloth" => 'Tissu',
	"leather" => 'Cuir',
	"uc_gender" => 'Sexe',
	"uc_male" => 'Mâle',
	"uc_female" => 'Femelle',
	"uc_branch" => 'Archétype',
	"uc_guild" => 'Guilde',
	"uc_race" => 'Race',
	"uc_class" => 'Classe',
	"core_sett_fs_gamesettings" => 'Paramètres d\'Allods Online',
	"uc_faction" => 'Faction',
	"uc_faction_help" => 'Choisissez la faction par défaut',
	"uc_abranch_0" => '-',
	"uc_abranch_1" => 'Bagarreur',
	"uc_abranch_2" => 'Champion',
	"uc_abranch_3" => 'Templier',
	"uc_abranch_4" => 'Chevalier',
	"uc_abranch_5" => 'Braconnier',
	"uc_abranch_6" => 'Rôdeur',
	"uc_abranch_7" => 'Chapelain',
	"uc_abranch_8" => 'Clerc',
	"uc_abranch_9" => 'Animiste',
	"uc_abranch_10" => 'Druide',
	"uc_abranch_11" => 'Archimage',
	"uc_abranch_12" => 'Magicien',
	"uc_abranch_13" => 'Démoniste',
	"uc_abranch_14" => 'Devin',
	"uc_abranch_15" => 'Conquérant',
	"uc_abranch_16" => 'Brute',
	"uc_abranch_17" => 'Vengeur',
	"uc_abranch_18" => 'Ravageur',
	"uc_abranch_19" => 'Saboteur',
	"uc_abranch_20" => 'Traqueur',
	"uc_abranch_21" => 'Inquisiteur',
	"uc_abranch_22" => 'Hérétique',
	"uc_abranch_23" => 'Chaman',
	"uc_abranch_24" => 'Sorcier',
	"uc_abranch_25" => 'Thanatologue',
	"uc_abranch_26" => 'Savant',
	"uc_abranch_27" => 'Mentaliste',
	"uc_abranch_28" => 'Occultiste',
	"uc_abranch_29" => 'Troubadour',
	"uc_abranch_30" => 'Rhapsode',
	"uc_abranch_31" => '**espace réservé**',
	"uc_abranch_32" => '**espace réservé**',
	"uc_abranch_33" => '**espace réservé**',
	"uc_abranch_34" => '**espace réservé**',
	),
	
);

?>