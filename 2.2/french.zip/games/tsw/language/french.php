<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:49
//File: games/tsw/language/french.php
//Source-Language: english

$french_array = array( 
	"classes" => array(
	0 => 'Inconnue',
	1 => 'Tank',
	2 => 'Guérisseur',
	3 => 'DPS',
	4 => 'Mêlée',
	5 => 'Leech',
	),
	"races" => array(
	0 => 'Inconnue',
	1 => 'Templiers',
	2 => 'Dragons',
	3 => 'Illuminati',
	),
	"roles" => array(
	0 => 'Tous les rôles',
	1 => 'Fist-healer',
	2 => 'Blood-healer',
	3 => 'Leech/Riffle Heal',
	4 => 'Tank',
	5 => 'Buff-Tank',
	6 => 'Heal-Tank',
	7 => 'Leech-Tank',
	8 => 'DA/BS-Buffs',
	9 => 'DPS',
	10 => 'Buff Mèche Courte',
	11 => 'Corps à corps',
	12 => 'MeleeVul	
',
	13 => 'RangedVul	
',
	14 => 'MagicVul	
',
	),
	"lang" => array(
	"tsw" => 'The Secret World',
	"uc_race" => 'Faction',
	"uc_class" => 'Classe favorite',
	"uc_faction" => 'Faction',
	"uc_cat_misc" => 'divers',
	"uc_pvp" => 'Champs de bataille PVP',
	"uc_pvp_help" => 'Battlegroup est saturé',
	"uc_RP" => 'Rôliste',
	"uc_RP_help" => '',
	"uc_yes" => 'Oui',
	"uc_no" => 'Non',
	"uc_unknown" => 'inconnu',
	"uc_ED" => 'Eldorado',
	"uc_SH" => 'Stonehenge',
	"uc_ShB" => 'Shambala',
	"uc_BG" => 'Battlegroup',
	"uc_BG_A" => 'Fusang BG-A',
	"uc_BG_B" => 'Fusang BG-B',
	"uc_guild" => 'Cabale',
	"uc_level" => 'Niveau d\'effusion',
	"uc_testlive" => 'Accès à Testlive',
	"uc_18h_Raid_cooldown" => 'Temps de rechargement du 18ème raid',
	"uc_wings" => 'Couleur d\'aile',
	"uc_blue" => 'Bleue',
	"uc_gold" => 'Dorée',
	"uc_purple" => 'Violette',
	"uc_nowings" => 'Aucune',
	"eidolon_elite" => 'Eidolon Elite',
	"ny_raid_elite" => 'New York Elite',
	"flappy_nm" => 'Flappy NM',
	"eidolon_nm" => 'Eidolon NM',
	"nyr_nm" => 'New York NM',
	"flappy_elite" => 'Flappy Elite',
	"core_sett_fs_gamesettings" => 'Paramètres de The Secret World',
	"Heroic" => 'Héroïque',
	"Epic" => 'Epique',
	"Rare" => 'Rare',
	"Normal" => 'Extraordinaire',
	"Other" => 'Ordinaire',
	"Augments" => 'Résonateur d\'augmentation',
	"Signets" => 'Signets',
	"Event-Items" => 'Objets d\'événements',
	"Clothes" => 'Habits',
	"Emotes" => 'Emoticones',
	"Token-Items" => 'Jetons',
	"Material" => 'Materiaux',
	"Others" => 'Autres',
	),
	
);

?>