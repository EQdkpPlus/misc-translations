<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:49
//File: games/syf/language/french.php
//Source-Language: english

$french_array = array( 
	"classes" => array(
	0 => 'Inconnu',
	1 => 'Alchimiste',
	2 => 'Archer',
	3 => 'Lumancien',
	4 => 'Berseker',
	5 => 'Kinétic',
	6 => 'Cryomancien',
	7 => 'Paladin',
	8 => 'Artilleur',
	9 => 'Chevalier',
	10 => 'Moine',
	11 => 'Nécromancien',
	12 => 'Sorcier',
	13 => 'Assassin',
	),
	"clans" => array(
	0 => 'Inconnu',
	1 => 'Clan01',
	2 => 'Clan02',
	3 => 'Clan03',
	4 => 'Clan04',
	5 => 'Clan05',
	6 => 'Clan06',
	7 => 'Clan07',
	8 => 'Clan08',
	9 => 'Clan09',
	10 => 'Clan10',
	11 => 'Clan11',
	12 => 'Clan12',
	13 => 'Clan13',
	14 => 'Clan14',
	15 => 'Clan15',
	),
	"roles" => array(
	1 => 'Tank',
	2 => 'Sorts',
	3 => 'Support',
	4 => 'Distant',
	5 => 'Corps à corps',
	),
	"lang" => array(
	"syf" => 'Skyforge',
	"uc_gender" => 'Sexe',
	"uc_male" => 'Mâle',
	"uc_female" => 'Femelle',
	"uc_guild" => 'Panthéon',
	"uc_clan" => 'Clan',
	"uc_race" => 'Race',
	"uc_class" => 'Classe',
	"uc_cat_misc" => 'divers',
	"uc_yes" => 'Oui',
	"uc_no" => 'Non',
	"uc_unknown" => 'Inconnu',
	"uc_level" => 'Prestige',
	"core_sett_fs_gamesettings" => 'Paramètres de Skyforge',
	"Heroic" => 'Héroïque',
	"Epic" => 'Épique',
	"Rare" => 'Rare',
	"Normal" => 'Extraordinaire',
	"Other" => 'Ordinaire',
	),
	
);

?>