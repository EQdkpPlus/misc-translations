<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Spanish	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:49
//File: core/data_handler/includes/modules/read/articles/language/spanish.php
//Source-Language: english

$module_lang = array(
	"sort_id" => '',
	"editicon" => '',
	"published" => '',
	"featured" => '',
	"title" => 'Título',
	"alias" => 'Alias',
	"user_id" => 'Usuario',
	"date" => 'Fecha',
	"last_edited" => 'Última modificación',
	"index_cb" => 'Índice',
	);
	$preset_lang = array(
	"article_sortable" => 'Clasificación de artículos',
	"article_editicon" => 'Article Editlink	
',
	"article_published" => 'Fecha de publicación del artículo',
	"article_title" => 'Título del artículo',
	"article_alias" => 'Alias del artículo',
	"article_date" => 'Fecha del artículo',
	"article_user" => 'Usuario del artículo',
	"article_featured" => 'Articulo Destacado',
	"article_last_edited" => 'Última edición del artículo',
	"article_index_cb" => 'Article Index Checkbox	',
	);
	

?>