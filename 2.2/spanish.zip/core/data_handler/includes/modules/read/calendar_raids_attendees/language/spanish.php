<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Spanish	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:49
//File: core/data_handler/includes/modules/read/calendar_raids_attendees/language/spanish.php
//Source-Language: english

$module_lang = array(
	"html_status" => '',
	"html_calstat_lastraid" => 'RCS - Última raid',
	"html_calstat_raids_confirmed" => 'Atendido',
	"html_calstat_raids_signedin" => 'Apuntado',
	"html_calstat_raids_signedoff" => 'No apuntado',
	"html_calstat_raids_backup" => 'En reserva',
	"calstat_raids_confirmed_fromto" => 'Atendido',
	"calstat_raids_signedin_fromto" => 'Apuntado',
	"calstat_raids_signedoff_fromto" => 'Rechazado',
	"calstat_raids_backup_fromto" => 'Copia de seguridad',
	"calstat_raids_total_fromto" => 'Total',
	);
	$preset_lang = array(
	"raidattendees_status" => 'Estado de asitencia de la banda en el calendario',
	"raidcalstats_lastraid" => 'Calendario-Estadísticas-Última banda',
	"raidcalstats_raids_confirmed_90" => 'Calendario-Estadísticas-Bandas confirmadas (90 días)',
	"raidcalstats_raids_signedin_90" => 'Calendario-Estadísticas-Bandas apuntadas (90 días)',
	"raidcalstats_raids_signedoff_90" => 'Calendario-Estadísticas-Bandas rechazadas (90 días)',
	"raidcalstats_raids_backup_90" => 'Calendario-Estadísticas-Bandas en reserva (90 días)',
	"raidcalstats_raids_confirmed_60" => 'Calendario-Estadísticas-Bandas confirmadas (60 días)',
	"raidcalstats_raids_signedin_60" => 'Calendario-Estadísticas-Bandas apuntadas (60 días)',
	"raidcalstats_raids_signedoff_60" => 'Calendario-Estadísticas-Bandas rechazadas (60 días)',
	"raidcalstats_raids_backup_60" => 'Calendario-Estadísticas-Bandas en reserva (60 días)',
	"raidcalstats_raids_confirmed_30" => 'Calendario-Estadísticas-Bandas confirmadas (30 días)',
	"raidcalstats_raids_signedin_30" => 'Calendario-Estadísticas-Bandas apuntadas (30 días)',
	"raidcalstats_raids_signedoff_30" => 'Calendario-Estadísticas-Bandas rechazadas (30 días)',
	"raidcalstats_raids_backup_30" => 'Calendario-Estadísticas-Bandas en reserva (30 días)',
	"raidcalstats_raids_confirmed_fromto" => 'Calendario-Estadísticas-Bandas confirmadas (def. días)',
	"raidcalstats_raids_signedin_fromto" => 'Calendario-Estadísticas-Bandas apuntadas (def. días)',
	"raidcalstats_raids_signedoff_fromto" => 'Calendario-Estadísticas-Bandas rechazadas (def. días)',
	"raidcalstats_raids_backup_fromto" => 'Calendario-Estadísticas-Bandas en reserva (def. días)',
	);
	

?>