<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Spanish	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:49
//File: language/spanish/lang_install.php
//Source-Language: english

$lang = array( 
	"page_title" => 'Instalacion de EQDKP-Plus',
	"back" => 'Guardar y regresar',
	"continue" => 'Proceder',
	"language" => 'Lenguaje',
	"inst_finish" => 'Instalación completa',
	"error" => 'Error',
	"warning" => 'Aviso',
	"success" => 'Éxito',
	"yes" => 'Si',
	"no" => 'No',
	"retry" => 'Intentar',
	"skip" => 'Saltar',
	"step_order_error" => 'Step-Order error: Step not found. Please ensure that all files are uploaded correctly. For further information please visit our forums at <a href="http://eqdkp-plus.eu/forum">http://eqdkp-plus.eu/forum</a>.',
	"licence" => 'Acuerdo de Licencia',
	"php_check" => 'Test de Pre-instalacion',
	"ftp_access" => 'Configuracion FTP',
	"encryptionkey" => 'Código de Encriptación',
	"data_folder" => 'Carpeta de Datos',
	"db_access" => 'Acceso a la Base de datos',
	"inst_settings" => 'Configuración',
	"admin_user" => 'Cuenta de Administrador',
	"end" => 'Instalación Completa',
	"welcome" => 'Bienvenido al instalador de EQdkp Plus. Hemos trabajado duro para hacer que este proceso sea fácil y rápido. Para empezar, simplemente acepta nuestro contrato de licencia haciendo clic en "aceptar y Empezar Instalación" a continuación.',
	"accept" => 'Aceptar y Empezar Instalación',
	"license_text" => '<b>EQdkp Plus is published under AGPL v3.0 license.</b><br /><br /> The full license text can be found at <a href="http://opensource.org/licenses/AGPL-3.0" target="_blank">http://opensource.org/licenses/AGPL-3.0</a>.<br /><br />
	This is a summary of the most important terms of the AGPL v3.0. There is no claim to completeness and correctness.<br /><br />
	<h3><strong>You are permitted:</strong></h3>
<ul>
<li>to use this software for commercial use</li>
<li>to distribute this software</li>
<li>to modify this software</li>
</ul>
<h3><strong>You are required:</strong></h3>
<ul>
<li>to disclose the sourcecode of your complete application that uses EQdkp Plus, when you distribute your application</li>
<li>to disclose the sourcecode of your complete application that uses EQdkp Plus, if you don\'t distribute it, but users are using the software via network ("Hosting", "SaaS")</li>
<li>to remain the visible and unvisible Copyright Notices of this Project and to include a copy of the AGPL License at your application</li>
<li>to indicate significant changes made to the code</li>
</ul>
<h3><strong>It\'s forbidden:</strong></h3>
<ul>
<li>to held the author(s) of this software liable for any damages, the software is provided without warranty.</li>
<li>to license your application under another license than the AGPL</li>
</ul>',
	"table_pcheck_name" => 'Nombre',
	"table_pcheck_required" => 'Requerido',
	"table_pcheck_installed" => 'Actual',
	"table_pcheck_rec" => 'Recomendado',
	"module_php" => 'Verisón PHP',
	"module_mysql" => 'Base de Datos MySQL',
	"module_zLib" => 'Modulo zLib PHP',
	"module_safemode" => 'Modo Seguro PHP',
	"module_curl" => 'Modulo cURL PHP',
	"module_fopen" => 'Función fopen PHP',
	"module_soap" => 'modulo SOAP PHP',
	"module_autoload" => 'Función PHP spl_autoload_register',
	"module_hash" => 'Función PHP de hash',
	"module_memory" => 'Limite de la memoria PHP',
	"module_json" => 'Modulo JSON PHP',
	"module_gd" => 'Modulo GD Image',
	"module_pathinfo" => 'Pathinfo-Soporte',
	"module_xml" => 'XML PHP module',
	"safemode_warning" => '<strong>WARNING</strong><br/>Because the PHP Safe mode is active, you have to use the FTP mode in the next Step in order to use EQdkp Plus!',
	"phpcheck_success" => 'Los requisitos mínimos para la instalación de EQdkp-Plus se cumplen. La instalación puede proceder.',
	"phpcheck_failed" => 'The minimum requirements for the installation of EQDKP-Plus are not met.<br />A selection of suitable hosting companies can be found on our <a href="http://eqdkp-plus.eu" target="_blank">website</a>',
	"do_match_opt_failed" => 'Algunos recomienda no se cumplen. EQDKP-Plus funciona en este sistema; Sin embargo, tal vez no todas las funciones estarán disponibles.',
	"ftphost" => 'Direccion FTP',
	"ftpport" => 'Puerto FTP',
	"ftpuser" => 'Usuario FTP',
	"ftppass" => 'Clave FTP',
	"ftproot" => 'Dirección base FTP',
	"ftproot_sub" => '(Ruta de acceso al directorio raíz del usuario FTP)',
	"useftp" => 'Utilizar el modo FTP como controlador de archivos.',
	"useftp_sub" => '(Puedes cambiarlo mas tarde editando el config.php)',
	"safemode_ftpmustbeon" => 'Ya que el modo seguro PHP esta encendido, los detalles FTP deben de completarse para continuar la instalación.',
	"ftp_connectionerror" => 'La conexión FTP no ha podido establecerse. Por favor comprueba el host FTP y el puerto FTP',
	"ftp_loginerror" => 'El inicio de sesión FTP no tuvo éxito. Pro favor comprueba tu nombre de usuario FTP y tu contraseña FTP',
	"plain_config_nofile" => 'The file <b>config.php</b> is not available and automatic creation failed. <br />Please create a blank text file with the name <b>config.php</b> and set the permissions with chmod 777',
	"plain_config_nwrite" => 'The <b>config.php</b> file is not writeable. <br /> Please set the correct permissions. <b>chmod 0777 config.php</b>.',
	"plain_dataf_na" => 'The folder <b>./data/</b> is not available.<br /> Please create this folder. <b>mkdir data</​​b>.',
	"plain_dataf_nwrite" => 'The folder <b>./data/</b> is not writeable.<br /> Please set the correct permissions. <b>chmod -R 0777 data</​​b>.',
	"ftp_datawriteerror" => 'La carpeta de datos no pudo ser escrito. ¿Esta la ruta de raíz FTP configurado correctamente?',
	"ftp_info" => 'Para mejorar la seguridad y la funcionalidad, se puede optar por permitir que una cuenta ftp de su elección para realizar las interacciones de archivos en el servidor. Esto reduce la necesidad de utilizar los permisos de servidor más abiertas, y puede ser necesario en algunas configuraciones de hosting. Para utilizar esta configuración opcional por favor proporcione un usuario ftp con permisos para acceder a su instalación, y seleccione la casilla de verificación "Modo FTP \'. Si no está utilizando el modo FTP simplemente puede seleccionar proceder en esta página.',
	"ftp_tmpinstallwriteerror" => 'The folder <b>./data/97384261b8bbf966df16e5ad509922db/tmp/</b> is not writable.<br />To write the config-file, CHMOD 777 is required. This folder will be deleted after the installation process.',
	"ftp_tmpwriteerror" => 'The folder <b>./data/%s/tmp/</b> is not writable.<br />Using FTP-Mode requires CHMOD 777 for this folder. This is the only folder needing writing permissions.',
	"dbtype" => 'Tipo de Base de Datos',
	"dbhost" => 'Direccion de la Base de Datos',
	"dbname" => 'Nombre de la Base de Datos',
	"dbuser" => 'Usuario de la Base de Datos',
	"dbpass" => 'Clave de la Base de Datos',
	"table_prefix" => 'Prefijo para la tablas EQDKP-Plus',
	"test_db" => 'Prueba Base de datos',
	"prefix_error" => 'Prefijo especificado no hay o la base de datos no es válido! Por favor, introduzca un prefijo válido.',
	"INST_ERR_PREFIX" => 'Una instalación EQDKP con ese prefijo ya existe. Eliminar todas las tablas con el prefijo y repetir este paso una vez que haya utilizado el botón "Atrás". Alternativamente, usted puede elegir un prefijo diferente, por ejemplo, si desea instalar varios conjuntos de datos EQDKPlus en una base de datos.',
	"INST_ERR_PREFIX_INVALID" => 'El prefijo de la tabla que has especificado es invalido para tu base de datos. Por favor prueba otro, quitando caracteres tal como guiones, apostrofes o barras.
',
	"dbcheck_success" => 'La base de datos se comprobó. No se encontraron errores ni conflictos. La instalación se puede continuar de forma segura.',
	"encryptkey_info" => 'La clave de cifrado es parte del proceso de cifrado que se utiliza para proteger los datos sensibles en la base de datos, como direcciones de correo electrónico de sus usuarios. Incluso si su base de datos se ve comprometida, sin la clave de cifrado de los datos permanecen codificada y segura. Por lo tanto, por favor elija una clave segura, y asegúrese de guardar una copia de seguridad. Cosa Nadie puede recuperarlo para usted si se ha perdido!',
	"encryptkey" => 'Clave de cifrado',
	"encryptkey_help" => '(min. longitud 6 caracteres)',
	"encryptkey_repeat" => 'Confirmar clave de cifrado',
	"encryptkey_no_match" => 'La clave de cifrado no coincide',
	"encryptkey_too_short" => 'La clave de cifrado es demasiado corta. Longitud minima 6 caracteres',
	"inst_db" => 'Instalación de la Base de Datos',
	"lang_config" => 'Configuración de Lenguaje',
	"default_lang" => 'Lenguaje por Defecto',
	"default_locale" => 'Localización por defecto',
	"game_config" => 'Configuración del juego',
	"default_game" => 'Juego por defecto',
	"server_config" => 'Configuración del servidor',
	"server_path" => 'Script path',
	"grp_guest" => 'Invitados',
	"grp_super_admins" => 'Super Administrador',
	"grp_admins" => 'Administrador',
	"grp_officers" => 'oficiales',
	"grp_writers" => 'Editores',
	"grp_member" => 'Miembros',
	"grp_guest_desc" => 'Invitados que no se han registrado como usuarios',
	"grp_super_admins_desc" => 'Los super-administradores tienen poderes completos',
	"grp_admins_desc" => 'Administradores que no tienen todos los derechos de administradores.',
	"grp_officers_desc" => 'Los oficiales son capaces de administrar la banda',
	"grp_writers_desc" => 'Los editores son capaces de escribir y gestionar noticias',
	"grp_member_desc" => 'Miembro',
	"game_info" => 'Más juegos soportados se pueden descargar después de la instalación en la gestión de la extensión.',
	"timezone" => 'Zona horaria del servidor',
	"startday" => 'Primer dia de la semana',
	"sunday" => 'Domingo',
	"monday" => 'Lunes',
	"time_format" => 'H:i',
	"date_long_format" => 'j. F Y',
	"date_short_format" => 'd.m.y',
	"style_jsdate_nrml" => 'DD/MM/YYYY',
	"style_jsdate_short" => 'D.M',
	"style_jstime" => 'hh:mm tt',
	"welcome_news_title" => 'Bienvenido a EQDKP-Plus',
	"welcome_news" => '<p>The installation of your EQdkp Plus was completed successfully - you can now set it up according to your wishes.</p>
<p>You can find assistance to administration and general use in our <a href="http://eqdkp-plus.eu/wiki/" target="_blank">Wiki</a>.</p>
<p>For further support, please visit our <a href="http://eqdkp-plus.eu/forum" target="_blank">Forum</a>.</p>
<p>Have fun with EQdkp Plus! Your EQdkp Plus team</p>',
	"feature_news_title" => 'Novedades de EQdkp Plus',
	"feature_news" => '<p>EQdkp Plus 2.2 contains a lot of new Features. This article should introduce the most importent of them.</p> <h3>Articlesystem</h3> <p>Instead of news and infopages, we introduced a complete new article system. Each news and page is now an article. You can group your articles using article-categories. Moreover, you can realise for example blogs for your guild and users.</p> <p>You can divide a single article using the Readmore- and Pagebreak-Methods. Also, you can insert Image-Galeries, Items or Raidloot using the appropriate Editor-Buttons.</p> <h3>Media-Management</h3> <p>Using the new Media-Management in ACP or Editor, you can now easily insert Media into your articles. For example, files can be uploaded using Drag&Drop. Also, you can even edit images in the Filebrowser.</p> <h3>Menu-Management</h3> <p>We have removed all menus except one. And the last one could be totally configured. You can position the entries using Drag&Drop in 3 levels, so it\'s possible to create submenus. You can still create links to external pages, but also add direct links to articles or articlecategories.</p> <h3>Portal-Management</h3> <p>In former times, there was only one portallayout, you had on every page the same portal modules. That\'s why we implemented the portallayouts. Now you can assign a portallayout to each articlecategory.</p> <p>Furthermore, you can create own portal blocks that you can embedd in your template, for example for editing links in your footer.</p>',
	"category1" => 'Sistema',
	"category2" => 'Noticias',
	"category3" => 'Eventos',
	"category4" => 'Objetos',
	"category5" => 'Bandas',
	"category6" => 'Calendario',
	"category7" => 'Roster',
	"category8" => 'Puntos',
	"category9" => 'Personaje',
	"article5" => 'Personaje',
	"article6" => 'Roster',
	"article7" => 'Eventos',
	"article8" => 'Objetos',
	"article9" => 'Puntos',
	"article10" => 'Bandas',
	"article12" => 'Eventos de Calendario',
	"article13" => 'Calendario',
	"article14" => 'Reglas de Hermandad',
	"article15" => 'Política de Privacidad',
	"article16" => 'Legal',
	"role_healer" => 'Sanador',
	"role_tank" => 'Tanque',
	"role_range" => 'DPS Distancia',
	"role_melee" => 'DPS Mele',
	"create_user" => 'Crear Acceso',
	"username" => 'Nombre de usuario del administrador',
	"user_password" => 'Clave de Administrador',
	"user_pw_confirm" => 'Confirmar clave de adminsitrador',
	"user_email" => 'Direccion correo de Admiministrador',
	"auto_login" => 'Recuerdame (cookie)',
	"user_required" => 'Usuario, correo y clave son campos obligatorios',
	"no_pw_match" => 'Las contraseñas no coinciden',
	"install_end_text" => 'La instalacion se ha completado con exito',
	"windows_apache_hint" => 'Parece que está utilizando Apache en Windows como servidor web. EQDKP Plus sólo funcionará si se aumenta el ThreadStackSize a 8.388.608 en el archivo de configuración de Apache.',
	"install_support_h1" => 'Support EQdkp Plus',
	"install_support_text" => 'A project like EQdkp Plus can only exist, if we can get back some of the effort, time and love we invest in EQdkp Plus. You can give something back on the following ways:
						<ul>
							<li><i class="fa fa-puzzle-piece"></i> <a href="http://eqdkp-plus.eu/repository/">Publish a plugin or template, so every EQdkp Plus user can use it</a></li>
							<li><i class="fa fa-comments"></i> <a href="http://eqdkp-plus.eu/forum/">Support us at our board</a></li>
							<li><i class="fa fa-cogs"></i> <a href="https://eqdkp-plus.eu/en/development.html">Take part actively in the development of EQdkp Plus</a></li>
							<li><i class="fa fa-usd"></i> <a href="https://eqdkp-plus.eu/en/donate.html">Support us financially so we can continue offering you our services like LiveUpdate</a></li>
						</ul>
						So if you love EQdkp Plus as much as we do, think about supporting us!',
	
);

?>