<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Spanish	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:49
//File: games/tsw/language/spanish.php
//Source-Language: english

$spanish_array = array( 
	"classes" => array(
	0 => 'Desconocido',
	1 => 'Tank',
	2 => 'Healer',
	3 => 'DPS',
	4 => 'Mele',
	5 => 'Leech',
	),
	"races" => array(
	0 => 'Desconocido',
	1 => 'Templarios',
	2 => 'Dragones',
	3 => 'Illuminati',
	),
	"roles" => array(
	0 => 'Anyrole',
	1 => 'Fist-healer',
	2 => 'Blood-healer',
	3 => 'Leech/Riffle Heal',
	4 => 'Tank',
	5 => 'Buff-Tank',
	6 => 'Heal-Tank',
	7 => 'Leech-Tank',
	8 => 'DA/BS-Buffs',
	9 => 'Full-DPS',
	10 => 'SF-Buff',
	11 => 'Melee',
	12 => 'MeleeVul',
	13 => 'RangedVul',
	14 => 'MagicVul',
	),
	"lang" => array(
	"tsw" => 'The Secret World',
	"uc_race" => 'Faction',
	"uc_class" => 'prefered Class',
	"uc_faction" => 'Faction',
	"uc_cat_misc" => 'miscellaneous',
	"uc_pvp" => 'PVP Battleground',
	"uc_pvp_help" => 'Battlegroup is Serverbound',
	"uc_RP" => 'Roleplayer',
	"uc_RP_help" => '',
	"uc_yes" => 'Yes',
	"uc_no" => 'No',
	"uc_unknown" => 'unknown',
	"uc_ED" => 'Eldorado',
	"uc_SH" => 'Stonehenge',
	"uc_ShB" => 'Shambala',
	"uc_BG" => 'Battlegroup',
	"uc_BG_A" => 'Fusang BG-A',
	"uc_BG_B" => 'Fusang BG-B',
	"uc_guild" => 'Cabal',
	"uc_level" => 'Effusionrating',
	"uc_testlive" => 'Access to Testlive',
	"uc_18h_Raid_cooldown" => '18h Raid Cooldown',
	"uc_wings" => 'Wing Colour',
	"uc_blue" => 'Blue',
	"uc_gold" => 'Golden',
	"uc_purple" => 'Purple',
	"uc_nowings" => 'none',
	"eidolon_elite" => 'Eidolon Elite',
	"ny_raid_elite" => 'New York Elite',
	"flappy_nm" => 'Flappy NM',
	"eidolon_nm" => 'Eidolon NM',
	"nyr_nm" => 'New York NM',
	"flappy_elite" => 'Flappy Elite',
	"core_sett_fs_gamesettings" => 'The Secret World Settings',
	"Heroic" => 'Heroic',
	"Epic" => 'Epic',
	"Rare" => 'Rare',
	"Normal" => 'Uncommon',
	"Other" => 'Common',
	"Augments" => 'Augment Resonator',
	"Signets" => 'Signets',
	"Event-Items" => 'Event-Items',
	"Clothes" => 'Clothes',
	"Emotes" => 'Emotes',
	"Token-Items" => 'Token-Items',
	"Material" => 'Material',
	"Others" => 'Others',
	),
	
);

?>