<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Russian	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:49
//File: games/wildstar/language/russian.php
//Source-Language: english

$russian_array = array( 
	"factions" => array(
	"exile" => 'Эксил',
	"dominion" => 'Доминион',
	),
	"classes" => array(
	0 => 'Неизвестно',
	1 => 'Воин',
	2 => 'Чарострел',
	3 => 'Сталкер',
	4 => 'Эспер',
	5 => 'Медик',
	6 => 'Инженер',
	),
	"races" => array(
	0 => 'Неизвестно',
	1 => 'Человек',
	2 => 'Кассиан',
	3 => 'Гранок',
	4 => 'Дракен',
	5 => 'Аурин',
	6 => 'Мехар',
	7 => 'Мордеш',
	8 => 'Чуа',
	),
	"roles" => array(
	1 => 'Лекарь',
	2 => 'Танк',
	3 => 'Боец',
	),
	"lang" => array(
	"wildstar" => 'Wildstar Online',
	"game_language" => 'Язык игры',
	"heavy" => 'Тяжёлая Броня',
	"medium" => 'Средняя броня',
	"light" => 'Лёгкая броня',
	"uc_path" => 'Путь',
	"uc_gender" => 'Пол',
	"uc_male" => 'Мужской',
	"uc_female" => 'Женский',
	"uc_guild" => 'Гильдия',
	"uc_race" => 'Раса',
	"uc_class" => 'Класс',
	"core_sett_fs_gamesettings" => 'Настройки Wildstar Online',
	"uc_faction" => 'Фракция',
	"uc_faction_help" => 'Выберите фракцию по умолчанию',
	"uc_path_0" => '-',
	"uc_path_1" => 'Исследователь',
	"uc_path_2" => 'Учёный',
	"uc_path_3" => 'Солдат',
	"uc_path_4" => 'Поселенец',
	"wildstar_event_warplots" => 'Арена (PVP)',
	"wildstar_event_adventure" => 'Приключения (5 человек)',
	),
	
);

?>