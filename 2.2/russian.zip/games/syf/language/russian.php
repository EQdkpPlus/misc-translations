<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Russian	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:49
//File: games/syf/language/russian.php
//Source-Language: english

$russian_array = array( 
	"classes" => array(
	0 => 'Неизвестно',
	1 => 'Алхимик',
	2 => 'Лучник',
	3 => 'Хранитель света',
	4 => 'Берсерк',
	5 => 'Кинетик',
	6 => 'Криомант',
	7 => 'Паладин',
	8 => 'Штурмовик',
	9 => 'Богатырь',
	10 => 'Монах',
	11 => 'Некромант',
	12 => 'Колдун',
	13 => 'Мастер теней',
	),
	"clans" => array(
	0 => 'Неизвестно',
	1 => 'Clan01',
	2 => 'Clan02',
	3 => 'Clan03',
	4 => 'Clan04',
	5 => 'Clan05',
	6 => 'Clan06',
	7 => 'Clan07',
	8 => 'Clan08',
	9 => 'Clan09',
	10 => 'Clan10',
	11 => 'Clan11',
	12 => 'Clan12',
	13 => 'Clan13',
	14 => 'Clan14',
	15 => 'Clan15',
	),
	"roles" => array(
	1 => 'Защита',
	2 => 'Кастер',
	3 => 'Поддержка',
	4 => 'Дальний бой',
	5 => 'Ближний бой',
	),
	"lang" => array(
	"syf" => 'Skyforge',
	"uc_gender" => 'Пол',
	"uc_male" => 'Мужской',
	"uc_female" => 'Женский',
	"uc_guild" => 'Пантеон',
	"uc_clan" => 'Клан',
	"uc_race" => 'Раса',
	"uc_class" => 'Класс',
	"uc_cat_misc" => 'Разное',
	"uc_yes" => 'Да',
	"uc_no" => 'Нет',
	"uc_unknown" => 'Неизвестно',
	"uc_level" => 'Престиж',
	"core_sett_fs_gamesettings" => 'Настройки Skyforge',
	"Heroic" => 'Героический',
	"Epic" => 'Эпический',
	"Rare" => 'Редкий',
	"Normal" => 'Необычний',
	"Other" => 'Обычный',
	),
	
);

?>