<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:50
//File: language/french/lang_mmode.php
//Source-Language: english

$lang = array( 
	"click2show" => '(cliquez pour afficher)',
	"maintenance_mode" => 'Mode Maintenance',
	"task_manager" => 'Gestionnaire de tâches',
	"admin_acp" => 'Panneau d\'administration',
	"activate_info" => '<h1>Activate Maintenance Mode</h1><br />With this maintenance tool, you can easily update your EQdkp and import Data from an older Version.<br />An Update or Import is only possible, if the maintenance mode is enabled and denies the Login of users to prevent Errors and Problems.<br /><br />Reason, shown to the users (not required):<br />',
	"activate_mmode" => 'Activer le mode maintenance',
	"deactivate_mmode" => 'Fermer le mode de maintenance',
	"leave_mmode" => 'Annuler',
	"home" => 'Accueil',
	"no_leave" => 'Impossible de désactiver le mode de maintenance tant que des tâches doivent être exécutées.',
	"no_leave_accept" => 'Retour à la liste des tâches',
	"maintenance_message" => '<b>The EQdkp Plus-system is currently running in maintenance mode.</b> A login actually is only possible for administrators.',
	"reason" => '<br /><b>Reason:</b> ',
	"admin_login" => 'Connexion Administrateur',
	"login" => 'Connexion',
	"username" => 'Utilisateur',
	"password" => 'Mot de passe',
	"remember_password" => 'Se souvenir du mot de passe ?',
	"invalid_login_warning" => 'Erreur lors de la connexion ! Veuillez vérifier votre nom d\'utilisateur et votre mot de passe. Seuls les administrateurs peuvent se connecter !',
	"is_necessary" => 'Obligatoire ?',
	"is_applicable" => 'Applicable ? ',
	"name" => 'Nom',
	"version" => 'Version',
	"author" => 'Auteur',
	"link" => 'Exécuter la tâche',
	"description" => 'Description',
	"type" => 'Type de tâche',
	"yes" => 'Oui',
	"no" => 'Non',
	"click_me" => 'Exécuter la tâche',
	"mmode_info" => 'Votre système est actuellement en mode de maintenance, les connexions des utilisateurs normaux sont rejetées tant que ce mode est actif.',
	"necessary_tasks" => 'Opérations nécessaires',
	"applicable_tasks" => 'Not necessary/already processed tasks',
	"not_applicable_tasks" => 'Opérations inapplicables',
	"no_nec_tasks" => 'Aucune opération n\'est nécessaire',
	"nec_tasks" => 'Les tâches suivantes sont nécessaires. Veuillez les soumettre pour maintenir votre système à jour.',
	"nec_tasks_available" => 'Merci de soumettre les tâches nécessaires à la mise à jour de votre système.',
	"applicable_warning" => 'Cette tâche n\'est pas applicable. Son exécution peut provoquer des pertes de données. Ne la lancez que si vous êtes absolument sûr de ce que vous faites.',
	"executed_tasks" => 'Les opérations suivantes ont été réalisées pour la tâche "%s"',
	"stepend_info" => 'La tâche est terminée. EQDKP Plus est toujours en mode de maintenance ce qui vous permet de tout tester tranquillement. Les utilisateurs ne pourront à nouveau se connecter que lorsque ce mode sera fermé.',
	"mmode_pfh_error" => 'Des erreurs se sont produites. Vous devez corriger ces erreurs pour pouvoir fermer le mode de maintenance.',
	"lib_cache_notwriteable" => 'Ecriture impossible dans le répertoire "data". Veuillez lui attribuer les permissions CHMOD 777.',
	"pfh_safemode_error" => 'Le mode de sécurité de PHP est activé. EQdkp Plus ne peut pas fonctionner correctement dans ce mode car toutes les fonctions d\'écriture ne sont pas disponibles.',
	"spl_autoload_register_notavailable" => 'Impossible de trouver la fonction PHP "spl_autoload_register". Il est fort probable que vous utilisiez les services d\'un hébergeur gratuit qui ne propose pas cette fonction.',
	"fix" => 'Réparer',
	"update" => 'Update',
	"import" => 'Importer',
	"plugin_update" => 'Mise à jour des Plugins',
	"unknown_task_warning" => 'Tâche inconnue !',
	"application_warning" => 'Une erreur d\'application empêche de traiter la tâche !',
	"dependency_warning" => 'Cette tâche est dépendante d\'autres. Exécutez-les en premier !',
	"start_here" => 'Commencez ici !',
	"following_updates_necessary" => 'Les mises à jour suivantes sont nécessaires:',
	"start_update" => 'Exécutez toutes les mises à jour nécessaires !',
	"only_this_update" => 'N\'exécuter que cette mise à jour:',
	"start_single_update" => 'Exécuter la mise à jour',
	"splash_welcome" => 'Bienvenue dans la zone de maintenance du système EQdkp Plus !',
	"splash_desc" => 'Ici vous pouvez mettre à jour EQdkp Plus et en importer une version précédente.',
	"splash_new" => 'You are new to EQdkp Plus? You have never awarded DKP points or added raids?',
	"start_tour" => 'Commencer la visite',
	"jump_tour" => 'Passer la visite',
	"guild_import" => 'Importer une guilde à partir d\'une base de données externe',
	"guild_import_info" => '* Si supporté par votre jeu',
	
);

?>