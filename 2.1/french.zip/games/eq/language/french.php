<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:50
//File: games/eq/language/french.php
//Source-Language: english

$french_array = array( 
	"classes" => array(
	0 => 'Inconnue',
	1 => 'Barde',
	2 => 'Maître-Faune',
	3 => 'Berserker',
	15 => 'Clerc',
	16 => 'Druide',
	4 => 'Enchanteur',
	5 => 'Magicien',
	6 => 'Moine',
	7 => 'Nécromancien',
	8 => 'Paladin',
	9 => 'Scout',
	10 => 'Voleur',
	11 => '
	Chevalier de l\'ombre ',
	12 => 'Shamane',
	13 => 'Guerrier',
	14 => 'Sorcier',
	),
	"races" => array(
	0 => 'Inconnue',
	3 => 'Barbare',
	6 => 'Elfe des Ombres',
	16 => 'Drakkin',
	4 => 'Nain',
	14 => 'Erudite',
	12 => 'Froglok',
	1 => 'Gnome',
	15 => 'Petit-Gen',
	8 => 'Demi-Elfe',
	5 => 'Haut-Elfe',
	2 => 'Humain',
	13 => 'Iksar',
	11 => 'Ogre',
	10 => 'Troll',
	9 => 'Vah Shir',
	7 => 'Elfe des Bois',
	),
	"lang" => array(
	"eq" => 'EverQuest',
	"tank" => 'Tank',
	"melee" => 'Corps à corps',
	"priest" => 'Prêtre',
	"caster" => 'Distant',
	"uc_race" => 'Race',
	"uc_class" => 'Classe',
	"uc_guild" => 'Guilde',
	"uc_gender" => 'Genre',
	"uc_level" => 'Niveau',
	"uc_male" => 'Mâle',
	"uc_female" => 'Femelle',
	"core_sett_fs_gamesettings" => 'Réglages d\'EverQuest',
	"uc_faction" => 'Faction',
	"uc_faction_help" => 'Choisissez la faction par défaut',
	),
	
);

?>