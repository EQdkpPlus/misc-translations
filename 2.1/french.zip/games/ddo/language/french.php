<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:50
//File: games/ddo/language/french.php
//Source-Language: english

$french_array = array( 
	"classes" => array(
	0 => 'Inconnue',
	1 => 'Artificier',
	2 => 'Barbare',
	3 => 'Barde',
	4 => 'Prêtre',
	5 => 'Élu Divin',
	6 => 'Guerrier',
	7 => 'Moine',
	8 => 'Paladin',
	9 => 'Ranger',
	10 => 'Voleur',
	11 => 'Ensorceleur',
	12 => 'Magicien',
	),
	"races" => array(
	0 => 'Inconnue',
	1 => 'Drow',
	2 => 'Nain',
	3 => 'Elfe',
	4 => 'Demi-Elfe',
	5 => 'Halfelin',
	6 => 'Demi-Orc',
	7 => 'Humain',
	8 => 'Forgelier',
	9 => 'Défenseur d\'Acier',
	),
	"lang" => array(
	"ddo" => 'Dungeons & Dragons Online',
	"tank" => 'Tank',
	"damage_dealer" => 'Dégât',
	"support" => 'Soutien',
	"healer" => 'Guérisseur',
	"uc_gender" => 'Sexe',
	"uc_male" => 'Mâle',
	"uc_female" => 'Femelle',
	"uc_guild" => 'Guilde',
	"uc_class_path" => 'Voies',
	"uc_race" => 'Race',
	"uc_class" => 'Classe',
	"uc_path_0" => '-',
	"uc_path_1" => 'Angel of Vengeance',
	"uc_path_2" => 'Arcane Archer',
	"uc_path_3" => 'Arcane Cannon',
	"uc_path_4" => 'Bastion of the Outlands',
	"uc_path_5" => 'Beacon of Hope',
	"uc_path_6" => 'Deepwood Sniper',
	"uc_path_7" => 'Divine Avenger',
	"uc_path_8" => 'Elementalist',
	"uc_path_9" => 'Henshin Mystic',
	"uc_path_10" => 'Master Mechanic',
	"uc_path_11" => 'Mastermaker',
	"uc_path_12" => 'Necromancer',
	"uc_path_13" => 'Ninja Spy',
	"uc_path_14" => 'Runic Champion',
	"uc_path_15" => 'Savage of the Wild',
	"uc_path_16" => 'Scourge of the Undead',
	"uc_path_17" => 'Shintao Monk 	
',
	"uc_path_18" => 'Spellsinger',
	"uc_path_19" => 'Stalwart Soldier',
	"uc_path_20" => 'Storm of Kargon',
	"uc_path_21" => 'Tempest',
	"uc_path_22" => 'The Dark Blade',
	"uc_path_23" => 'The Dynamic Hand',
	"uc_path_24" => 'The Flame of Justice',
	"uc_path_25" => 'The Font of Healing',
	"uc_path_26" => 'The Ingenious Sage',
	"uc_path_27" => 'The Mighty Protector',
	"uc_path_28" => 'The Path of Light',
	"uc_path_29" => 'The Path of Shadow',
	"uc_path_30" => 'The Truthbringer',
	"uc_path_31" => 'The Voice of Power',
	"uc_path_32" => 'Thief Acrobat',
	"uc_path_33" => 'Two-headed Heron',
	"uc_path_34" => 'Vanguard Warrior',
	"uc_path_35" => 'Virtuoso of the Sword',
	"uc_path_36" => 'War Chanter',
	"uc_path_37" => 'Warpriest of Siberys',
	"uc_path_38" => 'Whirlwind Fighter',
	),
	
);

?>