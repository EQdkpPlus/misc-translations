<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:50
//File: games/ffxiv/language/french.php
//Source-Language: english

$french_array = array( 
	"classes" => array(
	0 => 'Inconnu',
	1 => 'Blackmage',
	2 => 'Guerrier',
	3 => 'Chevalier Dragon',
	4 => 'Moine',
	5 => 'Paladin',
	6 => 'Barde',
	7 => 'Whitemage',
	8 => 'Invocateur',
	9 => 'Erudit',
	10 => 'Ninja',
	11 => 'Chevalier noir',
	12 => 'Astrologue',
	13 => 'Machiniste',
	),
	"races" => array(
	0 => 'Inconnu',
	1 => 'Elézen',
	2 => 'Roegadyn',
	3 => 'Hyur',
	4 => 'Miqo\'te',
	5 => 'Lalafell',
	6 => 'Ao Ra',
	),
	"factions" => array(
	"gridania" => 'Gridania',
	"limsa" => 'Limsa Lominsa',
	"uldah" => 'Ul\'dah',
	),
	"lang" => array(
	"ffxiv" => 'Final Fantasy XIV',
	"tank" => 'Tank',
	"support" => 'Guérisseur',
	"damage_dealer" => 'DPS',
	"uc_gender" => 'Sexe',
	"uc_male" => 'Masculin',
	"uc_female" => 'Féminin',
	"uc_guild" => 'Guilde',
	"uc_race" => 'Race',
	"uc_class" => 'Classe',
	"core_sett_fs_gamesettings" => 'Réglages de Final Fantasy XI',
	"uc_faction" => 'Faction',
	"uc_faction_help" => 'Choisissez la faction par défaut',
	),
	
);

?>