<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:50
//File: plugins/raidlogimport/language/french/wow_lang.php
//Source-Language: english

$lang = array( 
	"difficulty" => 'Difficulté',
	"title_difficulty" => 'Options de difficulté',
	"diff_0" => 'autre',
	"diff_1" => 'normal',
	"diff_2" => 'héroïque',
	"diff_3" => 'Normal 10 joueurs',
	"diff_4" => 'Normal 25 joueurs',
	"diff_5" => 'Héroïque 10 joueurs',
	"diff_6" => 'Héroïque 25 joueurs',
	"diff_7" => 'LFR',
	"diff_8" => 'Mode Défi',
	"diff_9" => '40 joueurs',
	"diff_11" => 'Héroïque',
	"diff_12" => 'Normal',
	"diff_14" => 'Normal (10-30 joueurs)',
	"diff_15" => 'Héroïque (10-30 joueurs)',
	"diff_16" => 'Mythique (20 joueurs)',
	"dep_match" => 'Le suffixe doit-il également être appliqué aux notes de boss ?',
	
);

?>