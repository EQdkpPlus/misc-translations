<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:50
//File: plugins/guildbank/language/french/lang_main.php
//Source-Language: english

$lang = array( 
	"guildbank" => 'Banque de guilde',
	"guildbank_short_desc" => 'Gérer les objets et transactions des banquiers de guilde',
	"guildbank_long_desc" => 'Banque de guilde est un Plugin de gestion des objets de raid.',
	"guildbank_not_installed" => 'Banque de guilde n\'est pas installé.',
	"gb_a_perm_auctions" => 'Gérer les enchères',
	"gb_u_perm_auction" => 'Placer des enchères',
	"gb_perm_shop" => 'Acheter des objets',
	"gb_mainmenu_guildbank" => 'Banque de guilde',
	"gb_adminmenu_guildbank" => 'Banque de guilde',
	"gb_banker" => 'Banquier',
	"gb_shop" => 'Boutique',
	"gb_not_avail" => ' n/d',
	"gb_all_bankers" => 'Tous les banquiers',
	"gb_total_bankers" => 'Actif de tous les banquiers',
	"gb_bankchar_name" => 'Banquier',
	"gb_no_bankchar" => 'Aucun',
	"gb_update" => 'Activité récente',
	"gb_tab_transactions" => 'Transactions',
	"gb_tab_items" => 'Objets',
	"gb_tab_auctions" => 'Enchères',
	"gb_title_page" => 'Banque de guilde',
	"gb_shop_window" => 'Achat d\'objet',
	"gb_shop_icon_title" => 'Achat d\'objet',
	"gb_shop_buy" => 'Acheter',
	"gb_item_name" => 'Objet',
	"gb_item_value" => 'Prix d\'achat (DKP)',
	"gb_item_value_money" => 'Prix d\'achat (Monnaie)',
	"gb_itemcost" => 'Coût',
	"gb_item_date" => 'Date d\'achat',
	"gb_dkppool" => 'Groupe MultiDKP',
	"gb_default_note" => 'Aucune remarque disponible',
	"gb_shop_error_nodkp" => 'DKP insuffisants pour acheter cet objet.',
	"gb_shop_error_noitem" => 'Aucun objet en vente',
	"gb_shop_error_noselection" => 'Vous n\'avez pas indiqué la quantité à acheter.',
	"gb_shop_buy_subject" => 'Objet reçu',
	"gb_shop_buy_successmsg" => 'L\'option d\'achat de cet objet est pris en compte. La transaction sera finalisée et imputée à votre compte par un administrateur.',
	"gb_confirm_shop_ta_head" => 'Objets achetés à la banque de guilde',
	"gb_confirm_shop_ta_button" => 'Confirmer la vente',
	"gb_decline_shop_ta_button" => 'Refuser la vente',
	"gb_confirm_msg_success" => 'La transaction a bien été confirmée',
	"gb_confirm_msg_delete" => 'La transaction a été refusée',
	"gb_notify_shopta_header" => 'Partager les objets achetés',
	"gb_notify_shopta_confirm_req1" => 'Un achat est en attente de confirmation',
	"gb_notify_shopta_confirm_req2" => '%s achats sont en attente de confirmation',
	"gb_no_item_id_missing" => 'L\'ID de l\'objet est manquant. Veuillez réessayer.',
	"gb_manage_auctions" => 'Gestion des enchères',
	"gb_auction_management" => 'Gestion des enchères',
	"gb_auction_head_add" => 'Ajouter une enchère',
	"gb_auction_head_edit" => 'Modifier une enchère',
	"gb_footer_auction" => '... %1$d auction(s) found / %2$d per page',
	"gb_add_auction" => 'Créer une enchère',
	"gb_delete_auctions" => 'Supprimer les objets sélectionnés',
	"gb_add_auction_title" => 'Ajouter une enchère',
	"gb_edit_auction_title" => 'Modifier une enchère',
	"gb_auction_item" => 'Objet',
	"gb_auction_item_help" => 'Choisissez un ou plusieurs objets. Une enchère sera créée pour chacun des objets.',
	"gb_auction_startdate" => 'Heure de début',
	"gb_auction_duration" => 'Durée de l\'enchère',
	"gb_auction_duration_help" => 'Durée de l\'enchère en heures',
	"gb_auction_startvalue" => 'Valeur de mise à prix',
	"gb_auction_bidsteps" => 'Pas d\'enchère',
	"gb_auction_bidsteps_help" => 'Valeur de l\'incrément d\'une enchère sur l\'objet',
	"gb_auction_raidatt" => 'Raid participant à l\'enchère',
	"gb_auction_raidatt_help" => 'Nombre de participants au raid dans lequel l\'objet est tombé. Si c\'est 0 tout le monde pourra faire une offre sur l\'objet.',
	"gb_confirm_delete_auctions" => 'Etes-vous sur de vouloir supprimer cette ou ces enchères %s ?',
	"gb_auction_multidkppool" => 'Groupe MultiDKP',
	"gb_auction_multidkppool_help" => 'Saisissez le groupe MultiDKP dont les points doivent être utilisés pour les enchères.',
	"gb_auction_icon_title" => 'Enchérir',
	"gb_auction_window" => 'Enchères',
	"gb_auction_title" => 'Mise en vente & enchères',
	"gb_button_bid" => 'Enchérir',
	"gb_error_noidnotloggedin" => 'ATTENTION: Pour utiliser les enchères, vous devez être connecté(e) et utiliser une ID enchère valide. Essayez à nouveau.',
	"gb_auction_avail_dkp" => 'Crédits disponibles',
	"gb_auction_timeleft" => 'Temps restant',
	"gb_auction_bid_info" => 'Enchérir',
	"gb_bids_footcount" => '... %1$d Bid(s) / %2$d per page',
	"gb_bids_loading" => 'Chargement...',
	"gb_bids_auctionended" => 'Terminée',
	"gb_bids_nobids" => 'Aucune enchère',
	"gb_manage_bankers" => 'Gestion des banquiers',
	"gb_confirm_delete_bankers" => 'Supprimer le(s) banquier(s) %s ?',
	"gb_banker_mainchar" => 'Personnage bancaire',
	"gb_money" => 'Crédits',
	"gb_manage_bank_items_title" => 'Modifier un objet du banquier \'%s\'',
	"gb_manage_bank_items" => 'Modifier les objets de la banque',
	"gb_mode" => 'Mode',
	"gb_a_mode" => array(
	0 => 'Objet',
	1 => 'Transaction',
	),
	"gb_subject" => 'Utilisation',
	"gb_members" => 'Bénéficiaire',
	"gb_manage_bank_transa" => 'Gestion des transactions',
	"gb_title_transaction" => 'Gestion des transactions',
	"gb_title_item" => 'Gestion des objets',
	"gb_item_added" => 'Objet ajouté',
	"gb_item_payout" => 'objet(s) payé(s)',
	"gb_payout_item" => 'Distribuer l\'objet',
	"add_transaction" => 'Ajouter la transaction',
	"gb_adjustment_text" => 'Banque de guilde - L\'objet a été acheté',
	"gb_item_sellable" => 'Mettre en vente',
	"gb_itemvalue" => 'Valeur de l\'objet',
	"gb_manage_banker" => 'Gestion des banquiers',
	"gb_add_item_title" => 'Ajouter un objet au compte bancaire',
	"gb_edit_item_title" => 'Editer l\'objet',
	"gb_rarity" => 'Niveau de l\'objet',
	"gb_type" => 'Type de l\'objet',
	"gb_dkp" => 'DKP',
	"gb_amount" => 'Quantité',
	"gb_additem_button" => 'Sauvegarder l\'objet',
	"gb_payout_button" => 'Remboursement',
	"gb_addtrans_button" => 'Enregistrer la transaction ',
	"gb_ta_head_transaction" => 'Gérer la transaction',
	"gb_ta_head_payout" => 'Remboursement',
	"gb_ta_head_item" => 'Gérer l\'objet',
	"gb_banker_added" => 'Banquier ajouté',
	"gb_header_global" => 'Paramètre de la banque de guilde',
	"gb_breadcrumb_settings" => 'Banque de guilde: Paramètres',
	"gb_saved" => 'Les paramètres ont été sauvegardés avec succès',
	"gb_fs_banker_display" => 'Paramètres d\'affichage de Guildbank',
	"gb_f_show_money" => 'Afficher les actifs bancaire',
	"gb_f_help_show_money" => 'Afficher les actifs bancaire (si désactivé : l\'argent ne sera pas affiché)',
	"gb_f_merge_bankers" => 'Combiner tous les banquiers',
	"gb_f_help_merge_bankers" => 'Combiner tous les banquiers en une seul banque',
	"gb_fs_itemshop" => 'Transactions d\'objets',
	"gb_f_use_autoadjust" => 'Ajouter un ajustement automatique pour tous les objets vendu',
	"gb_f_help_use_autoadjust" => 'Une correction automatique doit-elle être appliquée à chaque transaction ?',
	"gb_f_default_event" => 'Evènement par défaut pour les ajustements',
	"gb_f_help_default_event" => 'Si vous voulez utiliser un ajustement automatique, vous devez paramétrer un évenement par défaut',
	"gb_filter_banker" => 'Choisir le Banquier',
	"gb_filter_type" => 'Choisir le type de l\'objet',
	"gb_filter_rarity" => 'Choisir le niveau de l\'objet',
	"gb_a_type" => array(
	"quest" => 'Quète',
	"weapon" => 'Armes',
	"reagent" => 'Réactif',
	"builder" => 'Fabriqué',
	"armor" => 'Armure',
	"key" => 'Clé',
	"useable" => 'Ingrédient',
	"misc" => 'Autres',
	),
	"gb_a_rarity" => array(
	5 => 'Légendaire',
	4 => 'Epique',
	3 => 'Rare',
	2 => 'Normale',
	1 => 'Autre',
	),
	"gb_currency" => array(
	"platin" => 'Platine',
	"platin_s" => 'P',
	"gold" => 'Or',
	"gold_s" => 'O',
	"silver" => 'Argent',
	"silver_s" => 'A',
	"copper" => 'Cuivre',
	"copper_s" => 'C',
	"diamond" => 'Diamant',
	"diamond_s" => 'D',
	),
	"gb_credits" => 'Banque de guilde %s',
	
);

?>