<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:50
//File: plugins/cmsimport/language/french/lang_main.php
//Source-Language: english

$lang = array( 
	"cmsimport" => 'CMS-Import',
	"cmsimport_short_desc" => 'Importe les données provenant d\'autres CMS',
	"cmsimport_long_desc" => 'Importe les données provenant d\'autres CMS tels que Wordpress ou Joomla.',
	"ci_plugin_not_installed" => 'Le plugin CMS-Import n\'est pas installé.',
	"ci_import" => 'Importer',
	"ci_continue" => 'Continuer',
	"ci_db_types" => array(
	0 => 'Même base de données',
	1 => 'Autre base de données',
	2 => 'Utiliser une passerelle de connexion',
	),
	"ci_fs_general" => 'Importer les paramètres',
	"ci_f_import_type" => 'Choisir l\'importateur',
	"ci_f_url" => 'URL de votre CMS',
	"ci_f_help_url" => 'URL complète de votre CMS incluant son protocole',
	"ci_fs_connection" => 'Paramètres de connexion',
	"ci_f_db_type" => 'Indiquez comment se connecter au CMS',
	"ci_f_db_host" => 'Serveur de la base de données',
	"ci_f_db_user" => 'Utilisateur de la base de données',
	"ci_f_db_password" => 'Mot de passe de la base de données',
	"ci_f_db_database" => 'Nom de la base de données',
	"ci_f_db_prefix" => 'Préfixe d\'installation',
	"ci_f_help_db_prefix" => 'Le préfixe de l\'installation principale d\'EQdkp Plus, ex:"eqdkp20_"',
	"ci_conn_error" => 'Connexion au CMS impossible. Veuillez vérifier vos paramètres.',
	"ci_select_steps" => 'Choisir les étapes',
	"ci_select_all_steps" => 'Choisir toutes les étapes',
	"ci_step" => 'Étape',
	"ci_import_error" => 'Une erreur est survenue durant l\'importation. Veuillez essayer à nouveau.',
	"ci_step_user" => 'Utilisateur',
	"ci_step_pages" => 'Pages',
	"ci_step_posts" => 'Messages',
	"ci_step_categories" => 'Catégories',
	"ci_user_import_hint" => 'Please note that only the users are imported, but no mapping to usergroups. The users are added to the default group.<br /><br />Note also that the passwords cannot be imported, therefore the user should request a new password, if no CMS-Bridge is used.',
	"ci_imported_users" => 'Utilisateurs importés',
	"ci_imported_pages" => 'Pages importées',
	"ci_imported_posts" => 'Messages importés
',
	"ci_imported_categories" => 'Catégories importées',
	"ci_end_message" => 'L\'importation est terminée. Merci de vérifier les permissions des objets importés.',
	"ci_default_user_pages" => 'Choisir un utilisateur pour les articles qui n\'en ont pas',
	"ci_default_category_posts" => 'Choisir la catégorie des messages importés',
	"ci_default_category_pages" => 'Choisir la catégorie des pages importées',
	
);

?>