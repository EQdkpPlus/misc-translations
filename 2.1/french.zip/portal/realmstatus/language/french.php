<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:50
//File: portal/realmstatus/language/french.php
//Source-Language: english

$lang = array( 
	"realmstatus" => 'Etat du royaume',
	"realmstatus_name" => 'Etat du royaume',
	"realmstatus_desc" => 'Afficher l\'état actuel du Royaume',
	"realmstatus_f_realm" => 'Liste des serveurs',
	"realmstatus_f_help_realm" => 'Les serveurs multiples devront être séparés par une virgule.',
	"realmstatus_f_us" => 'Serveur US ?',
	"realmstatus_f_help_us" => 'Ce paramètre n\'a d\'effet que pour les jeux RIFT et WoW.',
	"realmstatus_f_gd" => 'Lib GD (%s) trouvée. Voulez-vous l\'utliser ?',
	"realmstatus_f_help_gd" => 'Ce paramètre n\'a d\'effet que pour WoW.',
	"rs_no_realmname" => 'Aucun Royaume n\'a été spécifié',
	"rs_realm_not_found" => 'Royaume non trouvé.',
	"rs_game_not_supported" => 'Ce module ne fonctionne pas pour le jeu indiqué',
	"rs_unknown" => 'Inconnu',
	"rs_realm_status_error" => 'Des erreurs sont survenues pendant la détermination de l\'état du Royaume %1$s',
	"rs_loading" => 'Chargement de l\'état...',
	"rs_loading_error" => 'Etat impossible à charger',
	
);

?>