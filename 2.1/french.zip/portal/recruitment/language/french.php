<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:50
//File: portal/recruitment/language/french.php
//Source-Language: english

$lang = array( 
	"recruitment" => 'Recrutement',
	"recruitment_name" => 'Recrutement',
	"recruitment_desc" => 'Recherche de Membres',
	"recruitment_open" => 'Nous recherchons',
	"recruitment_contact" => 'Postuler',
	"recruitment_noneed" => 'Aucune place n\'est disponible actuellement',
	"recruitment_f_url" => 'URL de recrutement',
	"recruitment_f_help_url" => 'Saisissez l\'URL de votre outil de recrutement. S\'il n\'y en a pas, le module insérera le mail de contact d\'EQdkpPlus.',
	"recruitment_f_embed" => 'Type d\'ouverture de l\'URL',
	"recruitment_f_help_embed" => 'Choisissez comment l\'URL insérée doit s\'ouvrir.',
	"recruitment_f_priority" => 'Utiliser les priorités au lieu de nombres ?',
	"pm_recruitment_talentsorroles" => 'Talents ou rôles ?',
	"pm_recruitment_talents" => 'Talents',
	"pm_recruitment_roles" => 'Rôles',
	"recruitment_f_layout" => 'Mise en page',
	"recruitment_f_2columns" => 'Présentation sur deux colonnes',
	"recruit_priority_high" => 'Elevé',
	"recruit_priority_middle" => 'Moyen',
	"recruit_priority_low" => 'Faible',
	"recruitment_f_text" => 'Informations',
	
);

?>