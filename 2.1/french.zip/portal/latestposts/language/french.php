<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:50
//File: portal/latestposts/language/french.php
//Source-Language: english

$lang = array( 
	"latestposts" => 'Derniers messages du forum',
	"latestposts_name" => 'Derniers messages du forum',
	"latestposts_desc" => 'Affiche les derniers messages de votre forum.',
	"portal_latestposts_nomodule" => 'Aucun module de forum sélectionné. Merci d\'ouvrir les paramètres des modules et de le configurer.',
	"portal_latestposts_invmodule" => 'Mauvais module BB.',
	"portal_latestposts_noselectedboards" => 'Aucun forum n\'a été sélectionné pour être affiché.',
	"latestposts_f_bbmodule" => 'Module de forum',
	"latestposts_f_dbmode" => 'Sélectionner le mode de connexion de la base de données',
	"latestposts_f_help_dbmode" => 'Les informations de connexion de la base de données ne sont nécessaires que si vous avez choisi "Autre base de données qu\'EQDKP"',
	"latestposts_dbmode_same" => 'Le forum est dans la même base de données qu\'EQDKP.',
	"latestposts_dbmode_new" => 'Le forum est dans une autre base de données qu\'EQDKP',
	"latestposts_dbmode_bridge" => 'Utiliser les paramètres de connexion de la passerelle.',
	"latestposts_f_dbname" => 'Base de données',
	"latestposts_f_dbuser" => 'Utilisateur',
	"latestposts_f_dbpassword" => 'Mot de passe',
	"latestposts_f_dbhost" => 'Hôte',
	"latestposts_f_dbprefix" => 'Préfixe',
	"latestposts_f_url" => 'URL du forum',
	"latestposts_f_amount" => 'Afficher les x dernières entrées.',
	"latestposts_f_trimtitle" => 'Tronquer les titres longs à x caractères',
	"latestposts_f_help_trimtitle" => 'Only when in left/right Module block',
	"latestposts_f_linktype" => 'Comment les liens vers les sujets doivent-ils s\'ouvrir ?',
	"latestposts_f_blackwhitelist" => 'Liste noire ou blanche',
	"latestposts_f_help_blackwhitelist" => 'Rejeter les ID de forum indiqués (liste noire) ou les accepter (liste blanche)',
	"latestposts_f_privateforums" => 'Black-/Whitelist for Usergroup: ',
	"latestposts_f_help_privateforums" => 'Insert here the forum IDs used by Black-/Whitelist, seperated by commas',
	"latestposts_f_help_privateforums2" => 'Select the forums for the shown usergroup used by Black-/Whitelist',
	"latestposts_noentries" => 'Aucune entrée disponible',
	"latestposts_connerror" => 'Erreur de connexion',
	"latestposts_lastpost" => 'Dernière réponse',
	"latestposts_starter" => 'Débuté par:',
	"latestposts_posts" => 'Réponses',
	"latestposts_title" => 'Sujet',
	"latestposts_forum" => 'Forum',
	"latestposts_display_normal" => 'Normal',
	"latestposts_display_accordion" => 'Accordéon',
	"latestposts_f_showcontent" => 'Apperçu',
	"latestposts_f_style" => 'Affichage',
	
);

?>