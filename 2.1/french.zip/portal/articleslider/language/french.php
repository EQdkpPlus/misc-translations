<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:50
//File: portal/articleslider/language/french.php
//Source-Language: english

$lang = array( 
	"articleslider" => 'Slider d\'articles',
	"articleslider_name" => 'Slider d\'articles',
	"articleslider_desc" => 'Affiche une image dans laquelle défilent les articles vedettes',
	"articleslider_f_categories" => 'Catégories d\'articles',
	"articleslider_f_help_categories" => 'Catégories dont il faudra afficher les articles vedettes.',
	"articleslider_f_maxitems" => 'Nombre maximum d\'articles à afficher',
	"articleslider_f_height" => 'Hauteur maximum du Slider',
	"articleslider_f_help_height" => 'Exprimée en pixels',
	"articleslider_f_width" => 'Largeur maximum du Slider',
	"articleslider_f_help_width" => 'Exprimée en pixels. Laissez vide pour occuper toute la largeur.',
	"articleslider_f_auto" => 'Défilement automatique',
	"articleslider_f_timeout" => 'Durée entre chaque défilement (millisecondes)',
	"articleslider_f_wordcount" => 'Nombre de mots dans l’aperçu du texte',
	
);

?>