<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:50
//File: core/data_handler/includes/modules/read/calendar_raids_attendees/language/french.php
//Source-Language: english

$module_lang = array(
	"html_status" => '',
	"html_calstat_lastraid" => 'RCS - Dernier raid',
	"html_calstat_raids_confirmed" => 'Participant',
	"html_calstat_raids_signedin" => 'Inscrit',
	"html_calstat_raids_signedoff" => 'Indisponible',
	"html_calstat_raids_backup" => 'Réserve',
	"calstat_raids_confirmed_fromto" => 'Participants',
	"calstat_raids_signedin_fromto" => 'Inscrits',
	"calstat_raids_signedoff_fromto" => 'Indisponibles',
	"calstat_raids_backup_fromto" => 'Réserve',
	"calstat_raids_total_fromto" => 'Total',
	);
	$preset_lang = array(
	"raidattendees_status" => 'Statut de participation aux raids du calendrier',
	"raidcalstats_lastraid" => 'Stats-Calendrier-Dernier Raid',
	"raidcalstats_raids_confirmed_90" => 'Stats-Calendrier-Derniers Raids (90 jours)',
	"raidcalstats_raids_signedin_90" => 'Stats-Calendrier-Raids Inscrits (90 jours)',
	"raidcalstats_raids_signedoff_90" => 'Stats-Calendrier-Raids Indisponibles (90 jours)',
	"raidcalstats_raids_backup_90" => 'Stats-Calendrier-Raids Réserve (90 jours)',
	"raidcalstats_raids_confirmed_60" => 'Stats-Calendrier-Raids Confirmés (60 jours)',
	"raidcalstats_raids_signedin_60" => 'Stats-Calendrier-Raids Inscrits (60 jours)',
	"raidcalstats_raids_signedoff_60" => 'Stats-Calendrier-Raids Indisponibles (60 jours)',
	"raidcalstats_raids_backup_60" => 'Stats-Calendrier-Raids Réserve (60 jours)',
	"raidcalstats_raids_confirmed_30" => 'Stats-Calendrier-Raids confirmés (30 jours)',
	"raidcalstats_raids_signedin_30" => 'Stats-Calendrier-Raids Inscrits (30 jours)',
	"raidcalstats_raids_signedoff_30" => 'Stats-Calendrier-Raids Indisponibles (30 jours)',
	"raidcalstats_raids_backup_30" => 'Stats-Calendrier-Raids Réserve (30 jours)',
	"raidcalstats_raids_confirmed_fromto" => 'Stats-Calendrier-Raids confirmés (jours def.)',
	"raidcalstats_raids_signedin_fromto" => 'Stats-Calendrier-Raids Inscrits (jours def.)',
	"raidcalstats_raids_signedoff_fromto" => 'Stats-Calendrier-Raids Indisponibles (jours def.)',
	"raidcalstats_raids_backup_fromto" => 'Stats-Calendrier-Raids Réserve (jours def.)',
	);
	

?>