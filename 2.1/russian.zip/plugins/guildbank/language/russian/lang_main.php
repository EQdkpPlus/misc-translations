<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Russian	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:50
//File: plugins/guildbank/language/russian/lang_main.php
//Source-Language: english

$lang = array( 
	"guildbank" => 'Банк гильдии',
	"guildbank_short_desc" => 'Управление предметами и транзакциями в общем банке гильдии',
	"guildbank_long_desc" => 'Guild bank is a Plugin to manage raiditems.',
	"guildbank_not_installed" => 'Guild bank is not installed.',
	"gb_a_perm_auctions" => 'Manage auctions',
	"gb_u_perm_auction" => 'Bid on auctions',
	"gb_perm_shop" => 'Buy items',
	"gb_mainmenu_guildbank" => 'Банк гильдии',
	"gb_adminmenu_guildbank" => 'Банк гильдии',
	"gb_banker" => 'Banker',
	"gb_shop" => 'Магазин',
	"gb_not_avail" => 'н/д',
	"gb_all_bankers" => 'Все банкиры',
	"gb_total_bankers" => 'Активы всех банкиров',
	"gb_bankchar_name" => 'Bank character',
	"gb_no_bankchar" => 'Нет',
	"gb_update" => 'Последняя активность',
	"gb_tab_transactions" => 'Транзакции',
	"gb_tab_items" => 'Предметы',
	"gb_tab_auctions" => 'Auction',
	"gb_title_page" => 'View guildbank',
	"gb_shop_window" => 'Купить предмет',
	"gb_shop_icon_title" => 'Купить предмет',
	"gb_shop_buy" => 'Купить',
	"gb_item_name" => 'Предмет',
	"gb_item_value" => 'Purchasing price (DKP)',
	"gb_item_value_money" => 'Purchasing price (Money)',
	"gb_itemcost" => 'Cost',
	"gb_item_date" => 'Purchasing date ',
	"gb_dkppool" => 'MultiDKP-Pool',
	"gb_default_note" => 'No note available',
	"gb_shop_error_nodkp" => 'There are not enough DKP to buy this item.',
	"gb_shop_error_noitem" => 'There is no item available to purchase.',
	"gb_shop_error_noselection" => 'You have not selected any amount of items to buy.',
	"gb_shop_buy_subject" => 'Item received',
	"gb_shop_buy_successmsg" => 'The item was flagged for shopping. The transaction will be made ​​after the confirmation by an admin and credited to your account',
	"gb_confirm_shop_ta_head" => 'Guild bank item purchases',
	"gb_confirm_shop_ta_button" => 'Confirm purchase',
	"gb_decline_shop_ta_button" => 'Decline purchase',
	"gb_confirm_msg_success" => 'The transaction was successfully completed',
	"gb_confirm_msg_delete" => 'The transaction was successfully declined',
	"gb_notify_shopta_header" => 'Share purchases item',
	"gb_notify_shopta_confirm_req1" => 'A purchase is waiting for release',
	"gb_notify_shopta_confirm_req2" => '%s purchases are waiting for release',
	"gb_no_item_id_missing" => 'The item-ID is missing. Please try again',
	"gb_manage_auctions" => 'Manage auctions',
	"gb_auction_management" => 'Auction management',
	"gb_auction_head_add" => 'Add auction',
	"gb_auction_head_edit" => 'Edit auction',
	"gb_footer_auction" => '... %1$d auction(s) found / %2$d per page',
	"gb_add_auction" => 'Create auction',
	"gb_delete_auctions" => 'Delete selected Items',
	"gb_add_auction_title" => 'Add auction',
	"gb_edit_auction_title" => 'Edit auction',
	"gb_auction_item" => 'Предмет',
	"gb_auction_item_help" => 'One or more items to auction off. For multiple choice multiple auctions are created',
	"gb_auction_startdate" => 'Start time',
	"gb_auction_duration" => 'auction duration',
	"gb_auction_duration_help" => 'The auction duration in hours',
	"gb_auction_startvalue" => 'Starting bid value',
	"gb_auction_bidsteps" => 'Bid increment',
	"gb_auction_bidsteps_help" => 'Bidders can bid on these increments to the object',
	"gb_auction_raidatt" => 'Raid participate to bid',
	"gb_auction_raidatt_help" => 'Number of Raid participate in which the relevant objects have fallen. At 0 anyone can offer on the item.',
	"gb_confirm_delete_auctions" => 'You are sure, do delete this auction(s) %s ?',
	"gb_auction_multidkppool" => 'Multidkp Pool',
	"gb_auction_multidkppool_help" => 'Enter a MultiDKP pool from which the points are to be used for bids.',
	"gb_auction_icon_title" => 'Bid',
	"gb_auction_window" => 'Auction',
	"gb_auction_title" => 'Auction & bidding',
	"gb_button_bid" => 'Bidding',
	"gb_error_noidnotloggedin" => 'ATTENTION: To use the auctions you have either logged in, also use as a valid auctionID. Lets try again.',
	"gb_auction_avail_dkp" => 'Available credits',
	"gb_auction_timeleft" => 'Remaining auctiontime',
	"gb_auction_bid_info" => 'Place a bid',
	"gb_bids_footcount" => '... %1$d Bid(s) / %2$d per page',
	"gb_bids_loading" => 'Loading...',
	"gb_bids_auctionended" => 'Ended',
	"gb_bids_nobids" => 'No bids',
	"gb_manage_bankers" => 'Manage guild bankers',
	"gb_confirm_delete_bankers" => 'Should the bankers are deleted?',
	"gb_banker_mainchar" => 'Служебный банковый персонаж',
	"gb_money" => 'Credits',
	"gb_manage_bank_items_title" => 'Edit item of bankers \'%s\'',
	"gb_manage_bank_items" => 'Edit bankitems',
	"gb_mode" => 'Режим',
	"gb_a_mode" => array(
	0 => 'Предмет',
	1 => 'Транзакция',
	),
	"gb_subject" => 'Application',
	"gb_members" => 'Получатель',
	"gb_manage_bank_transa" => 'Управление транзакциями',
	"gb_title_transaction" => 'Transaction management',
	"gb_title_item" => 'Item management',
	"gb_item_added" => 'Item added',
	"gb_item_payout" => 'Предмет оплачен',
	"gb_payout_item" => 'Оплатить предмет',
	"add_transaction" => 'Добавить транзакцию',
	"gb_adjustment_text" => 'Guild bank - Item was purchased ',
	"gb_item_sellable" => 'Доступен для продажи',
	"gb_itemvalue" => 'Item value',
	"gb_manage_banker" => 'Manage bankers',
	"gb_add_item_title" => 'Внести предмет на баланс банка',
	"gb_edit_item_title" => 'Изменить предмет',
	"gb_rarity" => 'Уровень',
	"gb_type" => 'Тип',
	"gb_dkp" => 'ДКП',
	"gb_amount" => 'Количество',
	"gb_additem_button" => 'Сохранить предмет',
	"gb_payout_button" => 'Оплатить предмет',
	"gb_addtrans_button" => 'Save transaction',
	"gb_ta_head_transaction" => 'Управление транзакцией',
	"gb_ta_head_payout" => 'Оплатить предмет',
	"gb_ta_head_item" => 'Изменить предмет',
	"gb_banker_added" => 'Banker added',
	"gb_header_global" => 'Настройки банка гильдии',
	"gb_breadcrumb_settings" => 'Guild bank: settings',
	"gb_saved" => 'Настройки успешно сохранены',
	"gb_fs_banker_display" => 'Guildbank display settings',
	"gb_f_show_money" => 'Показать активы',
	"gb_f_help_show_money" => 'Показать активы (при отключении не отображаются деньги)',
	"gb_f_merge_bankers" => 'Объединить банкиров',
	"gb_f_help_merge_bankers" => 'Объединить всех банкиров в единый список',
	"gb_fs_itemshop" => 'Item Transactions',
	"gb_f_use_autoadjust" => 'Добавить автоматическое изменение для проданных предметов',
	"gb_f_help_use_autoadjust" => 'Should be entered automatic corrections for each sold item?',
	"gb_f_default_event" => 'Событие по умолчанию для изменений',
	"gb_f_help_default_event" => 'Если вы хотите использовать автоматические коррекции, необходимо настроить событие по умолчанию',
	"gb_filter_banker" => 'Банкир',
	"gb_filter_type" => 'Тип предмета',
	"gb_filter_rarity" => 'Уровень предмета',
	"gb_a_type" => array(
	"quest" => 'Квест',
	"weapon" => 'Оружие',
	"reagent" => 'Реагент',
	"builder" => 'Крафт',
	"armor" => 'Броня',
	"key" => 'Ключ',
	"useable" => 'Расходуемый',
	"misc" => 'Другой',
	),
	"gb_a_rarity" => array(
	5 => 'Легендарный',
	4 => 'Эпический',
	3 => 'Редкий',
	2 => 'Обычный',
	1 => 'Другой',
	),
	"gb_currency" => array(
	"platin" => 'Platinum',
	"platin_s" => 'P',
	"gold" => 'Gold',
	"gold_s" => 'G',
	"silver" => 'Silver',
	"silver_s" => 'S',
	"copper" => 'Copper',
	"copper_s" => 'C',
	"diamond" => 'Diamond',
	"diamond_s" => 'D',
	),
	"gb_credits" => 'Банк гильдии %s',
	
);

?>