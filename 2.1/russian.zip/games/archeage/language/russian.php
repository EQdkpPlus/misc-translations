<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Russian	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:50
//File: games/archeage/language/russian.php
//Source-Language: english

$russian_array = array( 
	"classes" => array(
	0 => 'не указан',
	1 => 'Танки',
	2 => 'Хилеры',
	3 => 'Саппорты',
	4 => 'Мили',
	5 => 'Луки',
	),
	"races" => array(
	0 => 'не указан',
	1 => 'Нуиане',
	2 => 'Эльфы',
	3 => 'Харнийцы',
	4 => 'Ферре',
	),
	"lang" => array(
	"archeage" => 'ArcheAge',
	"uc_gender" => 'пол',
	"uc_male" => 'муржской',
	"uc_female" => 'женский',
	"uc_guild" => 'Гильдия',
	"uc_ability_1" => 'умения',
	"uc_ability_2" => 'умения',
	"uc_ability_3" => 'умения',
	"uc_race" => 'Раса',
	"uc_class" => 'Класс',
	"core_sett_fs_gamesettings" => 'Настройки ArcheAge',
	"uc_faction" => 'Фракция',
	"uc_faction_help" => 'Выберете фракцию по умолчанию',
	"uc_ab_0" => '-',
	"uc_ab_1" => 'Battlerage',
	"uc_ab_2" => 'Witchcraft',
	"uc_ab_3" => 'Defense',
	"uc_ab_4" => 'Auramancy',
	"uc_ab_5" => 'Occultism',
	"uc_ab_6" => 'Archery',
	"uc_ab_7" => 'Sorcery',
	"uc_ab_8" => 'Shadowplay',
	"uc_ab_9" => 'Songcraft',
	"uc_ab_10" => 'Vitalism',
	),
	
);

?>