<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Russian	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:50
//File: games/tsw/language/russian.php
//Source-Language: english

$russian_array = array( 
	"classes" => array(
	0 => 'Неизвестно',
	1 => 'Tank',
	2 => 'Healer',
	3 => 'DPS',
	4 => 'Ближний бой',
	5 => 'Leech',
	),
	"races" => array(
	0 => 'Неизвестно',
	1 => 'Тамплиеры',
	2 => 'Драконы',
	3 => 'Иллюминаты',
	),
	"roles" => array(
	1 => 'Healer',
	2 => 'Tank',
	3 => 'Damage Dealer',
	4 => 'Add Control',
	5 => 'Podder',
	),
	"lang" => array(
	"tsw" => 'The Secret World',
	"uc_race" => 'Faction',
	"uc_class" => 'prefered Class',
	"uc_faction" => 'Faction',
	"uc_cat_misc" => 'miscellaneous',
	"uc_pvp" => 'Fusang Battlegroup',
	"uc_pvp_help" => 'Battlegroup is Serverbound',
	"uc_RP" => 'Roleplayer',
	"uc_RP_help" => '',
	"uc_yes" => 'Yes',
	"uc_no" => 'No',
	"uc_unknown" => 'unknown',
	"uc_ED" => 'Eldorado',
	"uc_SH" => 'Stonehenge',
	"uc_BG" => 'Battlegroup',
	"uc_BG_A" => 'Fusang BG-A',
	"uc_BG_B" => 'Fusang BG-B',
	"uc_guild" => 'Cabal',
	"uc_level" => 'Effusionrating',
	"uc_testlive" => 'Access to Testlive',
	"uc_wings" => 'Wing Colour',
	"uc_blue" => 'Blue',
	"uc_gold" => 'Golden',
	"uc_purple" => 'Purple',
	"uc_nowings" => 'none',
	"eidolon" => 'Eidolon',
	"ny_raid" => 'New York',
	"flappy" => 'Flappy',
	"core_sett_fs_gamesettings" => 'The Secret World Settings',
	"Heroic" => 'Heroic',
	"Epic" => 'Epic',
	"Rare" => 'Rare',
	"Normal" => 'Uncommon',
	"Other" => 'Common',
	"Augments" => 'Augment Resonator',
	"Signets" => 'Signets',
	"Event-Items" => 'Event-Items',
	"Clothes" => 'Clothes',
	"Emotes" => 'Emotes',
	"Token-Items" => 'Token-Items',
	"Material" => 'Material',
	"Others" => 'Others',
	),
	
);

?>