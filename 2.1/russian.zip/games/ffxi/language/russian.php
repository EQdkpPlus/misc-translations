<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Russian	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:50
//File: games/ffxi/language/russian.php
//Source-Language: english

$russian_array = array( 
	"classes" => array(
	0 => 'Неизвестно',
	1 => 'Бард',
	2 => 'Зверолов',
	3 => 'Чёрный маг',
	4 => 'Синий маг',
	5 => 'Корсар',
	6 => 'Танцор',
	7 => 'Тёмный рыцарь',
	8 => 'Драгун',
	9 => 'Монах',
	10 => 'Ниндзя',
	11 => 'Паладин',
	12 => 'Кукловод',
	13 => 'Рейнджер',
	14 => 'Красный маг',
	15 => 'Самурай',
	16 => 'Школяр',
	17 => 'Саммонер',
	18 => 'Вор',
	19 => 'Воин',
	20 => 'Белый маг',
	),
	"races" => array(
	0 => 'Неизвестно',
	1 => 'Эльваны',
	2 => 'Галка',
	3 => 'Хьюмы',
	4 => 'Митры',
	5 => 'Тарутару',
	),
	"factions" => array(
	"bastok" => 'Басток',
	"sandoria" => 'Сан д\'Ория',
	"windurst" => 'Виндарст',
	),
	"lang" => array(
	"ffxi" => 'Final Fantasy XI',
	"tank" => 'Танк',
	"support" => 'Поддержка',
	"damage_dealer" => 'Боец',
	"uc_gender" => 'Пол',
	"uc_male" => 'Мужской',
	"uc_female" => 'Женский',
	"uc_guild" => 'Гильдия',
	"uc_race" => 'Раса',
	"uc_class" => 'Класс',
	"core_sett_fs_gamesettings" => 'Настройки Final Fantasy XI',
	"uc_faction" => 'Faction',
	"uc_faction_help" => 'Выберите фракцию по-умолчанию',
	),
	
);

?>