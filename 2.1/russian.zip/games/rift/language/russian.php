<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Russian	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:50
//File: games/rift/language/russian.php
//Source-Language: english

$russian_array = array( 
	"classes" => array(
	0 => 'Неизвестно',
	1 => 'Воин',
	2 => 'Разбойник',
	3 => 'Клирик',
	4 => 'Маг',
	5 => 'Primalist',
	),
	"races" => array(
	0 => 'Неизвестно',
	1 => 'Матосиане',
	2 => 'Высшие эльфы',
	3 => 'Гномы',
	4 => 'Бахми',
	5 => 'Этхи',
	6 => 'Келари',
	7 => 'Ascended',
	),
	"factions" => array(
	"default" => 'по умолчанию',
	"guardians" => 'Стражи',
	"defiant" => 'Непокорные',
	),
	"roles" => array(
	1 => 'Лекарь',
	2 => 'Танк',
	3 => 'Дамагер',
	4 => 'Поддержка',
	),
	"lang" => array(
	"rift" => 'RIFT',
	"plate" => 'Латы',
	"heavy" => 'Тяжёлая',
	"light" => 'Ткань',
	"medium" => 'Кожа',
	"import_ranks" => 'Импорт рангов',
	"guild_xml" => 'XML гильдии',
	"uc_import_forw" => 'Импорт',
	"uc_import_guild" => 'Import/Update Guild',
	"uc_import_guild_help" => 'Import/Update all Guild-Members with a Guild-XML-File',
	"guild_xml_lang" => 'Язык XML-файла гильдии',
	"uc_gimp_header_fnsh" => 'Данные успешно импортированы. Теперь можете закрыть это окно.',
	"import_status_true" => 'Imported/Updated',
	"import_status_false" => 'Ошибка',
	"guild_xml_error" => 'Некорректный XML гильдии.',
	"uc_delete_chars_onimport" => 'Удалять покинувших гильдию персонажей',
	"uc_race" => 'Race',
	"uc_class" => 'Class',
	"core_sett_fs_gamesettings" => 'RIFT Settings',
	"uc_faction" => 'Faction',
	"uc_faction_help" => 'Select the default faction',
	),
	
);

?>