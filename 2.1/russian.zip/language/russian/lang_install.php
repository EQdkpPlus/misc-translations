<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Russian	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:50
//File: language/russian/lang_install.php
//Source-Language: english

$lang = array( 
	"page_title" => 'Установка EQDKP-PLUS %s',
	"back" => 'Сохранить и вернуться',
	"continue" => 'Продолжить',
	"language" => 'Язык',
	"inst_finish" => 'Завершить установку',
	"error" => 'Ошибка',
	"warning" => 'Внимание',
	"success" => 'Успешно',
	"yes" => 'Да',
	"no" => 'Нет',
	"retry" => 'Повторить',
	"skip" => 'Пропустить',
	"step_order_error" => 'Step-Order error: Step not found. Please ensure that all files are uploaded correctly. For further information please visit our forums at <a href="http://eqdkp-plus.eu/forum">http://eqdkp-plus.eu/forum</a>.',
	"licence" => 'Лицензионное Соглашение',
	"php_check" => 'Предварительная проверка',
	"ftp_access" => 'Настройки FTP',
	"encryptionkey" => 'Ключ шифрования',
	"data_folder" => 'Директория скрипта',
	"db_access" => 'Доступ к БД',
	"inst_settings" => 'Настройки',
	"admin_user" => 'Учётная запись администратора',
	"end" => 'Завершить установку',
	"welcome" => 'Добро пожаловать в программу установки EQdkp Plus. Мы проделали большую работу, чтобы сделать этот процесс быстрым и удобным. Чтобы начать установку, пожалуйста, примите условия лицензионного соглашения, нажав \'Согласиться и продолжить\'.',
	"accept" => 'Согласиться и продолжить',
	"license_text" => '<b>EQdkp Plus is published under AGPL v3.0 license.</b><br /><br /> The full license text can be found at <a href="http://opensource.org/licenses/AGPL-3.0" target="_blank">http://opensource.org/licenses/AGPL-3.0</a>.<br /><br />
	This is a summary of the most important terms of the AGPL v3.0. There is no claim to completeness and correctness.<br /><br />
	<h3><strong>You are permitted:</strong></h3>
<ul>
<li>to use this software for commercial use</li>
<li>to distribute this software</li>
<li>to modify this software</li>
</ul>
<h3><strong>You are required:</strong></h3>
<ul>
<li>to disclose the sourcecode of your complete application that uses EQdkp Plus, when you distribute your application</li>
<li>to disclose the sourcecode of your complete application that uses EQdkp Plus, if you don\'t distribute it, but users are using the software via network ("Hosting", "SaaS")</li>
<li>to remain the visible and unvisible Copyright Notices of this Project and to include a copy of the AGPL License at your application</li>
<li>to indicate significant changes made to the code</li>
</ul>
<h3><strong>It\'s forbidden:</strong></h3>
<ul>
<li>to held the author(s) of this software liable for any damages, the software is provided without warranty.</li>
<li>to license your application under another license than the AGPL</li>
</ul>',
	"table_pcheck_name" => 'Имя',
	"table_pcheck_required" => 'Обязательно',
	"table_pcheck_installed" => 'Текущ.',
	"table_pcheck_rec" => 'Рекомендуемые',
	"module_php" => 'Версия PHP',
	"module_mysql" => 'База данных MySQL',
	"module_zLib" => 'PHP-модуль zLib',
	"module_safemode" => 'Безопасный режим PHP',
	"module_curl" => 'PHP-модуль cURL',
	"module_fopen" => 'PHP-функция fopen',
	"module_soap" => 'PHP-модуль SOAP',
	"module_autoload" => 'PHP-функция spl_autoload_register',
	"module_hash" => 'PHP-функция hash',
	"module_memory" => 'PHP memory limit',
	"module_json" => 'JSON PHP молуль',
	"module_gd" => 'GD Image module',
	"module_pathinfo" => 'PathInfo-Support',
	"safemode_warning" => '<strong>WARNING</strong><br/>Because the PHP Safe mode is active, you have to use the FTP mode in the next Step in order to use EQdkp Plus!',
	"phpcheck_success" => 'Система отвечает минимальным требованиям для установки  EQDKP-Plus, можно продолжать установку.',
	"phpcheck_failed" => 'The minimum requirements for the installation of EQDKP-Plus are not met.<br />A selection of suitable hosting companies can be found on our <a href="http://eqdkp-plus.eu" target="_blank">website</a>',
	"do_match_opt_failed" => 'Некоторые рекомендации не выполнены. EQDKP-Plus будет работать на этой системе; однако, не все функции могут быть доступны.',
	"ftphost" => 'Хост FTP',
	"ftpport" => 'Порт FTP',
	"ftpuser" => 'Имя пользователя FTP',
	"ftppass" => 'Пароль FTP',
	"ftproot" => 'Папка FTP',
	"ftproot_sub" => '(Путь к корневой директории FTP пользователя)',
	"useftp" => 'Использовать FTP-режим для работы с файлами',
	"useftp_sub" => '(Этот параметр можно изменить позднее в файле config.php)',
	"safemode_ftpmustbeon" => 'Поскольку PHP работает в безопасном режиме, настройте параметры FTP, чтобы продолжить установку.',
	"ftp_connectionerror" => 'Не удалось подключиться к FTP. Пожалуйста, проверьте FTP хост и порт.',
	"ftp_loginerror" => 'Не удалось подключиться к FTP. Пожалуйста, проверьте имя пользователя и пароль.',
	"plain_config_nofile" => 'The file <b>config.php</b> is not available and automatic creation failed. <br />Please create a blank text file with the name <b>config.php</b> and set the permissions with chmod 777',
	"plain_config_nwrite" => 'The <b>config.php</b> file is not writeable. <br /> Please set the correct permissions. <b>chmod 0777 config.php</b>.',
	"plain_dataf_na" => 'The folder <b>./data/</b> is not available.<br /> Please create this folder. <b>mkdir data</​​b>.',
	"plain_dataf_nwrite" => 'The folder <b>./data/</b> is not writeable.<br /> Please set the correct permissions. <b>chmod -R 0777 data</​​b>.',
	"ftp_datawriteerror" => 'Ошибка записи в папку с данными. Пожалуйста, проверьте, корректно ли настроен путь к корневой директории FTP.',
	"ftp_info" => 'Для улучшения безопасности и функциональности, вы можете дать возможность системе совершать файловые операции по FTP. Это уменьшает необходимость выставления прав на запись на бóльшую часть папок, что может быть необходимо на определенных хостинговых площадках. Чтобы использовать эту опциональную настройку, впишите данные в форму ниже и отметьте галочку "FTP-режим". Если вы не хотите использовать FTP-режим, просто нажмите "Продолжить".',
	"ftp_tmpinstallwriteerror" => 'The folder <b>./data/97384261b8bbf966df16e5ad509922db/tmp/</b> is not writable.<br />To write the config-file, CHMOD 777 is required. This folder will be deleted after the installation process.',
	"ftp_tmpwriteerror" => 'The folder <b>./data/%s/tmp/</b> is not writable.<br />Using FTP-Mode requires CHMOD 777 for this folder. This is the only folder needing writing permissions.',
	"dbtype" => 'Тип БД',
	"dbhost" => 'Хост сервера БД',
	"dbname" => 'Название БД',
	"dbuser" => 'Имя пользователя БД',
	"dbpass" => 'Пароль БД',
	"table_prefix" => 'Префикс для таблиц EQDKP-Plus',
	"test_db" => 'Проверить базу данных',
	"prefix_error" => 'Некорректный или пустой префикс для базы данных!',
	"INST_ERR_PREFIX" => 'Установленная копия EQdkp с таким префиксом уже существует. Удалите все таблицы с этим префиксом и повторите этот шаг установки, нажав "Назад". Также вы можете укзать другой префикс, если хотите установить несколько копий EQDKPlus в одну базу данных.',
	"INST_ERR_DB_CONNECT" => 'Ошибка подключения к базе данных. Ознакомьтесь с сообщением об ошбике.',
	"INST_ERR_DB_NO_ERROR" => 'Нет сообщений об ошибке.',
	"INST_ERR_DB_NO_MYSQLI" => 'Версия MySQL на этом сервере несовместима с выбранной опцией “MySQL с расширением MySQLi". Пожалуйста, попробуйте выбрать опцию "MySQL".',
	"INST_ERR_DB_NO_NAME" => 'Не указано имя базы данных.',
	"INST_ERR_PREFIX_INVALID" => 'Выбран некорректный префикс для таблиц. Пожалуйста, выберите другой префикс, убрав спецсимволы.',
	"INST_ERR_PREFIX_TOO_LONG" => 'Слишком длинный префикс для таблиц. Максимальный префикс: %d симв.',
	"dbcheck_success" => 'Проверка подключения к БД пройдена успешно. Ошибок или конфликтов не выявлено. Можете продолжать установку.',
	"encryptkey_info" => 'Ключ является частью процесса шифрования критичной информации в базе данных. Например, шифруются личные данные пользователей. Даже если база данных будет скомпрометирована, без ключа шифрования злоумышленник не сможет получить доступ к данным. Поэтому, пожалуйста, выберите безопасный ключ, чтобы защитить ваши данные и помните, что в случае его утраты никто не сможет получить доступ к данным!',
	"encryptkey" => 'Ключ шифрования',
	"encryptkey_help" => '(мин. длина - 6 символов)',
	"encryptkey_repeat" => 'Подтвердите ключ шифрования',
	"encryptkey_no_match" => 'Ключи шифрования не совпадают',
	"encryptkey_too_short" => 'Слишком короткий ключ шифрования. Минимальная длина - 6 символов.',
	"inst_db" => 'Установить базу данных',
	"lang_config" => 'Языковые настройки',
	"default_lang" => 'Язык по умолчанию',
	"default_locale" => 'Локаль по умолчанию',
	"game_config" => 'Настройки игры',
	"default_game" => 'Игра по умолчанию',
	"server_config" => 'Серверные настройки',
	"server_path" => 'Путь к скрипту',
	"grp_guest" => 'Гости',
	"grp_super_admins" => 'Главные администраторы',
	"grp_admins" => 'администраторы',
	"grp_officers" => 'офицеры',
	"grp_writers" => 'редакторы',
	"grp_member" => 'пользователи',
	"grp_guest_desc" => 'Гости - это неавторизованные пользователи',
	"grp_super_admins_desc" => 'Главные администраторы имеют все права',
	"grp_admins_desc" => 'Администраторам недоступны некоторые опции в панели управления',
	"grp_officers_desc" => 'Офицеры могут управлять рейдами',
	"grp_writers_desc" => 'Редакторы могут управлять новостями',
	"grp_member_desc" => 'Рядовые пользователи системы',
	"game_info" => 'Другие поддерживаемые игры могут быть загружены позже через менеджер расширений.',
	"timezone" => 'Временнáя зона сервера',
	"startday" => 'Первый день недели',
	"sunday" => 'Воскресенье',
	"monday" => 'Понедельник',
	"time_format" => 'H:i',
	"date_long_format" => 'j F Y',
	"date_short_format" => 'd.m.y',
	"style_jsdate_nrml" => 'День/месяц/год',
	"style_jsdate_short" => 'd.M',
	"style_jstime" => 'hh:mm tt',
	"welcome_news_title" => 'Добро пожаловать в систему EQDKP-Plus',
	"welcome_news" => '<p>The installation of your EQdkp Plus was completed successfully - you can now set it up according to your wishes.</p>
<p>You can find assistance to administration and general use in our <a href="http://eqdkp-plus.eu/wiki/" target="_blank">Wiki</a>.</p>
<p>For further support, please visit our <a href="http://eqdkp-plus.eu/forum" target="_blank">Forum</a>.</p>
<p>Have fun with EQdkp Plus! Your EQdkp Plus team</p>',
	"feature_news_title" => 'Новые возможности EQdkp Plus',
	"feature_news" => '<p>EQdkp Plus 2.2 contains a lot of new Features. This article should introduce the most importent of them.</p> <h3>Articlesystem</h3> <p>Instead of news and infopages, we introduced a complete new article system. Each news and page is now an article. You can group your articles using article-categories. Moreover, you can realise for example blogs for your guild and users.</p> <p>You can divide a single article using the Readmore- and Pagebreak-Methods. Also, you can insert Image-Galeries, Items or Raidloot using the appropriate Editor-Buttons.</p> <h3>Media-Management</h3> <p>Using the new Media-Management in ACP or Editor, you can now easily insert Media into your articles. For example, files can be uploaded using Drag&Drop. Also, you can even edit images in the Filebrowser.</p> <h3>Menu-Management</h3> <p>We have removed all menus except one. And the last one could be totally configured. You can position the entries using Drag&Drop in 3 levels, so it\'s possible to create submenus. You can still create links to external pages, but also add direct links to articles or articlecategories.</p> <h3>Portal-Management</h3> <p>In former times, there was only one portallayout, you had on every page the same portal modules. That\'s why we implemented the portallayouts. Now you can assign a portallayout to each articlecategory.</p> <p>Furthermore, you can create own portal blocks that you can embedd in your template, for example for editing links in your footer.</p>',
	"category1" => 'Система',
	"category2" => 'Новости',
	"category3" => 'События',
	"category4" => 'Айтемы',
	"category5" => 'Рейды',
	"category6" => 'Календарь',
	"category7" => 'Список',
	"category8" => 'Очки',
	"category9" => 'Персонажи',
	"article5" => 'Персонажи',
	"article6" => 'Список',
	"article7" => 'События',
	"article8" => 'Айтемы',
	"article9" => 'Очки',
	"article10" => 'Рейды',
	"article12" => 'Календарь событий',
	"article13" => 'Календарь',
	"article14" => 'Правила Гильдии',
	"article15" => 'Политика Конфиденциальности',
	"article16" => 'Юридическая информация',
	"role_healer" => 'Лекарь',
	"role_tank" => 'Танк',
	"role_range" => 'РДД',
	"role_melee" => 'Мили-ДД',
	"create_user" => 'Создать',
	"username" => 'Логин администратора',
	"user_password" => 'Пароль администратора',
	"user_pw_confirm" => 'Подтвердите пароль',
	"user_email" => 'E-mail администратора',
	"auto_login" => 'Запомнить меня',
	"user_required" => 'Логин, пароль и e-mail являются обязательными полями',
	"no_pw_match" => 'Пароли не совпадают.',
	"install_end_text" => 'Теперь установка может быть завершена.',
	"windows_apache_hint" => 'It seems like you are using Apache under Windows as Webserver. EQdkp Plus will only work if you increase the ThreadStackSize to 8388608 at the Apache configuration file.',
	
);

?>