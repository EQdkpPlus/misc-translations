<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Finnish	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:45
//File: plugins/guildrequest/language/finnish/lang_main.php
//Source-Language: english

$lang = array( 
	"guildrequest" => 'Kiltahakemus',
	"guildrequest_short_desc" => 'Kiltahakemus',
	"guildrequest_long_desc" => 'Kiltahakemus on plugini hakemusten ylläpitämiseen',
	"gr_manage_form" => 'Hallitse lomaketta',
	"gr_vote" => 'Äänestys',
	"gr_view" => 'Näytä hakemukset',
	"gr_view_closed" => 'Näytä suljetut hakemukset',
	"gr_add" => 'Kirjoita hakemus',
	"gr_applications" => 'Avaa hakemukset',
	"gr_archive" => 'Arkisto',
	"gr_internal_comment" => 'Kirjoita sisäinen kommentti',
	"gr_comment" => 'Kirjoita julkinen kommentti',
	"gr_plugin_not_installed" => 'Kiltahakemus plugini ei ole asennettu.',
	"gr_select_options" => 'Vaihtoehdot (1 per rivi)',
	"gr_required" => 'Pakollinen',
	"gr_delete_selected_fields" => 'Poista valitut kentät',
	"gr_types" => array(
	0 => 'Teksikenttä',
	1 => 'Tekstialue',
	2 => 'Pudotusvalikko',
	3 => 'Ryhmämerkki',
	4 => 'Vapaata tekstiä',
	5 => 'Valintalaatikot',
	6 => 'Radio-painikkeet',
	7 => 'Toimittaja',
	8 => 'Kuva-Lataus',
	),
	"gr_add_field" => 'Lisää uusi kenttä',
	"gr_delete_field" => 'Poista kenttä',
	"gr_default_grouplabel" => 'Yleistä informaatiota',
	"gr_personal_information" => 'Henkilötietoja',
	"gr_submit_request" => 'Lähetä hakemus',
	"gr_email_help" => 'Anna voimassa oleva, aktiivinen sähköpostisi. Sähköpostisi perusteella luodaan uusi tilisi järjestelmään ja ilmoitetaan hakemuksen edistymisestä.',
	"gr_activationmail_subject" => 'Aktivoi hakemuksesi',
	"gr_viewlink_subject" => 'Sinun hakemuksesi',
	"gr_request_success" => 'Hakemuksesi on talletettu onnistuneesti. Sähköposti on lähetetty.',
	"gr_request_success_msg" => 'Hakemuksesi on talletettu onnistuneesti. Voit tarkastella hakemustasi aina tästä linkistä:',
	"gr_internal_comments" => 'Sisäiset kommentit',
	"gr_newcomment_subject" => 'Uusi kommentti hakemuksessasi',
	"gr_status" => array(
	0 => 'uusi',
	1 => 'kesken',
	2 => 'Hyväksytty',
	3 => 'Hylätty',
	),
	"gr_status_text" => 'Hakemuksesi tila: <b>%s</b>',
	"gr_vote_button" => 'Äänestä',
	"gr_manage_request" => 'Hallinoi hakemuksia',
	"gr_status_help" => 'Hakija saa automaattisen sähköpostin muutoksesta. Jos haluat lisätä jotain viestiin, kirjoita kenttään haluamasi terveiset',
	"gr_change_status" => 'Vaihda tila',
	"gr_close" => 'Sulje hakemus',
	"gr_open_request" => 'Avaa hakemus uudelleen',
	"gr_closed_subject" => 'Sinun hakemus on suljettu',
	"gr_status_subject" => 'Hakemuksesi tila: Tilan vaihto',
	"gr_footer" => 'löytyi %1$ hakemusta / %2$ per sivu',
	"gr_in_list" => 'Näytä avoimien hakemusten lista',
	"gr_confirm_delete_requests" => 'Haluatko varmasti poistaa hakemuksen %s ?',
	"gr_delete_selected_requests" => 'Poista valittu hakemus',
	"gr_delete_success" => 'Valittu hakemus on poistettu onnistuneesti.',
	"gr_notification" => '%s uusi hakemus/kommentti',
	"gr_notification_open" => '%s avointa hakemusta',
	"gr_mark_all_as_read" => 'Merkitse kaikki hakemukset luetuiksi',
	"gr_send_notification_mails" => 'Lähetä huomio sähköpostilla uuden hakemuksen tullessa järjestelmään',
	"gr_closed" => 'Tämä hakemus on suljettu',
	"gr_notification_subject" => 'Uusi hakemus',
	"gr_jgrowl_notifications" => 'Näytä PopUp ilmoitukset',
	"gr_viewrequest" => 'Näytä hakemus',
	"gr_dependency" => 'Riippuvuus (Kenttä - Vaihtoehto)',
	"gr_customcheck_info" => 'Voit lisätä omat riippuvuustarkistuksen, jos valitset "_Custom" ja kirjoitat lausekkeen kentän oikealla puolella. <br /> Esimerkki: ((FIELD1 == "OmaArvoni1" && FIELD2 == "OmaArvoni2") || FIELD3 = = "OmaArvoni3") <br /> Älä ota huomioon, että pakollisen kentän tarkistus ei toimi oikein mukautettujen riippuvuuksien suhteen.',
	"user_sett_fs_guildrequest" => 'Kiltahakemus',
	"user_sett_tab_guildrequest" => '<i class="fa fa-pencil-square-o"></i> Kiltahakemus',
	"gr_preview" => 'Esikatselu',
	"gr_preview_info" => 'Tämä esikatselu on luotu viimeisimmästä tallennetusta muodosta. Tallenna nykyinen lomake tallentamalla muokattu lomake ja napsauttamalla Esikatselu-painiketta lomakesivulla.',
	"user_sett_f_ntfy_guildrequest_new_application" => 'Uusi hakemus',
	"user_sett_f_ntfy_guildrequest_new_update" => 'Uusi kommentti',
	"user_sett_f_ntfy_guildrequest_open_applications" => 'Avoimet hakemukset',
	"user_sett_f_ntfy_guildrequest_new_update_own" => 'Päivityksiä omalle hakemukselleni',
	"user_sett_fs_notifications_guildrequest" => 'Kiltahakemus',
	"gr_notify_new_application" => '{PRIMARY} lisäsi uuden hakemuksen',
	"gr_notify_new_application_grouped" => '{PRIMARY} lisäsi uuden hakemuksen',
	"gr_notify_new_update" => '{ADDITIONAL} hakemus sai kommentin',
	"gr_notify_new_update_grouped" => 'Hakemusten kommentteja yht. {COUNT} ',
	"gr_notify_new_update_own" => 'Hakemustasi on päivitetty',
	"gr_notify_new_update_own_grouped" => 'Hakemustasi on päivitetty yhteensä {COUNT} kertaa',
	"gr_fs_general" => 'Yleinen',
	"gr_f_create_account" => 'Luo EQdkp Plus-tili, jos hakemus hyväksyttiin',
	"gr_f_help_create_account" => 'Tämä vaihtoehto on käytettävissä, jos yksikään CMS-silta ei ole aktiivinen',
	"gr_f_archive" => 'Siirrä kaikki suljetut hakemukset arkistoon',
	"gr_f_help_archive" => 'Tämä esi järjestelee kaikki suljetut hakemukset paremman yleiskuvan saamiseksi',
	"gr_myapplications" => 'Minun hakemukset',
	"plugin_statistics_guildrequest_applications" => 'Kiltahakemus: Hakemukset',
	"gr_voted_users" => 'Seuraavat käyttäjät ovat jo äänestäneet',
	
);

?>