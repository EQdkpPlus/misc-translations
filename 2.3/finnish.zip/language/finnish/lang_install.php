<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Finnish	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:45
//File: language/finnish/lang_install.php
//Source-Language: english

$lang = array( 
	"page_title" => 'EQDKP-PLUS %s Asennus',
	"back" => 'Tallenna ja palaa',
	"continue" => 'Jatka',
	"language" => 'Kieli',
	"inst_finish" => 'Viimeistele asennus',
	"error" => 'Virhe',
	"warning" => 'Varoitus',
	"success" => 'Onnistui',
	"yes" => 'Kyllä',
	"no" => 'Ei',
	"retry" => 'Yritä uudelleen',
	"skip" => 'Ohita',
	"step_order_error" => 'Vaihejärjestyksen virhe: Vaihetta ei löytynyt. Varmista, että kaikki tiedostot on ladattu oikein. Lisätietoja varten käy foorumillamme osoitteessa <a href="http://eqdkp-plus.eu/forum">http://eqdkp-plus.eu/forum</a>.',
	"licence" => 'Lisenssisopimus',
	"php_check" => 'Esiasennus tarkistus',
	"file_permissions" => 'Tiedostojen ja kansioiden käyttöoikeudet',
	"encryptionkey" => 'Salausavain',
	"data_folder" => 'Data kansio',
	"db_access" => 'Tietokantojen käyttö',
	"inst_settings" => 'Asetukset',
	"admin_user" => 'Ylläpitäjä tunnus',
	"end" => 'Suorita asennus loppuun',
	"welcome" => 'Tervetuloa EQdkp Plus -sovelluksen asentajaan. Olemme työskennelleet ahkerasti tehdäksemme prosessista helpon ja nopean. Aloita hyväksymällä lisenssisopimus napsauttamalla alla olevaa \'Hyväksy ja aloita asennus\'.',
	"accept" => 'Hyväksy ja aloita asennus',
	"license_text" => '<b>EQdkp Plus is published under AGPL v3.0 license.</b><br /><br /> The full license text can be found at <a href="http://opensource.org/licenses/AGPL-3.0" target="_blank">http://opensource.org/licenses/AGPL-3.0</a>.<br /><br />
	This is a summary of the most important terms of the AGPL v3.0. There is no claim to completeness and correctness.<br /><br />
	<h3><strong>You are permitted:</strong></h3>
<ul>
<li>to use this software for commercial use</li>
<li>to distribute this software</li>
<li>to modify this software</li>
</ul>
<h3><strong>You are required:</strong></h3>
<ul>
<li>to disclose the sourcecode of your complete application that uses EQdkp Plus, when you distribute your application</li>
<li>to disclose the sourcecode of your complete application that uses EQdkp Plus, if you don\'t distribute it, but users are using the software via network ("Hosting", "SaaS")</li>
<li>to remain the visible and unvisible Copyright Notices of this Project and to include a copy of the AGPL License at your application</li>
<li>to indicate significant changes made to the code</li>
</ul>
<h3><strong>It\'s forbidden:</strong></h3>
<ul>
<li>to held the author(s) of this software liable for any damages, the software is provided without warranty.</li>
<li>to license your application under another license than the AGPL</li>
</ul>',
	"table_pcheck_name" => 'Nimi',
	"table_pcheck_required" => 'Vaadittu',
	"table_pcheck_installed" => 'Nykyinen',
	"table_pcheck_rec" => 'Suositeltu',
	"module_php" => 'PHP versio',
	"module_mysql" => 'MySQL tietokanta',
	"module_zLib" => 'zLib PHP module',
	"module_curl" => 'cURL PHP module',
	"module_fopen" => 'fopen PHP function',
	"module_soap" => 'SOAP PHP module',
	"module_autoload" => 'spl_autoload_register PHP function',
	"module_hash" => 'hash PHP function',
	"module_memory" => 'PHP memory limit',
	"module_json" => 'JSON PHP module',
	"module_gd" => 'GD Image PHP module',
	"module_pathinfo" => 'PathInfo-Support',
	"module_zip" => 'Zip PHP module',
	"module_xml" => 'XML PHP module',
	"module_mb" => 'MultiByte PHP-module',
	"module_crypto" => 'Cryptographic Methods',
	"phpcheck_success" => 'EQDKP-Plus -sovelluksen vähimmäisvaatimukset täyttyvät. Asennus voi edetä.',
	"phpcheck_failed" => 'EQDKP-Plus -sovelluksen vähimmäisvaatimukset eivät täyty. <br /> Valikoima sopivia hosting-yrityksiä löytyy <a href="http://eqdkp-plus.eu"" target="_blank"> verkkosivustoltamme </a>',
	"do_match_opt_failed" => 'Jotkut suositukset eivät täyty. EQDKP-Plus toimii tässä järjestelmässä; Ehkä kaikki ominaisuudet eivät ole käytettävissä.',
	"ftphost" => 'FTP host',
	"ftpport" => 'FTP port',
	"ftpuser" => 'FTP username',
	"ftppass" => 'FTP password',
	"ftproot" => 'FTP base dir',
	"ftproot_sub" => '(Polku FTP-käyttäjän juurihakemistoon)',
	"useftp" => 'Käytä FTP-tilaa tiedostojen käsittelijänä',
	"useftp_sub" => '(Voit muuttaa sitä myöhemmin muokkaamalla config.php)',
	"ftp_connectionerror" => 'FTP-yhteyttä ei voitu muodostaa. Tarkista FTP-osoite ja FTP-portti.',
	"ftp_loginerror" => 'FTP-kirjautuminen ei onnistunut. Tarkista FTP-käyttäjänimesi ja FTP-salasanasi.',
	"plain_config_nofile" => 'Tiedosto <b>config.php</b> ei ole käytettävissä ja automaattinen luominen epäonnistui. <br />Luo tyhjä tekstitiedosto nimellä <b>config.php</b> ja aseta käyttöoikeudet chmod 777:llä',
	"plain_config_nwrite" => '<b>config.php</b>-tiedostoa ei voi kirjoittaa. Aseta oikeat oikeudet. <b>chmod 0777 config.php</b>.',
	"plain_dataf_na" => 'Kansio <b>'.registry::get_const('root_path').'data/</b> ei ole käytettävissä. <br />Luo tämä kansio <b>mkdir data</b>.',
	"plain_dataf_nwrite" => 'Kansiossa <b>'.registry::get_const('root_path').'data/</b> ei voida kirjoittaa. <br /> Aseta oikeat oikeudet. <b>chmod -R 0777 data</b>.',
	"ftp_datawriteerror" => 'Data kansioon ei voitu kirjoittaa. Onko FTP-juuripolku asetettu oikein?',
	"ftp_info" => 'Vaadittavien tiedosto- ja kansio-käyttöoikeuksien asettamisen sijaan voit käyttää ftp-tiliä tiedostojen muuttamiseen palvelimella. Jotta tätä valinnaista asetusta voitaisiin käyttää, anna ftp-käyttäjälle lupa muokata tiedostoja polussa ja valitse \'FTP-tila\' -valintaruutu. Jos et käytä FTP-tilaa, voit yksinkertaisesti jatkaa sivulta eteenpäin.',
	"ftp_tmpinstallwriteerror" => 'Kansio <b>'.registry::get_const('root_path').'data/97384261b8bbf966df16e5ad509922db/tmp/</b> ei ole kirjoitettavissa. <br />Konfiguraatiotiedoston kirjoittamiseen tarvitaan CHMOD 777. Tämä kansio poistetaan asennuksen jälkeen.',
	"ftp_tmpwriteerror" => 'Kansio <b>'.registry::get_const('root_path').'data/%s/tmp/</b> ei ole kirjoitettavissa. <br />FTP-tilan käyttäminen vaatii CHMOD 777 tälle kansiolle. Tämä on ainoa kansio, joka tarvitsee kirjoitusoikeuksia.',
	"fp_data_folder" => 'Kansio "data" on olemassa ja se on kirjoitettavissa',
	"fp_config_file" => 'Tiedosto "config.php" on olemassa ja se on kirjoitettavissa',
	"fp_test_file" => 'Testitiedosto kirjoitettu ja saatavilla',
	"dbtype" => 'Tietokannan tyyppi',
	"dbhost" => 'Tietokannan isäntä',
	"dbname" => 'Tietokannan nimi',
	"dbuser" => 'Tietokannan käyttäjätunnus',
	"dbpass" => 'Tietokannan salasana',
	"dbport" => 'Tietokannan portti',
	"dbport_help" => 'Vakio portti on 3306',
	"table_prefix" => 'EQDKP-Plus taulujen etuliite',
	"test_db" => 'Testi tietokanta',
	"prefix_error" => 'Tietokannan etuliitettä ei ole määritetty tai virheellinen! Anna kelvollinen etuliite.',
	"INST_ERR_PREFIX" => 'EQdkp-asennus kyseisellä etuliitteellä on jo olemassa. Poista kaikki etuliitteellä olevat taulukot ja toista tämä vaihe, kun olet käyttänyt Takaisin-painiketta. Vaihtoehtoisesti voit valita toisen etuliitteen, esim. jos haluat asentaa useita EQDKPlus-tietojoukkoja samaan tietokantaan.',
	"INST_ERR_PREFIX_INVALID" => 'Määrittämäsi taulukon etuliite on virheellinen tietokannallesi. Kokeile toista, poista merkit, kuten tavuviiva, apostrofi tai eteen- tai taaksepäinviiva.',
	"dbcheck_success" => 'Tietokanta tarkistettiin. Se ei löytänyt virheitä tai ristiriitoja. Asennusta voidaan jatkaa turvallisesti.',
	"encryptkey_info" => 'Salausavain on osa salausprosessia, jota käytetään tietokannan arkaluontoisten tietojen, kuten käyttäjien sähköpostiosoitteiden, suojaamiseen. Vaikka tietokantaisi olisi vaarantunut, tietosi ovat edelleen salattuja ilman salausavainta. Siksi valitse suojattu avain ja varmista, että säilytät siitä varmassa turvassa kopion. Kukaan muu ei voi koskaan palauttaa sitä puolestasi, jos se katoaa!',
	"encryptkey" => 'Salaus-avain',
	"encryptkey_help" => '(min. pituus 6 merkkiä)',
	"encryptkey_repeat" => 'Vahvista salausavain',
	"encryptkey_no_match" => 'Salausavaimet eivät täsmää',
	"encryptkey_too_short" => 'Salausavain on liian lyhyt. Vähittäis pituus on 6 merkkiä.',
	"inst_db" => 'Asenna tietokanta',
	"lang_config" => 'Kieli asetukset',
	"default_lang" => 'Vakio kielisyys',
	"default_locale" => 'Oletus paikallisuus',
	"game_config" => 'Peli asetukset',
	"default_game" => 'Oletus peli',
	"server_config" => 'Palvelimen asetukset',
	"server_path" => 'Komentosarjan polku',
	"grp_guest" => 'Vieraat',
	"grp_super_admins" => 'Super ylläpitäjät',
	"grp_admins" => 'Ylläpitäjät',
	"grp_officers" => 'Virkailijat',
	"grp_writers" => 'Toimittajat',
	"grp_member" => 'Jäsenet',
	"grp_guest_desc" => 'Vierailijat eivät ole kirjautuneita käyttäjiä.',
	"grp_super_admins_desc" => 'Super ylläpitäjillä on kaikki oikeudet',
	"grp_admins_desc" => 'Ylläpitäjillä on melkein kaikki oikeudet.',
	"grp_officers_desc" => 'Virkailijat(Officers) voivat hallita raideja',
	"grp_writers_desc" => 'Toimittajat voivat luoda ja hallita uutisia',
	"grp_member_desc" => 'Jäsen',
	"game_info" => 'Muita tuettuja pelejä voi ladata asennuksen jälkeen laajennushallinnassa.',
	"timezone" => 'Palvelimen aikavyöhyke',
	"startday" => 'Viikon ensimmäinen päivä',
	"sunday" => 'Sunnuntai',
	"monday" => 'Maanantai',
	"time_format" => 'H:i',
	"date_long_format" => 'j. F Y',
	"date_short_format" => 'd.m.y',
	"style_jsdate_nrml" => 'DD.MM.YYYY',
	"style_jsdate_short" => 'D.M',
	"style_jstime" => 'hh:mm',
	"welcome_news_title" => 'Tervetuloa EQDKP-Plus -sivustolle',
	"welcome_news" => '<p>EQdkp Plus -sovelluksesi asennus saatiin päätökseen onnistuneesti - voit nyt muokata sitä toiveidesi mukaiseksi.</p> <p>Löydät apua hallintoon ja yleiseen käyttöön <a href="http://eqdkp-plus.eu/wiki/" target="_blank">Wikistä</a>.</p> <p>Lisätietoja saat <a href="http://eqdkp-plus.eu/forum" target="_blank">Foorumeilta</a>.</p> <p>Pidä hauskaa EQdkp Plus -sovelluksen kanssa! EQdkp Plus -tiimisi</p>',
	"feature_news_title" => 'EQdkp Plus:n uudet ominaisuudet',
	"feature_news" => '<p>EQdkp Plus 2.3 contains a lot of new Features. This article should introduce the most importent of them.</p>
		<h3>Articlesystem</h3>
		<p>Instead of news and infopages, we introduced a complete new article system. Each news and page is now an article. You can group your articles using article-categories. Moreover, you can realise for example blogs for your guild and users.</p>
		<p>You can divide a single article using the Readmore- and Pagebreak-Methods. Also, you can insert Image-Galeries, Items or Raidloot using the appropriate Editor-Buttons.</p>
		<h3>Media-Management</h3> <p>Using the new Media-Management in ACP or Editor, you can now easily insert Media into your articles. For example, files can be uploaded using Drag&Drop. Also, you can even edit images in the Filebrowser.</p>
		<h3>Calendar</h3><p>Planing raids was never been easier by using Drag&Drop. Also, public and private events can be created, people can be invited and tell you if they participate or not.</p>
		<h3>Menu-Management</h3> <p>We have removed all menus except one. And the last one could be totally configured. You can position the entries using Drag&Drop in 3 levels, so it\'s possible to create submenus. You can still create links to external pages, but also add direct links to articles or articlecategories.</p>
		<h3>Portal-Management</h3> <p>In former times, there was only one portallayout, you had on every page the same portal modules. That\'s why we implemented the portallayouts. Now you can assign a portallayout to each articlecategory.</p>
		<p>Furthermore, you can create own portal blocks that you can embedd in your template, for example for editing links in your footer.</p>',
	"category1" => 'Järjestelmä',
	"category2" => 'Uutiset',
	"category3" => 'Tapahtumat',
	"category4" => 'Items',
	"category5" => 'Raidit',
	"category6" => 'Kalenteri',
	"category7" => 'Roster',
	"category8" => 'Points',
	"category9" => 'Character',
	"article5" => 'Character',
	"article6" => 'Roster',
	"article7" => 'Events',
	"article8" => 'Items',
	"article9" => 'Points',
	"article10" => 'Raids',
	"article12" => 'Calendarevent',
	"article13" => 'Calendar',
	"article14" => 'Guild Rules',
	"article15" => 'Privacy Policy',
	"article16" => 'Legal Notice',
	"role_healer" => 'Healer',
	"role_tank" => 'Tank',
	"role_range" => 'Ranged DPS',
	"role_melee" => 'Melee DPS',
	"create_user" => 'Create Access',
	"username" => 'Administrator username',
	"user_password" => 'Administrator password',
	"user_pw_confirm" => 'Confirm the administrator password',
	"user_email" => 'Administrator email address',
	"auto_login" => 'Remember me (cookie)',
	"user_required" => 'Username, email and password are required fields',
	"no_pw_match" => 'The passwords do not match.',
	"install_end_text" => 'The installation can now be completed successfully.',
	"windows_apache_hint" => 'It seems like you are using Apache under Windows as Webserver. EQdkp Plus will only work if you increase the ThreadStackSize to 8388608 at the Apache configuration file.',
	"install_support_h1" => 'Support EQdkp Plus',
	"install_support_text" => 'A project like EQdkp Plus can only exist, if we can get back some of the effort, time and love we invest in EQdkp Plus. You can give something back on the following ways:
						<ul>
							<li><i class="fa fa-puzzle-piece"></i> <a href="http://eqdkp-plus.eu/repository/">Publish a plugin or template, so every EQdkp Plus user can use it</a></li>
							<li><i class="fa fa-comments"></i> <a href="http://eqdkp-plus.eu/forum/">Support us at our board</a></li>
							<li><i class="fa fa-cogs"></i> <a href="https://eqdkp-plus.eu/en/development.html">Take part actively in the development of EQdkp Plus</a></li>
							<li><i class="fa fa-usd"></i> <a href="https://eqdkp-plus.eu/en/donate.html">Support us financially so we can continue offering you our services like LiveUpdate</a></li>
						</ul>
						So if you love EQdkp Plus as much as we do, think about supporting us!<br /><a href="https://eqdkp-plus.eu/Donate.html?" style="background:orange;border-radius:5px;padding:7px;display:inline-block;color:black;"><i class="fa fa-paypal"></i> Donate now</a>',
	"additional_keys" => 'Additional Features',
	"additional_keys_info" => 'We use features from other providers, like spam protection. In order to use this features, you need own Keys for this features. Therefore you can create your own keys at the following pages.<br /><b>Of course you can skip this step, and insert the keys at any time at the EQdkp Plus Settings.</b>',
	"recaptcha_info" => 'reCATPCHA is a spam protection method. Enabling this method reduces spam and increases the security of your EQdkp Plus. You can create your own keys at this page: <br /> <a href="https://www.google.com/recaptcha/admin/create" target="_blank"><i class="fa fa-lg fa-external-link"></i> https://www.google.com/recaptcha/admin/create</a>. Please use only supported types when creating a new key.',
	"recaptcha_okey" => 'Website Key of reCATPCHA',
	"recaptcha_pkey" => 'Private Key of reCATPCHA',
	"recaptcha_type" => 'Type',
	"delete_ownership_file" => 'For security reasons, please delete the file "database_ownership_file.txt" from the EQdkp Plus root folder to continue with your installation.',
	"module_externalconnection" => 'External connections',
	
);

?>