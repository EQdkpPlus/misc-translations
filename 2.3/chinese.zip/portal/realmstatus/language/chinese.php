<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Chinese	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:43
//File: portal/realmstatus/language/chinese.php
//Source-Language: english

$lang = array( 
	"realmstatus" => '狀態',
	"realmstatus_name" => '狀態',
	"realmstatus_desc" => '顯示當前地區狀態',
	"realmstatus_f_realm" => '伺服器清單',
	"realmstatus_f_help_realm" => '對於多台伺服器，伺服器必須以逗號分隔',
	"realmstatus_f_us" => '是美國伺服器嗎？',
	"realmstatus_f_help_us" => '僅當將RIFT或WoW設置為遊戲時，此設置才有效。',
	"realmstatus_f_gd" => '找到GD Lib（％s）。您要使用嗎？',
	"realmstatus_f_help_gd" => '此設置僅影響魔獸世界',
	"rs_no_realmname" => '未指定地區',
	"rs_realm_not_found" => '發現地區',
	"rs_game_not_supported" => '當前遊戲不支持地區狀態',
	"rs_unknown" => '未知',
	"rs_realm_status_error" => '為%1$s確定地區狀態時發生錯誤',
	"rs_loading" => '正在載入狀態...',
	"rs_loading_error" => '無法加載狀態',
	"realmstatus_wow_population_new" => '新',
	"realmstatus_wow_population_low" => '低',
	"realmstatus_wow_population_medium" => '中',
	"realmstatus_wow_population_high" => '高',
	"realmstatus_wow_population_full" => '滿',
	"realmstatus_wow_population_unknown" => '未知',
	"realmstatus_wow_population_locked" => '已鎖定',
	
);

?>