<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Chinese	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:43
//File: portal/weather/language/chinese.php
//Source-Language: english

$lang = array( 
	"weather" => '天氣',
	"weather_desc" => '顯示天氣',
	"weather_name" => '天氣',
	"weather_no_data" => '您的用戶個人資料中未設置國家或郵政編碼。僅當您設置了個人資料資訊後，天氣才會顯示資訊。',
	"weather_f_tempformat" => '溫度格式（默認值：攝氏）',
	"weather_f_geolocation" => '如果在用戶配置文件中未設置位置數據，是否使用瀏覽器的Geolocation-Option？',
	"weather_f_default_country" => '默認國家',
	"weather_f_default_town" => '默認城市',
	
);

?>