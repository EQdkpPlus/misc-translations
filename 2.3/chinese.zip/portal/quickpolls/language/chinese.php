<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Chinese	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:43
//File: portal/quickpolls/language/chinese.php
//Source-Language: english

$lang = array( 
	"quickpolls" => '快速投票',
	"quickpolls_name" => '快速投票',
	"quickpolls_desc" => '建立問卷',
	"quickpolls_f_title" => '投票標題',
	"quickpolls_f_question" => '描述',
	"quickpolls_f_question_help" => '此快速投票的說明或問題將顯示在標題下',
	"quickpolls_f_closedate" => '顯示直到',
	"quickpolls_f_help_closedate" => '在此日期之後，將僅顯示結果，並禁用投票',
	"quickpolls_f_showresults" => '顯示結果連結',
	"quickpolls_f_help_showresults" => '結果連結將顯示，與投票狀態無關',
	"quickpolls_f_showstatistics" => '在結果下方顯示統計資訊',
	"quickpolls_f_help_showstatistics" => '其中包括總票數，此外，對於多個選項，參與者（無嘉賓）',
	"quickpolls_f_options" => '選項',
	"quickpolls_f_help_options" => '每行插入一個選項',
	"quickpolls_f_resetvotes" => '重設投票',
	"quickpolls_vote" => '投票',
	"quickpolls_resuls" => '結果',
	"quickpolls_total_votes" => '總票數',
	"quickpolls_participants" => '參加者（無嘉賓）',
	"quickpolls_f_multiple" => '允許選擇多個選項',
	
);

?>