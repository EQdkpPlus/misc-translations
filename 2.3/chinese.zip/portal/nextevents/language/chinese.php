<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Chinese	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:43
//File: portal/nextevents/language/chinese.php
//Source-Language: english

$lang = array( 
	"nextevents" => '下次活動',
	"nextevents_name" => '日曆條目',
	"nextevents_desc" => '在頁面中顯示未來的Raid或事件',
	"nr_nextevents_signon" => '已登錄',
	"nr_nextevents_confirmed" => '已確認',
	"nr_nextevents_signoff" => '退出',
	"nr_nextevents_missing" => '必要',
	"nr_nextevents_notsigned" => '尚未登錄！',
	"nr_nextevents_noevents" => '沒有可用的活動',
	"nextevents_f_limit" => '顯示下一個事件',
	"nextevents_f_hideclosed" => '隱藏封閉的Raid',
	"nextevents_f_calendars" => '僅顯示所選日曆的事件',
	"nextevents_f_types" => '選擇事件類型',
	"nextevents_f_showweekday" => '在日期前顯示工作日',
	"nextevents_f_showendtime" => '顯示除開始時間以外的結束時間',
	"nextevents_f_useflags" => '使用彩色標記代替Raid狀態的名稱',
	"nextevents_f_showcalendarcolor" => '將日曆顯示為日期前面的彩色圓點',
	"nextevents_f_raidcountdown" => '顯示Raid倒數',
	"nextevents_f_help_raidcountdown" => '如果距Raid不到24小時，則顯示倒數而不是日期',
	
);

?>