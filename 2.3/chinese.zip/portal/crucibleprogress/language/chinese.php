<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Chinese	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:43
//File: portal/crucibleprogress/language/chinese.php
//Source-Language: english

$lang = array( 
	"crucibleprogress" => '風暴邪淵進度',
	"crucibleprogress_name" => '風暴邪淵進度',
	"crucibleprogress_desc" => '在此處設置進度',
	"crucibleprogress_f_boss1" => '不安之契',
	"crucibleprogress_f_boss2" => '烏納特，虛空先驅',
	"crucible_no" => '打開',
	"crucible_nhc" => '普通',
	"crucible_hc" => '英雄',
	"crucible_myth" => '神話',
	"test" => array(
	0 => '打開',
	1 => '普通',
	2 => '英雄',
	3 => '神話',
	),
	
);

?>