<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Chinese	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:43
//File: portal/recruitment/language/chinese.php
//Source-Language: english

$lang = array( 
	"recruitment" => '招募',
	"recruitment_name" => '招募',
	"recruitment_desc" => '尋找成員',
	"recruitment_open" => '搜索成員',
	"recruitment_contact" => '應用',
	"recruitment_noneed" => '目前沒有空位',
	"recruitment_f_url" => '招募網址',
	"recruitment_f_help_url" => '插入招募工具的URL。如果沒有URL，則模塊將插入EQdkp Plus的聯繫人電子郵件地址。',
	"recruitment_f_embed" => '網址應如何打開？',
	"recruitment_f_help_embed" => '選擇應如何打開插入的URL',
	"recruitment_f_priority" => '使用優先級而不是數字？',
	"pm_recruitment_talentsorroles" => '人才還是角色？',
	"pm_recruitment_talents" => '人才專長',
	"pm_recruitment_roles" => '角色',
	"recruitment_f_layout" => '佈局',
	"recruitment_f_2columns" => '兩列佈局',
	"recruit_priority_high" => '高',
	"recruit_priority_middle" => '中',
	"recruit_priority_low" => '低',
	"recruitment_f_text" => '資訊',
	
);

?>