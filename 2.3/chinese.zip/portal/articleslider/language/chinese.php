<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Chinese	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:43
//File: portal/articleslider/language/chinese.php
//Source-Language: english

$lang = array( 
	"articleslider" => '幻燈片',
	"articleslider_name" => '幻燈片',
	"articleslider_desc" => '顯示精選文章的圖像幻燈片',
	"articleslider_f_categories" => '文章類別',
	"articleslider_f_help_categories" => '精選文章將按所選類別顯示',
	"articleslider_f_featured" => '僅顯示精選文章',
	"articleslider_f_maxitems" => '顯示的精選文章的最大數量',
	"articleslider_f_height" => '幻燈片的最大高度',
	"articleslider_f_help_height" => '單位為像素',
	"articleslider_f_width" => '幻燈片的最大寬度',
	"articleslider_f_help_width" => '單位為像素，留空以獲取完整寬度',
	"articleslider_f_auto" => '幻燈片之間的自動切換',
	"articleslider_f_timeout" => '自動切換的等待時間（毫秒）',
	"articleslider_f_wordcount" => '預覽文字的字數',
	
);

?>