<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Chinese	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:43
//File: portal/offi_conf/language/chinese.php
//Source-Language: english

$lang = array( 
	"offi_conf" => '幹部會議',
	"offi_conf_name" => '幹部會議模塊',
	"offi_conf_desc" => '管理員可以發布幹部會議的主題',
	"oc_f_day" => '會議日期',
	"oc_f_end_time" => '會議結束（HH：MM）',
	"oc_f_start_time" => '會議開始（HH：MM）',
	"oc_f_time_type" => '定義官員會議的開始或結束？',
	"oc_f_date" => '下次幹部會議的日期',
	"oc_f_period2" => '每x週召開一次幹部會議',
	"oc_f_period3" => '幹部每月的每個x工作日開會',
	"oc_f_type" => '重複型',
	"oc_weekday" => '在某個工作日',
	"oc_xmonthday" => '在x上。一個月的星期天',
	"oc_manual" => '手動輸入日期',
	"oc_monday" => '星期一',
	"oc_tuesday" => '星期二',
	"oc_wednesday" => '星期三',
	"oc_thursday" => '星期四',
	"oc_friday" => '星期五',
	"oc_saturday" => '星期六',
	"oc_sunday" => '星期日',
	"oc_add_topic" => '添加主題',
	"oc_upd_topic" => '編輯主題',
	"oc_next_topics" => '下一主題',
	"oc_topic_name" => '名稱',
	"oc_topic_time" => '通話時間（分鐘）',
	"oc_topic_posi" => '排序',
	"oc_topic_desc" => '描述',
	"oc_save" => '保存',
	"oc_delete" => '刪除',
	"oc_save_success" => '保存成功！',
	"oc_save_no_success" => '保存不成功！',
	"oc_delete_success" => '刪除成功！',
	"oc_delete_no_success" => '刪除不成功！',
	"oc_no_name" => '沒有名稱',
	"oc_no_desc" => '沒有說明',
	"oc_creator" => '由...製作：',
	"oc_min" => '分',
	"oc_next_oc" => '下次幹部會議',
	"oc_start" => '開始',
	"oc_end" => '結束',
	
);

?>