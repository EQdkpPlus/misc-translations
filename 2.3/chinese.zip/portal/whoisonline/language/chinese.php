<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Chinese	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:43
//File: portal/whoisonline/language/chinese.php
//Source-Language: english

$lang = array( 
	"whoisonline" => '在線用戶',
	"whoisonline_name" => '在線用戶',
	"whoisonline_desc" => '顯示在線/離線用戶',
	"whoisonline_f_limit_total" => '顯示的最大用戶數',
	"whoisonline_f_help_limit_total" => '不會顯示超過這個數字的用戶',
	"whoisonline_f_limit_online" => '顯示的在線用戶數上限',
	"whoisonline_f_help_limit_online" => '插入0以顯示所有在線用戶',
	"whoisonline_f_limit_offline" => '顯示的離線用戶數上限',
	"whoisonline_f_help_limit_offline" => '插入0以不顯示離線用戶',
	"whoisonline_f_show_guests" => '顯示訪客',
	"wo_last_activity" => '最後活動',
	"wo_type_options" => array(
	0 => '清單',
	1 => '僅頭像',
	),
	"whoisonline_f_view" => '視圖',
	"wo_and_guests" => '沒有用戶和％d位訪客',
	
);

?>