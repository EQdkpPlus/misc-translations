<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Chinese	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:43
//File: portal/uldirprogress/language/chinese.php
//Source-Language: english

$lang = array( 
	"uldirprogress" => '奧迪爾進度',
	"uldirprogress_name" => '奧迪爾進度',
	"uldirprogress_desc" => '為每個首領選擇正確的進度',
	"uldirprogress_f_boss1" => '塔羅克',
	"uldirprogress_f_boss2" => '嫣紅女王',
	"uldirprogress_f_boss3" => '噬臭者',
	"uldirprogress_f_boss4" => '恩諾斯信使 札克沃茲',
	"uldirprogress_f_boss5" => '維提克斯',
	"uldirprogress_f_boss6" => '祖爾',
	"uldirprogress_f_boss7" => '揭滅者謎思拉克斯',
	"uldirprogress_f_boss8" => '古翰',
	"uldir_no" => '打開',
	"uldir_nhc" => '普通',
	"uldir_hc" => '英雄',
	"uldir_myth" => '神話',
	"test" => array(
	0 => '打開',
	1 => '普通',
	2 => '英雄',
	3 => '神話',
	),
	
);

?>