<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Chinese	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:43
//File: portal/dazarprogress/language/chinese.php
//Source-Language: english

$lang = array( 
	"dazarprogress" => '達薩亞洛之戰進度',
	"dazarprogress_name" => '達薩亞洛之戰進度',
	"dazarprogress_desc" => '為每個首領選擇正確的進度',
	"dazarprogress_f_boss1" => '聖光勇士',
	"dazarprogress_f_boss2" => '玉火大師',
	"dazarprogress_f_boss3" => '猩猩大王格洛恩',
	"dazarprogress_f_boss4" => '豐靈',
	"dazarprogress_f_boss5" => '神選者教團',
	"dazarprogress_f_boss6" => '拉斯塔哈大王',
	"dazarprogress_f_boss7" => '大工匠梅卡托克',
	"dazarprogress_f_boss8" => '風暴屏障封鎖部隊',
	"dazarprogress_f_boss9" => '珍娜‧普勞德摩爾女士',
	"dazar_no" => '打開',
	"dazar_nhc" => '普通',
	"dazar_hc" => '英雄',
	"dazar_myth" => '神話',
	"test" => array(
	0 => '打開',
	1 => '普通',
	2 => '英雄',
	3 => '神話',
	),
	
);

?>