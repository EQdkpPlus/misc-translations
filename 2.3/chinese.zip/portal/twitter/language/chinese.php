<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Chinese	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:43
//File: portal/twitter/language/chinese.php
//Source-Language: english

$lang = array( 
	"twitter" => 'Twitter',
	"twitter_name" => 'Twitter',
	"twitter_desc" => '關注特定的Twitter帳戶',
	"twitter_f_account" => 'Twitter帳戶',
	"twitter_f_maxitems" => '最高 顯示的（空=無限制)',
	"twitter_f_cachetime" => '緩存時間（小時）（默認值：1小時）',
	"twitter_f_hideuserreplys" => '隱藏對用戶的回覆',
	"twitter_f_hideretweets" => '隱藏轉推',
	"pm_twitter_follow" => '在Twitter上關注％s',
	"pm_twitter_period" => array(
	0 => '秒',
	1 => '分',
	2 => '時',
	3 => '天',
	4 => '週',
	5 => '月',
	6 => '年',
	7 => '十年',
	),
	"pm_twitter_periods" => array(
	0 => '秒',
	1 => '分',
	2 => '時',
	3 => '天',
	4 => '週',
	5 => '月',
	6 => '年',
	7 => '幾十年',
	),
	"pm_twitter_tense" => array(
	0 => '現在起',
	1 => '前',
	),
	"pm_twitter_format" => '%1$s %2$s',
	"pm_twitter_answer" => '回覆',
	"pm_twitter_retweet" => '轉推',
	"pm_twitter_favorit" => '喜愛',
	
);

?>