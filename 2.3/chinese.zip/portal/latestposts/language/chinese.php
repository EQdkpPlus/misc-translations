<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Chinese	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:43
//File: portal/latestposts/language/chinese.php
//Source-Language: english

$lang = array( 
	"latestposts" => '最新論壇帖子',
	"latestposts_name" => '最新論壇帖子',
	"latestposts_desc" => '顯示公告欄的最新帖子',
	"portal_latestposts_nomodule" => '未選擇模塊。請轉到模塊設置並配置此模塊。',
	"portal_latestposts_invmodule" => '錯誤的BB模塊',
	"portal_latestposts_noselectedboards" => '沒有選擇要顯示的論壇',
	"latestposts_f_bbmodule" => '論壇模塊',
	"latestposts_f_dbmode" => '選擇數據庫連接方式',
	"latestposts_f_help_dbmode" => '僅當選擇“ EQDKP以外的其他數據庫”時，才需要數據庫連接資訊',
	"latestposts_dbmode_same" => '論壇與EQDKP位於同一數據庫中',
	"latestposts_dbmode_new" => '論壇作為EQDKP在另一個數據庫中',
	"latestposts_dbmode_bridge" => '使用網橋的連接設置',
	"latestposts_dbmode_none" => '沒有',
	"latestposts_f_dbname" => '數據庫',
	"latestposts_f_dbuser" => '用戶',
	"latestposts_f_dbpassword" => '密碼',
	"latestposts_f_dbhost" => '主機',
	"latestposts_f_dbprefix" => '字首',
	"latestposts_f_url" => '看板網址',
	"latestposts_f_amount" => '顯示最近的x個條目',
	"latestposts_f_trimtitle" => '在x字後修剪主題標題',
	"latestposts_f_help_trimtitle" => '僅在左/右模塊中',
	"latestposts_f_linktype" => '應該如何打開主題連結？',
	"latestposts_f_blackwhitelist" => '黑名單或白名單',
	"latestposts_f_help_blackwhitelist" => '拒絕插入的論壇ID（列入黑名單）或接受它們（列入白名單）',
	"latestposts_f_privateforums" => '用戶組黑名單/白名單：',
	"latestposts_f_help_privateforums" => '在此處插入黑名單/白名單使用的論壇ID，以逗號分隔',
	"latestposts_f_help_privateforums2" => '選擇黑名單/白名單使用的顯示用戶組的論壇',
	"latestposts_noentries" => '沒有可用的條目',
	"latestposts_connerror" => '連接錯誤',
	"latestposts_lastpost" => '最後回覆',
	"latestposts_starter" => '首發',
	"latestposts_posts" => '回覆',
	"latestposts_title" => '話題',
	"latestposts_forum" => '看板',
	"latestposts_display_normal" => '正常',
	"latestposts_display_accordion" => '分頁',
	"latestposts_f_showcontent" => '顯示帖子預覽',
	"latestposts_f_style" => '顯示',
	
);

?>