<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Chinese	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:42
//File: core/data_handler/includes/modules/read/raid/language/chinese.php
//Source-Language: english

$module_lang = array(
	"date" => '日期',
	"event_name" => '名稱',
	"raidlink" => '名稱',
	"note" => '註記',
	"value" => '值',
	"item_count" => '物品',
	"attendee_count" => '參與者',
	"editicon" => '',
	);
	$preset_lang = array(
	"rdate" => 'Raid日期',
	"rlink" => 'Raid連結',
	"rattcount" => 'Raid參與者人數',
	"ritemcount" => 'Raid物品件數',
	"rvalue" => '值',
	"revent" => '事件',
	"rnote" => '註記',
	"raidedit" => '編輯按鈕',
	);
	

?>