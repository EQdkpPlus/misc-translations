<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Chinese	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:42
//File: core/data_handler/includes/modules/read/articles/language/chinese.php
//Source-Language: english

$module_lang = array(
	"sort_id" => '',
	"editicon" => '',
	"published" => '',
	"featured" => '',
	"title" => '標題',
	"alias" => '別名',
	"user_id" => '用戶',
	"date" => '日期',
	"last_edited" => '最後更改',
	"index_cb" => '索引',
	);
	$preset_lang = array(
	"article_sortable" => '文章分類',
	"article_editicon" => '編輯連結',
	"article_published" => '發表狀態',
	"article_title" => '標題',
	"article_alias" => '別名',
	"article_date" => '發文日期',
	"article_user" => '文章用戶',
	"article_featured" => '精選文章',
	"article_last_edited" => '文章最後編輯',
	"article_index_cb" => '文章索引複選框',
	);
	

?>