<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Chinese	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:42
//File: core/data_handler/includes/modules/read/calendar_events/language/chinese.php
//Source-Language: english

$module_lang = array(
	"roleid" => '角色ID',
	"duration" => '註冊時間',
	"date" => '日期',
	"html_weekday" => '星期幾',
	"name" => '名稱',
	"creator" => '作者',
	"calendar" => '日曆',
	"edit" => '',
	"html_time_start" => '開始',
	"html_time_end" => '結束',
	"raid_event" => '事件',
	"notes" => '備註',
	"detailslink" => '',
	);
	$preset_lang = array(
	"calevents_id" => '事件ID',
	"calevents_date" => '活動日期',
	"calevents_weekday" => '活動星期幾',
	"calevents_duration" => '活動持續時間',
	"calevents_name" => '活動名稱',
	"calevents_creator" => '活動創建者',
	"calevents_calendar" => '活動日曆',
	"calevents_edit" => '日曆活動',
	"calevents_start_time" => '活動開始時間',
	"calevents_end_time" => '活動結束時間',
	"calevents_raid_event" => '團隊事件',
	"calevents_note" => '活動備忘',
	"calevents_detailslink" => '事件詳細資訊',
	);
	

?>