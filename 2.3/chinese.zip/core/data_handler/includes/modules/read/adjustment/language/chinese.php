<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Chinese	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:42
//File: core/data_handler/includes/modules/read/adjustment/language/chinese.php
//Source-Language: english

$module_lang = array(
	"date" => '日期',
	"link" => '原因',
	"event_name" => '事件',
	"m4agk4a" => '角色',
	"value" => '值',
	"raid_id" => 'Raids',
	"editicon" => '',
	"reason" => '原因',
	"member_name" => '角色',
	);
	$preset_lang = array(
	"adj_date" => '調整日期',
	"adj_reason_link" => '調整原因（已連結）',
	"adj_event" => '調整事件',
	"adj_members" => '調整角色',
	"adj_value" => '調整值',
	"adj_raid" => '調整團隊',
	"adj_reason" => '調整原因',
	"adjedit" => '調整編輯按鈕',
	"adj_member" => '調整角色',
	);
	

?>