<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Chinese	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:42
//File: core/data_handler/includes/modules/read/member/language/chinese.php
//Source-Language: english

$module_lang = array(
	"name" => '名稱',
	"editbutton" => '',
	"memberlink" => '名稱',
	"memberlink_detail_twink" => '名稱',
	"rankname" => 'Rank',
	"rankname_sortid" => 'Rank',
	"rankimage" => 'Rank圖案',
	"rankname_detail_twink" => 'Rank',
	"active" => '狀態',
	"active_detail_twink" => '狀態',
	"classname" => '職業',
	"classname_detail_twink" => '職業',
	"racename" => '種族',
	"racename_detail_twink" => '種族',
	"level" => '等級',
	"level_detail_twink" => '等級',
	"twink" => '類型',
	"twink_detail_twink" => '類型',
	"mainname" => '主要',
	"summed_up" => '總和',
	"char_defrole" => '默認角色',
	"member_menu" => '',
	"mainchar_radio" => '<i class="fa fa-star fa-lg not-sortable" title="Mainchar"></i>',
	"name_decorated" => '角色名字',
	"memberlink_decorated" => '角色名字',
	"last_update" => '最後更新',
	"defaultrole" => '角色',
	"raidgroups" => 'Raid群組',
	"picture" => '頭像',
	"user" => '用戶',
	);
	$preset_lang = array(
	"mname" => '角色名字',
	"mlink" => '人物連結',
	"mlevel" => '角色等級',
	"mrace" => '角色種族',
	"mrank" => '角色等級',
	"mrankimg" => '等級圖像',
	"mactive" => '活動狀態',
	"mcname" => '類別名稱',
	"mtwink" => '角色類型',
	"mlink_dt" => '人物連結',
	"mlevel_dt" => '角色等級',
	"mrace_dt" => '角色種族',
	"mrank_dt" => '角色等級',
	"mactive_dt" => '活動狀態',
	"mcname_dt" => '類別名稱',
	"mlink_decorated" => 'Character link (decorated)',
	"last_update" => '最後角色更新',
	"medit" => '編輯連結',
	"cdefrole" => '默認角色選擇',
	"mrank_sortid" => '排序ID',
	"charname" => '角色名稱',
	"mmainname" => '主要角色名稱',
	"picture" => '角色圖像',
	"note" => '角色說明',
	"muser" => '角色名稱',
	"charmenu" => '角色選單',
	"cmainchar" => '單選框 主要角色',
	"mrole" => '角色職業',
	"mraidgroups" => '角色Raid群組',
	);
	

?>