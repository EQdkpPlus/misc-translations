<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Chinese	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:42
//File: core/data_handler/includes/modules/read/item/language/chinese.php
//Source-Language: english

$module_lang = array(
	"date" => '日期',
	"buyer_name" => '購買者',
	"buyer_link" => '購買者',
	"value" => '值',
	"name" => '名稱',
	"itempool_name" => '物品池',
	"link" => '名稱',
	"raidlink" => 'Raid',
	"m4igk4i" => '購買者',
	"raididlink" => 'Raid',
	"link_itt" => '名稱',
	"editicon" => '',
	"droprate" => '掉落率',
	);
	$preset_lang = array(
	"idate" => '物品日期',
	"ilink" => '物品連結',
	"ibuyers" => '物品購買者',
	"ibuyerlink" => '物品購買者 (連結)',
	"iraididlink" => '物品 Raid (詳細)',
	"ivalue" => '物品價值',
	"ipoolname" => '項目池名稱',
	"iraidlink" => '物品 Raid',
	"iname" => '物品名稱',
	"ibuyername" => '物品購買者',
	"ilink_itt" => '物品連結-ITT',
	"itemsedit" => '物品編輯按鈕',
	"idroprate" => '物品掉落率（用於項目池）',
	);
	

?>