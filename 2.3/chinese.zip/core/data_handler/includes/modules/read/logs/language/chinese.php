<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Chinese	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:42
//File: core/data_handler/includes/modules/read/logs/language/chinese.php
//Source-Language: english

$module_lang = array(
	"date" => '日期',
	"tag" => '類型',
	"plugin" => '插件',
	"user" => '用戶',
	"ipaddress" => 'IP位置',
	"result" => '結果',
	"viewicon" => '',
	"record" => '數據庫',
	"recordid" => '數據庫ID',
	"value" => '值',
	);
	$preset_lang = array(
	"logdate" => '記錄日期',
	"logtype" => '日誌類型',
	"logplugin" => '日誌插件',
	"loguser" => '日誌用戶',
	"logipaddress" => '記錄IP位置',
	"logresult" => '記錄結果',
	"viewlog" => '日誌查看按鈕',
	"logrecord" => '日誌數據庫',
	"logrecordid" => '日誌數據庫ID',
	"logvalue" => '登錄',
	);
	

?>