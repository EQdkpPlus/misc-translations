<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Chinese	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:42
//File: core/data_handler/includes/modules/read/calendar_raids_attendees/language/chinese.php
//Source-Language: english

$module_lang = array(
	"html_status" => '',
	"html_calstat_lastraid" => '最後的Raid',
	"html_calstat_raids_confirmed" => '參加',
	"html_calstat_raids_signedin" => '簽到',
	"html_calstat_raids_signedoff" => '簽核',
	"html_calstat_raids_backup" => '後備',
	"calstat_raids_confirmed_fromto" => '參加',
	"calstat_raids_signedin_fromto" => '簽到',
	"calstat_raids_signedoff_fromto" => '簽核',
	"calstat_raids_backup_fromto" => '後備',
	"calstat_raids_total_fromto" => '全部',
	);
	$preset_lang = array(
	"raidattendees_status" => '團隊參與者狀態',
	"raidcalstats_lastraid" => '最後Raid',
	"raidcalstats_raids_confirmed_90" => 'Raid已確認（90天）',
	"raidcalstats_raids_signedin_90" => 'Raids登錄（90天）',
	"raidcalstats_raids_signedoff_90" => 'Raids 發佈 (90天)',
	"raidcalstats_raids_backup_90" => 'Raids備份（90天）',
	"raidcalstats_raids_confirmed_60" => 'Raids已確認（60天）',
	"raidcalstats_raids_signedin_60" => 'Raids登錄（60天）',
	"raidcalstats_raids_signedoff_60" => ' Raids發佈（60天）',
	"raidcalstats_raids_backup_60" => 'Raids備份（60天）',
	"raidcalstats_raids_confirmed_30" => 'Raids確認（30天）',
	"raidcalstats_raids_signedin_30" => 'Raids登錄（30天）',
	"raidcalstats_raids_signedoff_30" => 'Raids發佈（30天）',
	"raidcalstats_raids_backup_30" => 'Raids備份（30天）',
	"raidcalstats_raids_confirmed_fromto" => 'Raids已確認（默認天數）',
	"raidcalstats_raids_signedin_fromto" => 'Raids登錄（默認天數）',
	"raidcalstats_raids_signedoff_fromto" => 'Raids發佈（默認天數）',
	"raidcalstats_raids_backup_fromto" => 'Raids備份（默認天數）',
	);
	

?>