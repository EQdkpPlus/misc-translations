<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Chinese	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:42
//File: core/data_handler/includes/modules/read/member_attendance/language/chinese.php
//Source-Language: english

$module_lang = array(
	"attendance" => 'Raids（％d天）',
	"lifetime" => 'Raids(全部)',
	"attendance_fromto" => 'Raids出席',
	);
	$preset_lang = array(
	"attendance_30" => 'Raids出席（ˊ30天）',
	"attendance_60" => 'Raids出席（ˊˊˊ60天）',
	"attendance_90" => 'Raids出席（ˊ90天）',
	"attendance_30_real" => 'Raids出席（30天，基於創建時間）',
	"attendance_60_real" => 'Raids出席（60天，基於創建時間）',
	"attendance_90_real" => 'Raids出席（90天，基於創建時間）',
	"attendance_lt" => 'Raids出席率（全部）',
	"attendance_lt_real" => 'Raid出席率（生命週期，基於創建時間）',
	"attendance_fromto_all" => 'Raid出席（默認天數',
	);
	

?>