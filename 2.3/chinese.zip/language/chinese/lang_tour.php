<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Chinese	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:43
//File: language/chinese/lang_tour.php
//Source-Language: english

$lang = array( 
	"navi" => '<ul><li><a href="?tour=next"><b>繼續此導覽</b></a></li><li><a href="?tour=reload">重新開始此步驟</a></li><li><a href="?tour=cancel">退出導覽</a></li></ul>',
	"navi_title" => 'EQdkp Plus 導覽',
	"steps" => '第 %d 步，共 %d 步',
	"step_0" => '歡迎來到EQdkp Plus！<br /> <br />將向您展示我們CMS和DKP系統最重要的功能。<br /> <ul> <li>設置</ li> <li>插件</ li> <li>模塊</ li> <li>用戶管理</ li> <li>團隊管理</ li> < li>佈局/ DKP系統</ li> <li>創建CMS頁面</ li> <li>備份</ li> </ ul>',
	"step_0_title" => '開始',
	"step_1" => '在此頁面上，您可以配置EQdkp Plus。例如，您將看到<ul> <li>佈局設置（如頁面標題）的設置</ li> <li>遊戲設置（如遊戲名稱，服務器名稱，... </ li> <li>聯絡資訊</ </ li> <li>電子郵件設置</ li> <li>註冊設置（即CAPTCHA）</ li> <li> 物品統計設置</ li> </ ul>',
	"step_1_title" => '設定值',
	"step_2" => '插件是擴展EQdkp Plus功能的擴展。要安裝插件，只需單擊“安裝”。<br /> <br />建議的插件：<ul> <li> Raidlogimport：從遊戲中的插件導入RAID日誌</ li> </ ul>',
	"step_2_title" => '插件',
	"step_3" => '使用CMS的模塊，您可以在前端放置一些有趣的信息。例如：<ul> <li>團隊講話或其他語音服務器</ li> <li>最近的戰鬥日誌</ li> <li>即將到來的生日</ li> <li>天氣預報</ li> </ ul>等等 <br>通過使用“定位”標籤，您可以將每個模塊移動到前端應顯示的位置。<br> <br>使用步驟1中的設置，您還可以設置每個列應顯示的列頁而不是標準行為的索引頁。',
	"step_3_title" => '頁面模塊',
	"step_4" => '這是用戶管理。例如，您可以激活由於註冊設置而仍處於非活動狀態的用戶。<br /> <br />如果您首先分配一個角色，則該用戶只能申請Raid並收集DKP點數。<br /> < br />您還可以在此處管理用戶權限。這意味著您可以選擇允許每個用戶在EQdkp Plus中執行的操作。<br />您可以通過為該用戶分配不同的用戶組或單獨管理其權限來做到這一點。<br /> <br />未註冊的用戶是“訪客”用戶組的組成部分，您可以使用它來管理他們的權限。<br> <br>如果您想獲得有關權限的更多信息，請查看<a href =“ http：// eqdkp- plus.eu/wiki//de/index.php/Benutzergruppen“ target =” _ blank“',
	"step_4_title" => '用戶管理',
	"step_5" => '通常，Raid用於將DKP點分配給角色。日期、事件、DKP值，當然還有參與者（應該獲得DKP積分的角色）都是在團隊中設置的。<br>此外，您還可以將物品分發給角色並從他們的帳戶中扣除相應的積分。也可以進行個別調整。<br /> <br />如果您使用遊戲中的插件來記錄Raid，我們會使用插件“ Raidlogimport”自動為您創建Raid。<br /> <br />如果您想了解有關Raid的更多信息，請查看<a href =“ http://eqdkp-plus.eu/wiki//de/index.php/Ein_Beispielraid” target =“ _ blank” style =“ color：＃000;” >此Wiki頁面</a>。',
	"step_5_title" => '管理Raid',
	"step_6" => '由於每個人都有自己的EQdkp plus外觀或使用哪種DKP積分系統的要求，因此您可以在此處選擇EQdkp plus的外觀，您可以在各個頁面中定義的每個標籤中顯示哪些',
	"step_6_title" => '管理頁面',
	"step_7" => 'CMS當然具有創建自己內容的能力。<br>借助我們廣泛的編輯器和媒體管理器，大多數內容創建需求都得到了滿足。<br> <br>此外，您還可以設置每個用戶的公會規章必須接受才能註冊',
	"step_7_title" => '建立文章',
	"step_8" => '許多人都經歷過系統故障、數據丟失和備份缺失<br /> <br />這不再發生了！<br /> <br />除了從備份中恢復之外，您現在還可以設置自動備份作業。轉到“計劃工作管理”來設置選項。<br /> <br />如果您想要有關備份的更多資訊，請查看<a href =“ http://eqdkp-plus.eu/wiki// de / index.php / Sicherung“ target =” _ blank“ style =” color：＃000;“>此Wiki頁面</a>。',
	"step_8_title" => '備份',
	"step_9" => '非常感謝您採用EQdkp Plus。<br> <br>有關其他問題，請查看<ul> <li>我們的<a href =“ http://eqdkp-plus.eu/wiki/” style =“ color：＃000“> Wiki </a> </ li> <li>和<a href="http://eqdkp-plus.eu/forum" style="color:#000">論壇</a> 。</ li> </ ul>您可以隨時通過轉到管理部分主頁上的“支持”標籤再次進行此導覽。<br /> <br />“玩得開心”-整個EQdkp Plus團隊',
	"step_9_title" => '結束',
	
);

?>