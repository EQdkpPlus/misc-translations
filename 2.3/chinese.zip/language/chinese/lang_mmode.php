<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Chinese	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:43
//File: language/chinese/lang_mmode.php
//Source-Language: english

$lang = array( 
	"click2show" => '（單擊以顯示）',
	"maintenance_mode" => '維護模式',
	"task_manager" => '任務管理器',
	"admin_acp" => '管理員控制面板',
	"activate_info" => '<h1>啟用維護模式</ h1> <br />使用此維護工具，您可以輕鬆更新EQdkp並從舊版本導入數據。<br />只有在維護模式為已啟用並拒絕用戶登錄以防止出現錯誤和問題。<br /> <br />原因，顯示給用戶（不是必需的）：<br />',
	"activate_mmode" => '啟用維護模式',
	"deactivate_mmode" => '關閉維護模式',
	"leave_mmode" => '取消',
	"home" => '首頁',
	"no_leave" => '只要需要執行所需的任務，就不能停用維護模式',
	"no_leave_accept" => '返回任務概述',
	"maintenance_message" => '<b> EQdkp Plus系統當前正在維護模式下運行。</ b>只有管理員才能登錄',
	"reason" => '<br /><b>原因:</b>',
	"admin_login" => '管理員登錄',
	"login" => '登錄',
	"username" => '用戶',
	"password" => '密碼',
	"remember_password" => '記住密碼?',
	"invalid_login_warning" => '登錄無效！請驗證您的用戶名和密碼。僅管理員用戶可以登錄！',
	"is_necessary" => '必要?',
	"is_applicable" => '適用嗎?',
	"name" => '名稱',
	"version" => '版本',
	"author" => '作者',
	"link" => '處理任務',
	"description" => '描述',
	"type" => '任務類型',
	"yes" => '是',
	"no" => '否',
	"click_me" => '處理任務',
	"mmode_info" => '您的系統當前處於維護模式，並且在您禁用維護模式之前，拒絕普通用戶訪問',
	"necessary_tasks" => '必要更新',
	"applicable_tasks" => '不必要/已經處理的更新',
	"not_applicable_tasks" => '不適用的更新',
	"no_nec_tasks" => '沒有必要的更新',
	"nec_tasks" => '以下更新是必需的。請進行處理，以使系統進入最新狀態',
	"nec_tasks_available" => '請處理必要的更新以使系統進入最新狀態',
	"applicable_warning" => '此更新不適用！處理可能會導致數據丟失！僅在絕對確定的情況下處理此更新！',
	"executed_tasks" => '已為更新 "%s" 處理了以下操作',
	"stepend_info" => '更新已完成。EQdkp Plus仍處於維護模式，因此您可以測試所有內容。只有在關閉維護模式後，用戶才可以再次登錄',
	"mmode_pfh_error" => '發生了一些錯誤。您需要修正這些錯誤以關閉維護模式。',
	"lib_cache_notwriteable" => '無法寫入文件夾“data”。請將文件夾權限設置為CHMOD 777！',
	"fix" => '修復',
	"update" => '核心更新',
	"import" => '導入',
	"plugin_update" => '插件更新',
	"game_update" => '遊戲更新',
	"worker" => '工作',
	"unknown_task_warning" => '未知更新!',
	"application_warning" => '由於應用程序錯誤，無法處理更新！',
	"dependency_warning" => '這個更新是從其他上來的。請先處理它們！',
	"start_here" => '從這裡開始！',
	"following_updates_necessary" => '以下更新是必要的：',
	"start_update" => '處理所有必要的更新！',
	"only_this_update" => '僅處理此更新：',
	"start_single_update" => '處理更新',
	"backup" => '數據庫備份',
	"backup_note" => '數據庫備份已在 %s 建立',
	"support_eqdkplus" => '您可以通過以下方式回饋：<ul> <li> <i class =“ fa fa-puzzle-piece”> </ i> <a href =“ http://eqdkp-plus.eu/repository/ “>發布插件或模板，以便每個EQdkp Plus用戶都可以使用它</a> </ li> <li> <i class =” fa fa-comments“> </ i> <a href =” http：/ /eqdkp-plus.eu/forum /“>在董事會中支持我們</a> </ li> <li> <i class =” fa fa-cogs“> </ i> <a href =” http：/ /eqdkp-plus.eu/en/development.html“>積極參與EQdkp Plus的開發</a> </ li> <li> <i class =” fa fa-usd“> </ i> <',
	
);

?>