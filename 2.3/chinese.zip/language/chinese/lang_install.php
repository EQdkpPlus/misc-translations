<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Chinese	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:43
//File: language/chinese/lang_install.php
//Source-Language: english

$lang = array( 
	"page_title" => 'EQDKP-PLUS %s 安裝',
	"back" => '儲存並返回',
	"continue" => '繼續',
	"language" => '語言',
	"inst_finish" => '完成安裝',
	"error" => '錯誤',
	"warning" => '警告',
	"success" => '成功',
	"yes" => '是',
	"no" => '沒有',
	"retry" => '重試',
	"skip" => '跳過',
	"step_order_error" => '步驟順序錯誤：找不到步驟。請確保正確上傳所有文件。有關更多資訊，請訪問我們的論壇，網址為<a href="http://eqdkp-plus.eu/forum">http://eqdkp-plus.eu/forum</a>',
	"licence" => '許可協議',
	"php_check" => '安裝前檢查',
	"file_permissions" => '文件和文件夾權限',
	"encryptionkey" => '加密金鑰',
	"data_folder" => '資料夾',
	"db_access" => '數據庫訪問',
	"inst_settings" => '設定',
	"admin_user" => '管理員帳號',
	"end" => '完成安裝',
	"welcome" => '歡迎使用EQdkp Plus的安裝程序。我們努力使此安裝過程變得容易和快速。要開始使用，只需單擊下面的“接受並開始安裝”，接受我們的許可協議',
	"accept" => '接受並開始安裝',
	"license_text" => '<b> EQdkp Plus是根據AGPL v3.0許可發布的。</ b> <br /> <br />完整的許可文本可在<a href =“ http://opensource.org/licenses/AGPL -3.0“ target =” _blank“> http://opensource.org/licenses/AGPL-3.0 </a>。<br /> <br />這是AGPL v3.0最重要術語的摘要。 。沒有任何完整性和正確性的聲明。<br /> <br /> <h3> <strong>您被允許：</ strong> </ h3> <ul> <li>將此軟件用於商業用途</ li> <li>分發此軟件</ li> <li>修改此軟件</ li> </ ul> <h3> <strong>您需要：</ strong> </ h3> <ul> < li>公開使用EQdkp Plus的完整應用程序的源代碼',
	"table_pcheck_name" => '名稱',
	"table_pcheck_required" => '需要',
	"table_pcheck_installed" => '當前',
	"table_pcheck_rec" => '推薦',
	"module_php" => 'PHP版本',
	"module_mysql" => 'MySQL數據庫',
	"module_zLib" => 'zLib PHP模塊',
	"module_curl" => 'cURL PHP模塊',
	"module_fopen" => 'fopen PHP函數',
	"module_soap" => 'SOAP PHP模塊',
	"module_autoload" => 'spl_autoload_register PHP函數',
	"module_hash" => 'hash PHP函數',
	"module_memory" => 'PHP內存限制',
	"module_json" => 'JSON PHP模塊',
	"module_gd" => 'GD Image PHP模塊',
	"module_pathinfo" => '路徑資訊支持',
	"module_zip" => 'Zip PHP模塊',
	"module_xml" => 'XML PHP模塊',
	"module_mb" => 'MultiByte PHP模塊',
	"module_crypto" => '加密方法',
	"phpcheck_success" => '滿足安裝EQDKP-Plus的最低要求，安裝可以繼續',
	"phpcheck_failed" => '無法滿足安裝EQDKP-Plus的最低要求。<br />可以在我們的<a href="http://eqdkp-plus.eu" target="_blank">中找到合適的託管公司、網站</a>',
	"do_match_opt_failed" => '沒有達到建議要求，EQDKP-Plus將在此系統上運行；但是，也許並非所有功能都可用',
	"ftphost" => 'FTP主機',
	"ftpport" => 'FTP端口',
	"ftpuser" => 'FTP用戶名',
	"ftppass" => 'FTP密碼',
	"ftproot" => 'FTP基本目錄',
	"ftproot_sub" => '（FTP用戶根目錄的路徑）',
	"useftp" => '使用FTP模式作為文件處理程序',
	"useftp_sub" => '（您可以稍後通過編輯config.php對其進行更改）',
	"ftp_connectionerror" => '無法建立FTP連接，請檢查FTP主機和FTP端口',
	"ftp_loginerror" => 'FTP登錄失敗，請檢查您的FTP用戶名和FTP密碼',
	"plain_config_nofile" => '文件<b> config.php </ b>不可用，自動建立失敗。<br />請建立一個名為<b> config.php </ b>的空白文本文件，並使用chmod 777設置權限',
	"plain_config_nwrite" => '<b> config.php </ b>文件不可寫。<br />請設置正確的權限。<b> chmod 0777 config.php </ b>',
	"plain_dataf_na" => '文件夾<b> '.registry::get_const('root_path').' data / </ b>不可用。<br />請建立此文件夾。<b> mkdir數據</ b>',
	"plain_dataf_nwrite" => '文件夾<b> '.registry::get_const('root_path').' data / </ b>無法寫入。<br />請設置正確的權限。<b> chmod -R 0777數據</ b>',
	"ftp_datawriteerror" => '無法寫入數據文件夾。FTP根路徑設置正確嗎?',
	"ftp_info" => '您可以使用ftp帳戶在服務器上執行文件交換，而無需設置所需的文件和文件夾權限。要使用此可選設置，請為ftp用戶提供訪問安裝的權限，然後選擇“ FTP模式”複選框。如果您未使用FTP模式，則只需在此頁面上選擇繼續即可',
	"ftp_tmpinstallwriteerror" => '<b> '.registry::get_const('root_path').'文件夾data/97384261b8bbf966df16e5ad509922db/tmp/ </ b>是不可寫的。<br />要寫入配置文件，需要CHMOD 777。安裝過程完成後，該文件夾將被刪除',
	"ftp_tmpwriteerror" => '文件夾<b>'.registry::get_const('root_path').'data/%s/tmp/</b>是不可寫的<br />使用FTP模式需要為此文件夾使用CHMOD 777，這是唯一需要寫權限的文件夾',
	"fp_data_folder" => '文件夾“data”存在且可寫入',
	"fp_config_file" => '文件“ config.php”存在並且可寫入',
	"fp_test_file" => '測試文件已編寫並可使用',
	"dbtype" => '數據庫類型',
	"dbhost" => '數據庫主機',
	"dbname" => '數據庫名稱',
	"dbuser" => '數據庫用戶名',
	"dbpass" => '數據庫密碼',
	"dbport" => '數據庫端口',
	"dbport_help" => '默認端口是3306',
	"table_prefix" => 'EQDKP-Plus表的前綴',
	"test_db" => '測試數據庫',
	"prefix_error" => '沒有指定或無效的數據庫前綴！請輸入有效的前綴',
	"INST_ERR_PREFIX" => '具有該前綴的EQdkp安裝已存在。刪除所有帶有該前綴的表，並在使用“上一步”按鈕後重複此步驟。或者，您可以選擇其他前綴，例如，如果要在數據庫中安裝多套EQDKPlus數據',
	"INST_ERR_PREFIX_INVALID" => '您指定的表前綴對於您的數據庫無效，請嘗試另一個',
	"dbcheck_success" => '已檢查數據庫，它沒有發現錯誤或衝突，可以安全地繼續安裝',
	"encryptkey_info" => '加密密鑰是加密過程的一部分，該過程用於保護數據庫中的敏感數據，例如用戶的電子郵件地址。即使您的數據庫遭到破壞，如果沒有加密密鑰，您的數據也會保持編碼和安全。因此，請選擇一個安全密鑰，並確保存儲安全副本。如果丟失了，沒人能為您找回！',
	"encryptkey" => '加密密鑰',
	"encryptkey_help" => '（最小長度6個字串）',
	"encryptkey_repeat" => '確認加密密鑰',
	"encryptkey_no_match" => '加密密鑰不匹配',
	"encryptkey_too_short" => '加密密鑰太短。最小長度為6個字串',
	"inst_db" => '安裝數據庫',
	"lang_config" => '語言設定',
	"default_lang" => '預設語言',
	"default_locale" => '默認本地化',
	"game_config" => '遊戲設置',
	"default_game" => '默認遊戲',
	"server_config" => '伺服器設定',
	"server_path" => 'Script路徑',
	"grp_guest" => 'Guests',
	"grp_super_admins" => 'Super administrators',
	"grp_admins" => 'administrators',
	"grp_officers" => 'officers',
	"grp_writers" => 'Editors',
	"grp_member" => 'Members',
	"grp_guest_desc" => '訪客-未登錄用戶',
	"grp_super_admins_desc" => '超級管理員-擁有所有權限',
	"grp_admins_desc" => '管理員-擁有部分管理權限',
	"grp_officers_desc" => '幹部-可以管理Raid',
	"grp_writers_desc" => '編輯者-可以撰寫和管理新聞',
	"grp_member_desc" => '會員',
	"game_info" => '安裝後，可以在擴展管理器上下載更多受支持的遊戲',
	"timezone" => '伺服器的時間',
	"startday" => '開始日',
	"sunday" => '週日',
	"monday" => '週一',
	"time_format" => 'H:i',
	"date_long_format" => 'j. F Y',
	"date_short_format" => 'd.m.y',
	"style_jsdate_nrml" => 'DD/MM/YYYY',
	"style_jsdate_short" => 'D.M',
	"style_jstime" => 'hh:mm tt',
	"welcome_news_title" => '歡迎使用EQDKP-Plus',
	"welcome_news" => '<p> EQdkp Plus的安裝已成功完成-您現在可以根據自己的意願進行設置。</p> <p>您可以在我們的<a href="http://eqdkp-plus.eu/wiki/" target="_blank">Wiki</a></p> <p>有關進一步的支持，請訪問我們的<a href="http://eqdkp-plus.eu/forum" target="_blank">論壇</a></p> <p>使用EQdkp Plus玩得開心！您的EQdkp Plus團隊</p>',
	"feature_news_title" => 'EQdkp Plus的新功能',
	"feature_news" => '<p>EQdkp Plus 2.3 contains a lot of new Features. This article should introduce the most importent of them.</p>
		<h3>Articlesystem</h3>
		<p>Instead of news and infopages, we introduced a complete new article system. Each news and page is now an article. You can group your articles using article-categories. Moreover, you can realise for example blogs for your guild and users.</p>
		<p>You can divide a single article using the Readmore- and Pagebreak-Methods. Also, you can insert Image-Galeries, Items or Raidloot using the appropriate Editor-Buttons.</p>
		<h3>Media-Management</h3> <p>Using the new Media-Management in ACP or Editor, you can now easily insert Media into your articles. For example, files can be uploaded using Drag&Drop. Also, you can even edit images in the Filebrowser.</p>
		<h3>Calendar</h3><p>Planing raids was never been easier by using Drag&Drop. Also, public and private events can be created, people can be invited and tell you if they participate or not.</p>
		<h3>Menu-Management</h3> <p>We have removed all menus except one. And the last one could be totally configured. You can position the entries using Drag&Drop in 3 levels, so it\'s possible to create submenus. You can still create links to external pages, but also add direct links to articles or articlecategories.</p>
		<h3>Portal-Management</h3> <p>In former times, there was only one portallayout, you had on every page the same portal modules. That\'s why we implemented the portallayouts. Now you can assign a portallayout to each articlecategory.</p>
		<p>Furthermore, you can create own portal blocks that you can embedd in your template, for example for editing links in your footer.</p>',
	"category1" => '系統',
	"category2" => '新聞',
	"category3" => '事件',
	"category4" => '物品',
	"category5" => 'Raids',
	"category6" => '日曆',
	"category7" => '名冊',
	"category8" => '點數',
	"category9" => '人物',
	"article5" => '人物',
	"article6" => '名冊',
	"article7" => '事件',
	"article8" => '物品',
	"article9" => '點數',
	"article10" => 'Raids',
	"article12" => '日曆事件',
	"article13" => '日曆',
	"article14" => '公會規則',
	"article15" => '隱私政策',
	"article16" => '法律聲明',
	"role_healer" => '治療者',
	"role_tank" => '坦克',
	"role_range" => '遠程DPS',
	"role_melee" => '近戰DPS',
	"create_user" => '建立存取權',
	"username" => '管理員用戶名',
	"user_password" => '管理員密碼',
	"user_pw_confirm" => '確認管理員密碼',
	"user_email" => '管理員電子郵件地址',
	"auto_login" => '記住我（cookie）',
	"user_required" => '用戶名，電子郵件和密碼是必填字段',
	"no_pw_match" => '密碼不匹配',
	"install_end_text" => '現在可以成功完成安裝',
	"windows_apache_hint" => '似乎您在Windows下使用Apache作為Web服務器。僅當您在Apache配置文件中將ThreadStackSize增加到8388608時，EQdkp Plus才能工作',
	"install_support_h1" => '支持EQdkp Plus',
	"install_support_text" => '如果我們可以收回在EQdkp Plus上投入的精力，時間和愛心，那麼只有EQdkp Plus這樣的項目才能存在。您可以通過以下方式回饋：<ul> <li> <i class =“ fa fa-puzzle-piece”> </ i> <a href =“ http://eqdkp-plus.eu/repository/ “>發布插件或模板，以便每個EQdkp Plus用戶都可以使用它</a> </ li> <li> <i class =” fa fa-comments“> </ i> <a href =” http：/ /eqdkp-plus.eu/forum /“>在董事會中支持我們</a> </ li> <li> <i class =” fa fa-cogs“> </ i> <a href =” https：/ /eqdkp-plus.eu/en/development.html“>積極參與EQdkp Plus的開發</a> </ li> <li> <i class =” fa fa-usd“> </ i> < a href =“ https://eqdkp-plus.eu/en/donate.html”>提供財務支持，以便我們繼續為您提供LiveUpdate之類的服務</a> </ li> </ ul> EQdkp Plus與我們一樣多，請考慮支持我們！<br /> <a href =“ https://eqdkp-plus.eu/Donate.html？” style =“ background：orange; border-radius：5px; padding：7px; display：inline-block; color：black;”> <i class =“ fa fa-paypal”> </ i>立即捐贈</a>',
	"additional_keys" => '附加功能',
	"additional_keys_info" => '我們使用其他提供商的功能，例如垃圾郵件防護。為了使用此功能，您需要自己的密鑰才能使用此功能。因此，您可以在以下頁面上創建自己的密鑰。<br /> <b>您當然可以跳過此步驟，並隨時在EQdkp Plus設置中插入密鑰。</ b>',
	"recaptcha_info" => 'reCATPCHA是垃圾郵件防護方法。啟用此方法可減少垃圾郵件並提高EQdkp Plus的安全性。您可以在此頁面上創建自己的密鑰：<br /> <a href="https://www.google.com/recaptcha/admin/create" target="_blank"> <i class =“ fa fa-lg fa-external-link“> </ i> https://www.google.com/recaptcha/admin/create </a>。創建新密鑰時，請僅使用受支持的類型。',
	"recaptcha_okey" => 'reCATPCHA的網站密鑰',
	"recaptcha_pkey" => 'reCATPCHA的私鑰',
	"recaptcha_type" => '類型',
	"delete_ownership_file" => '出於安全原因，請從EQdkp Plus根文件夾中刪除文件“ database_ownership_file.txt”以繼續安裝',
	"module_externalconnection" => '外部連結',
	
);

?>