<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Chinese	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:43
//File: plugins/raidlogimport/language/chinese/wow_lang.php
//Source-Language: english

$lang = array( 
	"difficulty" => '難度',
	"title_difficulty" => '難度設定',
	"diff_0" => '其他',
	"diff_1" => '普通',
	"diff_2" => '英雄',
	"diff_3" => '10人普通模式',
	"diff_4" => '25人普通模式',
	"diff_5" => '10人英雄模式',
	"diff_6" => '10人英雄模式',
	"diff_7" => '團隊瀏覽器',
	"diff_8" => '挑戰模式',
	"diff_9" => '40人團隊',
	"diff_11" => '英雄',
	"diff_12" => '普通',
	"diff_14" => '普通 (10-30 人)',
	"diff_15" => '英雄 (10-30 人)',
	"diff_16" => '神話 (20 人)',
	"dep_match" => '字尾也可以應用於首領筆記嗎？',
	
);

?>