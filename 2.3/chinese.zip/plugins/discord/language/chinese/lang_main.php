<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Chinese	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:43
//File: plugins/discord/language/chinese/lang_main.php
//Source-Language: english

$lang = array( 
	"discord" => 'Discord',
	"discord_short_desc" => '初始化Discord',
	"discord_long_desc" => '啟動EQdkp Plus和Discord之間的連接',
	"discord_plugin_not_installed" => '未安裝Discord-Plugin',
	"discord_fs_general" => '一般',
	"discord_f_guild_id" => '公會ID',
	"discord_f_help_guild_id" => '您可以從Guildserver的URL獲取Guild-URL。它是URL的第一個長數字。',
	"discord_f_bot_client_id" => 'Bot應用程序的客戶ID',
	"discord_f_help_bot_client_id" => '有關更多資訊和說明，請參閱https://eqdkp-plus.eu/wiki/Discord',
	"discord_f_bot_token" => 'Bot用戶的訪問令牌',
	"discord_f_help_bot_token" => '有關更多信息和說明，請參閱https://eqdkp-plus.eu/wiki/Discord',
	"discord_autorize_bot" => '將Bot添加到公會服務器',
	"discordlatestposts" => '最新Discord訊息',
	"discordlatestposts_name" => '最新Discord訊息',
	"discordlatestposts_desc" => '顯示您選擇的Discord頻道中的最新訊息',
	"discord_f_amount" => '顯示的訊息數',
	"discord_f_blackwhitelist" => '黑名單或白名單',
	"discord_f_help_blackwhitelist" => '拒絕插入的論壇ID（列入黑名單）或接受它們（列入白名單）',
	"discord_f_cachetime" => '訊息的緩存時間',
	"discord_f_help_privateforums2" => '選擇黑名單/白名單使用的顯示用戶組的論壇',
	"discordlatestposts_noselectedboards" => '未選擇頻道',
	"discordlatestposts_noentries" => '沒有可用的訊息',
	
);

?>