<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Chinese	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:43
//File: plugins/guildbank/pdh/read/guildbank_auctions/language/chinese.php
//Source-Language: english

$module_lang = array(
	"startdate" => '開始日期',
	"startvalue" => '起始值',
	"name" => '物品',
	"duration" => '持續時間',
	"bidsteps" => '競標步驟',
	"note" => '備註',
	"active" => '',
	"edit" => '',
	"auctionlink" => '',
	"atime_left" => '剩餘時間',
	"atime_left_html" => '剩餘時間',
	"highest_bidder" => '最高出價者',
	"highest_value" => '最高出價',
	);
	$preset_lang = array(
	"gb_astartdate" => '日期',
	"gb_astartvalue" => '起始值',
	"gb_aname" => '物品',
	"gb_aduration" => '持續時間',
	"gb_abidsteps" => '競標步驟',
	"gb_anote" => '備註',
	"gb_aactive" => '啟用',
	"gb_aedit" => '編輯',
	"gb_aalink" => '拍賣按鈕',
	"atime_left" => '剩餘時間',
	);
	

?>