<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Chinese	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:43
//File: plugins/guildbank/pdh/read/guildbank_auction_bids/language/chinese.php
//Source-Language: english

$module_lang = array(
	"date" => '日期',
	"member" => '投標人',
	"bidvalue" => '投標',
	"highest_bidder" => '最高出價者',
	"highest_value" => '最高出價',
	);
	$preset_lang = array(
	"gb_biddate" => '競標日期',
	"gb_bidmember" => '投標人',
	"gb_bidvalue" => '投標',
	"gb_bidhibidder" => '最高出價者',
	"gb_bidhivalue" => '最高出價',
	);
	

?>