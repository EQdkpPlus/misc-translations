<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Chinese	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:43
//File: plugins/epgpimport/language/chinese/lang_main.php
//Source-Language: english

$lang = array( 
	"epgpimport" => 'EPGP導入',
	"epgpimport_import" => '導入EPGP日誌',
	"epgpimport_short_desc" => 'EPGP 匯入者',
	"epgpimport_long_desc" => '從遊戲中的插件導入您的EPGP日誌',
	"epgpimport_error_nolog" => '沒有提供EPGP日誌',
	"epgpimport_error_wrongformat" => 'EPGP-Log無法導入，可能已損壞，格式錯誤或已導入較新的格式。',
	"epgpimport_layoutwarning" => '您不使用EPGP佈局。這可能會導致導入不正確。請轉到<a href="'.registry::get_const('root_path').'admin/manage_pagelayouts.php'.registry::get_const('SID').'"> Pagelayout-Management </a>並選擇一個EPGP佈局。',
	"epgpimport_success" => 'EPGP-Log已成功導入。',
	"epgpimport_error_more_mdkp4event" => '無法導入EPGP-Log，因為所選事件屬於多個MultiDKP-Pool。',
	
);

?>