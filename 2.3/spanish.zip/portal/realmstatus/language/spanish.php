<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Spanish	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:48
//File: portal/realmstatus/language/spanish.php
//Source-Language: english

$lang = array( 
	"realmstatus" => 'Estado de los Reinos',
	"realmstatus_name" => 'Estado de los Reinos',
	"realmstatus_desc" => 'Muestra del estado actual del reino',
	"realmstatus_f_realm" => 'Lista de Reinos',
	"realmstatus_f_help_realm" => 'Para múltiples reinos. Los reinos deben estar separados por una coma',
	"realmstatus_f_us" => '¿Es un reino estadounidense (US)?',
	"realmstatus_f_help_us" => 'Esta opción sólo tiene efectos si RIFT o WoW está configurado como un juego.',
	"realmstatus_f_gd" => 'GD Lib %s encontrada. ¿Quieres usarla?',
	"realmstatus_f_help_gd" => 'Esta configuración solo afecta al juego de World of Warcraft',
	"rs_no_realmname" => 'Reino no especificado',
	"rs_realm_not_found" => 'Reino no encontrado',
	"rs_game_not_supported" => 'El estado del Reino no se admite para el juego actual',
	"rs_unknown" => 'Desconocido',
	"rs_realm_status_error" => 'Los errores ocurrieron mientras determinabamos el estado del reino para %1$s',
	"rs_loading" => 'Cargando Antigüedad...',
	"rs_loading_error" => 'Error al cargar el Estado',
	"realmstatus_wow_population_new" => 'New',
	"realmstatus_wow_population_low" => 'Low',
	"realmstatus_wow_population_medium" => 'Medium',
	"realmstatus_wow_population_high" => 'High',
	"realmstatus_wow_population_full" => 'Full',
	"realmstatus_wow_population_unknown" => 'Unknown',
	"realmstatus_wow_population_locked" => 'Locked',
	
);

?>