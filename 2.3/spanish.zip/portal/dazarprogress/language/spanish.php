<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Spanish	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:48
//File: portal/dazarprogress/language/spanish.php
//Source-Language: english

$lang = array( 
	"dazarprogress" => 'Dazar\'alor progress',
	"dazarprogress_name" => 'Dazar\'alor progress',
	"dazarprogress_desc" => 'Take here the right value of your progress for each boss.',
	"dazarprogress_f_boss1" => 'Champions of the Light',
	"dazarprogress_f_boss2" => 'Jadefire Masters',
	"dazarprogress_f_boss3" => 'Grong the Revenant',
	"dazarprogress_f_boss4" => 'Opulence',
	"dazarprogress_f_boss5" => 'Conclave of the Chosen',
	"dazarprogress_f_boss6" => 'King Rastakhan',
	"dazarprogress_f_boss7" => 'High Tinker Mekkatorque',
	"dazarprogress_f_boss8" => 'Stormwall Blockade',
	"dazarprogress_f_boss9" => 'Lady Jaina Proudmoore',
	"dazar_no" => 'open',
	"dazar_nhc" => 'normal',
	"dazar_hc" => 'heroic',
	"dazar_myth" => 'mythic',
	"test" => array(
	0 => 'Open',
	1 => 'Normal',
	2 => 'Heroic',
	3 => 'Mythic',
	),
	
);

?>