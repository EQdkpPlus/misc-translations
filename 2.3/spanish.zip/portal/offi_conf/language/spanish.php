<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Spanish	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:48
//File: portal/offi_conf/language/spanish.php
//Source-Language: english

$lang = array( 
	"offi_conf" => 'Reunión Oficial - Temas',
	"offi_conf_name" => 'Módulo de Reuniones Oficiales',
	"offi_conf_desc" => 'Los administradores pueden publicar temas en las Reuniones Oficiales',
	"oc_f_day" => 'Día de la Conferencia ',
	"oc_f_end_time" => 'final deseado de la reunión oficial (HH:MM)',
	"oc_f_start_time" => 'quería empezar la reunión oficial (HH:MM)',
	"oc_f_time_type" => 'Definir inicio o final de la reunión oficial',
	"oc_f_date" => 'Fecha de la próxima reunión oficial',
	"oc_f_period2" => 'Reunión oficial cada "x" semanas',
	"oc_f_period3" => 'Reunión oficial cada día "x" del a semana del mes',
	"oc_f_type" => 'Repetir todo',
	"oc_weekday" => 'en un determinado día de la semana',
	"oc_xmonthday" => 'en el "x" día de la semana del mes',
	"oc_manual" => 'fecha de entrada manual de',
	"oc_monday" => 'Lunes',
	"oc_tuesday" => 'Martes',
	"oc_wednesday" => 'Miércoles',
	"oc_thursday" => 'Jueves',
	"oc_friday" => 'Viernes',
	"oc_saturday" => 'Sábado',
	"oc_sunday" => 'Domingo',
	"oc_add_topic" => 'Agregar tema',
	"oc_upd_topic" => 'Editar Tema',
	"oc_next_topics" => 'Tema siguientes',
	"oc_topic_name" => 'Nombre',
	"oc_topic_time" => 'Tiempo para hablar (min)',
	"oc_topic_posi" => 'Clasificación',
	"oc_topic_desc" => 'Descripción',
	"oc_save" => 'Guardar',
	"oc_delete" => 'Borrar',
	"oc_save_success" => 'Datos salvados satisfactoriamente',
	"oc_save_no_success" => 'Datos NO salvados satisfactoriamente',
	"oc_delete_success" => 'Borrado satisfactorio',
	"oc_delete_no_success" => 'Borrado NO satisfactorio',
	"oc_no_name" => 'Sin Nombre',
	"oc_no_desc" => 'Sin Descripción',
	"oc_creator" => 'creado por:',
	"oc_min" => 'min',
	"oc_next_oc" => 'Siguiente Reunión Oficial',
	"oc_start" => 'Comenzar',
	"oc_end" => 'Final',
	
);

?>