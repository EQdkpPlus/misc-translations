<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Spanish	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:48
//File: plugins/guildrequest/language/spanish/lang_main.php
//Source-Language: english

$lang = array( 
	"guildrequest" => 'Sistema de Reclutamiento.',
	"guildrequest_short_desc" => 'Sistema de Reclutamiento.',
	"guildrequest_long_desc" => 'Sistema de Reclutamiento es un plugin para poder reclutar nuevos miembros en tu hermandad mendiante un formulario.',
	"gr_manage_form" => 'Gestionar Formulario',
	"gr_vote" => 'Votar',
	"gr_view" => 'Ver Apply\'s',
	"gr_view_closed" => 'View closed applications',
	"gr_add" => 'Escribir Apply',
	"gr_applications" => 'Open applications',
	"gr_archive" => 'Archive',
	"gr_internal_comment" => 'Escribir un comentario interno',
	"gr_comment" => 'Escribir un comentario público',
	"gr_plugin_not_installed" => 'El Plugin de Sistema de Reclutamiento no está instalado',
	"gr_select_options" => 'Opciones (1 por linea)',
	"gr_required" => 'Obligatorio',
	"gr_delete_selected_fields" => 'Borrar campos seleccionados',
	"gr_types" => array(
	0 => 'Campo de Texto',
	1 => 'Campo de Área de texto',
	2 => 'Desplegable',
	3 => 'Etiquetas de Grupo.',
	4 => 'Texto Libre',
	5 => 'Cajas de Verificación',
	6 => 'Botones.',
	7 => 'Editor',
	8 => 'Image-Upload',
	),
	"gr_add_field" => 'Añadir nuevo Campo',
	"gr_delete_field" => 'Borrar campo',
	"gr_default_grouplabel" => 'Información',
	"gr_personal_information" => 'Información Personal',
	"gr_submit_request" => 'Enviar Apply',
	"gr_email_help" => 'Porfavor provee de una dirección de correo electrónico válida, por que se te notificará de cambios en tu apply en esa cuenta.',
	"gr_activationmail_subject" => 'Activar tu Apply',
	"gr_viewlink_subject" => 'Tu Apply',
	"gr_request_success" => 'Tu apply ha sido guardado correctamente. Un correo con el enlace para ver la página será enviado al correo electrónico que nos has propocionado.',
	"gr_request_success_msg" => 'Your application has been saved successfully. You can view your application at any time using the following link: ',
	"gr_internal_comments" => 'Comentarios Internos',
	"gr_newcomment_subject" => 'Nuevo comentario en tu Apply.',
	"gr_status" => array(
	0 => 'Nuevo',
	1 => 'en progreso',
	2 => 'Aceptado',
	3 => 'Rechazado',
	),
	"gr_status_text" => 'Your applications has the following status: <b>%s</b>',
	"gr_vote_button" => 'Votar',
	"gr_manage_request" => 'Gestionar Apply\'s',
	"gr_status_help" => 'El Aplicante obtendrá un correo automático con el cambio de estado. Si quiere añadir algun correo electrónico, por favor rellene el campo.',
	"gr_change_status" => 'Cambio de estado',
	"gr_close" => 'Cerrar Apply',
	"gr_open_request" => 'Reabri Apply',
	"gr_closed_subject" => 'Tu apply a sido cerrado.',
	"gr_status_subject" => 'Tu Apply: Cambio de estado',
	"gr_footer" => 'found %1$s applications / %2$s per page',
	"gr_in_list" => 'Mostrar lista de Apply\'s',
	"gr_confirm_delete_requests" => '¿Estas seguro de borrar los Apply\'s de %s?',
	"gr_delete_selected_requests" => 'Borrar los Apply\'s seleccionados',
	"gr_delete_success" => 'Los Apply\'s seleccionados han sido borrados con éxito.',
	"gr_notification" => '%s new Applications/Comments',
	"gr_notification_open" => '%s open Applications',
	"gr_mark_all_as_read" => 'Marcar todos los Apply\'s como leído',
	"gr_send_notification_mails" => 'Enviar una notíficación por Correo Eletrónico por un nuevo Apply',
	"gr_closed" => 'Este Apply está cerrado.',
	"gr_notification_subject" => 'Nuevo Apply.',
	"gr_jgrowl_notifications" => 'Mostrar notificaciones en una Ventana Desplegable',
	"gr_viewrequest" => 'View Application',
	"gr_dependency" => 'Dependency (Field - Option)',
	"gr_customcheck_info" => 'You can add your own dependecy checks, if you select "_Custom" and enter your expression the field on the right.<br />Example: ((FIELD1 == "MyValueOne" && FIELD2 == "MyValueTwo") || FIELD3 == "MyValueThree")<br />Please not that the required-check will not work correctly for custom dependencies.',
	"user_sett_fs_guildrequest" => 'Sistema de Reclutamiento.',
	"user_sett_tab_guildrequest" => '<i class="fa fa-pencil-square-o"></i> GuildRequest',
	"gr_preview" => 'Preview',
	"gr_preview_info" => 'This Preview is generated from the latest saved form. To get the current form, please save your modified form and click on the Preview-Button at the Form Page.',
	"user_sett_f_ntfy_guildrequest_new_application" => 'New application',
	"user_sett_f_ntfy_guildrequest_new_update" => 'New Comments',
	"user_sett_f_ntfy_guildrequest_open_applications" => 'Open applications',
	"user_sett_f_ntfy_guildrequest_new_update_own" => 'Updates for my own applications',
	"user_sett_fs_notifications_guildrequest" => 'GuildRequest',
	"gr_notify_new_application" => '{PRIMARY} added a new application',
	"gr_notify_new_application_grouped" => '{PRIMARY} added a new application',
	"gr_notify_new_update" => 'The application of {ADDITIONAL} has been commented',
	"gr_notify_new_update_grouped" => '{COUNT} applications have been commented',
	"gr_notify_new_update_own" => 'Your Application was updated',
	"gr_notify_new_update_own_grouped" => 'There have been {COUNT} updates on your application',
	"gr_fs_general" => 'General',
	"gr_f_create_account" => 'Create EQdkp Plus Account, if Application was accepted',
	"gr_f_help_create_account" => 'This option is available if no CMS Bridge is active',
	"gr_f_archive" => 'Move all closed applications into an archive',
	"gr_f_help_archive" => 'This will pre-sort all closed applications for better overwiew',
	"gr_myapplications" => 'My Applications',
	"plugin_statistics_guildrequest_applications" => 'GuildRequest: Applications',
	"gr_voted_users" => 'The following users have already voted',
	
);

?>