<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Spanish	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:48
//File: plugins/epgpimport/language/spanish/lang_main.php
//Source-Language: english

$lang = array( 
	"epgpimport" => 'Impotar EPGP',
	"epgpimport_import" => 'Impotar Log EPGP',
	"epgpimport_short_desc" => 'Impotador EPGP',
	"epgpimport_long_desc" => 'Impotar tus logs de EPGP directamente del Addon del Juego.',
	"epgpimport_error_nolog" => 'No has dado ningún log de EPGP',
	"epgpimport_error_wrongformat" => 'El Log de EPGP no podía ser importado, tal vez está dañado, tiene un formato incorrecto o uno más nuevo ya se ha importado.',
	"epgpimport_layoutwarning" => 'You don\'t use an EPGP-Layout. This can cause uncorrectly imports. Please go to the <a href='.registry::get_const('root_path').'admin/manage_pagelayouts.php'.registry::get_const('SID').'">Pagelayout-Management</a> and select an EPGP-Layout.',
	"epgpimport_success" => 'Log de EPGP impotado correctamente.',
	"epgpimport_error_more_mdkp4event" => 'El log de EPGP no podía ser importado, ya que el evento seleccionado pertenece a más de una MultiDKP-Pool.',
	
);

?>