<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Spanish	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:48
//File: plugins/siggenerator/language/spanish/lang_main.php
//Source-Language: english

$lang = array( 
	"siggenerator" => 'Generador de firmas',
	"siggenerator_short_desc" => 'Generador de firmas',
	"siggenerator_long_desc" => 'Crea firmas con los datos del personaje e información del punto',
	"sg_plugin_not_installed" => 'El plugin del generador de firmas no está instalado.',
	"sg_manage_signatures" => 'Administración de firmas',
	"sg_manage_fonts" => 'Administración de fuente',
	"sg_manage_backgrounds" => 'Administración del fondo',
	"sg_add_signature" => 'Añadir firma',
	"sg_background" => 'Fondo',
	"sg_font" => 'Fuente',
	"sg_font_color" => 'Color de fuente',
	"sg_font_border_color" => 'Color del borde de la fuente',
	"sg_font_border_size" => 'Ancho del borde de la fuente',
	"sg_position" => 'Posición',
	"sg_preset" => 'Valor',
	"sg_add_field" => 'Añadir campo',
	"sg_values" => 'Campos',
	"sg_delete_field" => 'Borrar campo',
	"sg_live_preview" => 'Vista previa en directo',
	"sg_show_label" => 'Mostrar etiqueta',
	"sg_picture_preset" => 'Modulo de Imagen del Personaje',
	"sg_signatur_link" => 'Firmas de personajes',
	"sg_select_char" => 'Seleccionar personaje',
	"sg_bbcode" => 'Codigo BB para Foros',
	"sg_htmlcode" => 'Código HTML para páginas web',
	"sg_direktlink" => 'Enlace directo',
	"sg_add_font" => 'Añadir fuente',
	"sg_folder" => 'Carpeta',
	"sg_add_background" => 'Añadir fondo',
	"sg_font_help" => 'Puedes añadir tus fuentes propias. Las fuentes han de tener el formato -ttf. Puedes descargar formatos gratis desde Google Fonts.',
	"sg_background_help" => 'Usted puede cargar su propio fondo. La mejor resolución es 500px de ancho y 100px de altura. Otras resoluciones son posibles, pero pueden causar problemas.',
	
);

?>