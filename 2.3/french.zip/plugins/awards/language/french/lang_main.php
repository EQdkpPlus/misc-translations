<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:46
//File: plugins/awards/language/french/lang_main.php
//Source-Language: english

$lang = array( 
	"awards" => 'Récompenses',
	"awards_short_desc" => 'Obtenez succès, gloire et honneur.',
	"awards_long_desc" => 'Ce plugin permet d\'obtenir les succès.',
	"aw_achievement" => 'Succès',
	"aw_achievements" => 'Succès',
	"aw_ap" => 'Points de récompense',
	"aw_points" => 'Points de récompense',
	"aw_dkp" => 'DKP',
	"aw_progress" => 'Progrès',
	"aw_all_guild_achievements" => 'Tous les succès de guilde',
	"aw_customtab_title" => 'Mes succès',
	"aw_tab_user" => 'Mes succès',
	"aw_user_unreached" => 'N\'a pas obtenu ce succès',
	"aw_member_unreached" => 'Non obtenu',
	"aw_is_inactive" => 'Le succès est inactif',
	"aw_is_special" => 'Le succès est invisible',
	"user_sett_tab_awards" => 'Plugin Récompenses',
	"user_sett_fs_awards" => 'Paramètres des récompenses',
	"user_sett_f_aw_show_hook" => 'Afficher les Infos Rapides des Récompenses',
	"user_sett_f_aw_layout" => 'Mise en page',
	"user_sett_f_aw_pagination" => 'Succès par site',
	"user_sett_f_aw_admin_pagination" => '[PCA] Succès/Affectations par lieu',
	"user_sett_f_aw_layout_default" => 'Défaut',
	"user_sett_f_aw_layout_minimalist" => 'Minimaliste',
	"user_sett_f_ntfy_awards_new_award" => 'New Achievement',
	"user_sett_f_ntfy_awards" => 'Awards',
	"aw_manage_achievements" => 'Gestion des succès',
	"aw_manage_assignments" => 'Gestion des attributions',
	"aw_tab_assign" => '<i class="adminicon"></i>Toutes les affectations',
	"aw_tab_achieve" => ' <i class="adminicon"></i>Tous les succès',
	"aw_add_achievement" => 'Ajouter un succès',
	"aw_edit_achievement" => 'Modifier un succès',
	"aw_add_assignment" => 'Assigner un succès',
	"aw_edit_assignment" => 'Modifier une attibution',
	"aw_special" => 'Succès spécial',
	"aw_value" => 'Valeur PR',
	"aw_dkp_value" => 'Valeur DKP',
	"aw_auto_assign" => 'Auto-attribution',
	"aw_icon_header" => 'Choisir une icône',
	"aw_upload_icon" => 'Ajouter une icône',
	"aw_edit_icon" => 'Modifier une icône',
	"aw_name_help" => 'Nom / Titre du succès',
	"aw_desc_help" => 'Description du succès',
	"aw_active_help" => 'Détermine si ce succès peut être attribué.',
	"aw_special_help" => 'Les exploits invisibles n\'apparaitront que lorsqu\'ils seront atteints.',
	"aw_ap_help" => 'Les Points de Récompenses (point de succès) servent de devises propres aux Récompenses',
	"aw_dkp_help" => 'Ce sont les DKP que le joueur obtiendra en accomplissant ce succès.',
	"aw_dkp_warn" => 'Il est déconseillé de modifier les DKP car les DKP attribués ne seront pas modifiés.',
	"aw_event_help" => 'Choisissez un Evénement pour ce succès.',
	"aw_auto_assign_help" => 'La tâche planifiée "Plugins: Récompenses" doit être activée !',
	"aw_icon_help" => 'Sélectionnez ou téléchargez une icône correspondante. <br />Les images SVG ont en plus une option de changement de couleur, mais pour cette fonction vous devez optimiser votre SVG comme indiqué sur le <a href="https://eqdkp-plus.eu/wiki/Plugin:_Awards">Wiki</a>.',
	"aw_sortation" => 'Tri',
	"aw_icon_colors" => 'Couleurs d\'icône',
	"aw_module" => 'Module de tâche planifiée',
	"aw_module_settings" => 'Paramètres de tâche planifiée',
	"aw_listachiev_footcount" => '... %s Succès obtenus / %s par lieu',
	"aw_listassign_footcount" => '... %s Affectation(s) trouvée(s) / %s par lieu ',
	"aw_tt_reached_ap" => 'Points de récompenses atteints',
	"aw_tt_reached_dkp" => 'DKP atteints',
	"aw_tt_my_awards" => 'Tous mes succès',
	"aw_tt_all_awards" => 'Tous les succès de guilde',
	"aw_module_row_delete" => 'Supprimer cette condition',
	"aw_module_condition" => 'Ces conditions doivent être remplies.',
	"aw_module_all" => 'Toutes',
	"aw_module_any" => 'Une de ces',
	"aw_module_choose_option" => '-- Choisissez une condition ---',
	"action_achievement_added" => 'Succès créé',
	"action_achievement_deleted" => 'Succès suppriné',
	"action_achievement_updated" => 'Succès actualisé',
	"action_assignment_added" => 'Succès attribué',
	"action_assignment_deleted" => 'Attribution supprimée',
	"aw_plugin_not_installed" => 'Le plugin Récompenses n\'est pas installé.',
	"aw_no_permission" => 'Vous n\'avez pas les droits.',
	"aw_add_success" => '%s a été ajouté',
	"aw_add_nosuccess" => '%s ne peut pas être ajouté',
	"aw_upd_success" => '%s a été modifié',
	"aw_upd_nosuccess" => '%s ne peut pas être modifié',
	"aw_assign_success" => '%s a été <br />%s assigné',
	"aw_assign_nosuccess" => '%s ne peut pas être attribué',
	"aw_del_assign" => 'Attribution(s) supprimée(s)',
	"aw_module_load_error" => 'Impossible de charger le module.<br />Réessayez: <a href="javascript:get_module_settings(\'%s\');" onclick="$(this).parent().remove();">Charger le module</a>',
	"aw_confirm_delete_achievement" => 'Are you sure, that you will delete the selected %s achievements? All associated DKP of the characters will be deleted, too!',
	"aw_confirm_delete_assignment" => 'Etes-vous sûr(e) de vouloir supprimer toutes les attributions %s ? Les points DKP atteints seront également supprimés !',
	"aw_upd_assignment_warning" => '<h3>Une modification ultérieure de l\'assignation est à vos propres risques!</h3> Personne ne reçoit de notifications et pendant le processus d\'édition vous pouvez obtenir des erreurs irréversibles.<br /> Utilisez donc cette fonction avec prudence.',
	
);

?>