<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:46
//File: plugins/siggenerator/language/french/lang_main.php
//Source-Language: english

$lang = array( 
	"siggenerator" => 'Générateur de signatures',
	"siggenerator_short_desc" => 'Générateur de signatures',
	"siggenerator_long_desc" => 'Crée des signatures avec les données et points du personnage',
	"sg_plugin_not_installed" => 'Le générateur de signatures n\'est pas installé.',
	"sg_manage_signatures" => 'Gestion des signatures',
	"sg_manage_fonts" => 'Gestion des polices',
	"sg_manage_backgrounds" => 'Gestion des fonds de page',
	"sg_add_signature" => 'Ajouter une signature',
	"sg_background" => 'Fond de page',
	"sg_font" => 'Police',
	"sg_font_color" => 'Couleur de caractères',
	"sg_font_border_color" => 'Couleur de bordure de caractères',
	"sg_font_border_size" => 'Largeur de la bordure de caractères',
	"sg_position" => 'Position',
	"sg_preset" => 'Valeur',
	"sg_add_field" => 'Ajouter un champs',
	"sg_values" => 'Champs',
	"sg_delete_field" => 'Supprimer un champs',
	"sg_live_preview" => 'Aperçu dynamique',
	"sg_show_label" => 'Montrer l\'etiquette',
	"sg_picture_preset" => 'Module d\'image de personnage',
	"sg_signatur_link" => 'Signatures',
	"sg_select_char" => 'Choisir un personnage',
	"sg_bbcode" => 'BB-Code pour les forums',
	"sg_htmlcode" => 'Code HTML pour les sites web',
	"sg_direktlink" => 'Lien direct',
	"sg_add_font" => 'Ajouter une police',
	"sg_folder" => 'Dossier',
	"sg_add_background" => 'Ajouter un fond de page',
	"sg_font_help" => 'Vous pouvez télécharger vos propres polices au format .ttf. Vous trouverez des polices gratuites sur Google Fonts.',
	"sg_background_help" => 'Vous pouvez télécharger vos propres fonds de page. La résolution idéale est 500 x 100 pixel cependant d\'autres résolutions sont possibles mais risquent de poser des problèmes.',
	
);

?>