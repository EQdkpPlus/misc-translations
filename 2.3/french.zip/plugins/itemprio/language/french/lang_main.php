<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:46
//File: plugins/itemprio/language/french/lang_main.php
//Source-Language: english

$lang = array( 
	"itemprio" => 'Liste d\'articles prioritaires',
	"itemprio_short_desc" => 'Liste d\'articles prioritaires',
	"itemprio_long_desc" => 'Les personnages peuvent y ajouter les articles qu\'ils souhaitent par ordre de priorité',
	"ip_itemprios" => 'Liste d\'articles prioritaires',
	"ip_myitemprios" => 'Ma liste d\'articles prioritaires',
	"ip_config_saved" => 'Vos paramètres ont été correctement sauvegardés.',
	"ip_fs_general" => 'Généralités',
	"ip_fs_items" => 'Articles',
	"ip_f_item_count" => 'Nombre d\'articles par événement',
	"ip_f_item_new_allgone" => 'Les nouveaux articles ne peuvent être inscrits que lorsque tous les articles de la liste ont été attribués',
	"ip_f_events" => 'Choisissez un événement',
	"ip_f_twinks" => 'Liste d\'articles des rerolls',
	"ip_view" => 'Voir',
	"ip_use" => 'Créer des listes de priorités',
	"ip_change_items" => 'Modifier les articles de la liste',
	"ip_change_order" => 'Modifier la priorité des articles',
	"ip_distribute" => 'Distribuer les articles',
	"ip_plugin_not_installed" => 'Ce Plugin n\'est pas installé actuellement.',
	"ip_itemname" => 'Nom de l\'article',
	"ip_itemid" => 'ID de l`article dans le jeu',
	"ip_searchitem" => 'Rechercher un article',
	"ip_hint_allgone" => 'Vous ne pouvez pas ajouter de nouveaux articles tant que vous n\'avez pas reçu tous les articles de votre liste de priorités.',
	"ip_dragndrop" => 'Glissez à la position souhaitée',
	"ip_given_success" => 'L\'article \'%1$s\' a été donné à %2$s.',
	"ip_notify_new_item" => 'Vous avez reçu l\'article "{PRIMAIRY}" de votre liste de priorités.',
	"ip_notify_new_item_grouped" => 'Vous avez reçu {COUNT} articles de vos listes de priorités.',
	"ip_throw" => 'Donner l\'article aléatoirement',
	"ip_give" => 'Donner l\'article',
	"ip_f_item_new_allrequired" => 'Tous les articles par événement sont obligatoires',
	"ip_additional_buyers" => 'Autres personnages intéressés',
	"ip_f_show_additional_buyers" => 'Afficher tous les personnages intéressés par un article',
	"ip_no_chars" => 'Vous devez créer un personnage afin d\'ajouter des articles dans sa liste de priorités.',
	"user_sett_fs_notifications_itemprio" => 'Liste d\'articles prioritaires',
	"user_sett_f_ntfy_itemprio_new_item" => 'Article reçu',
	
);

?>