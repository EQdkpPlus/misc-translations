<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:46
//File: plugins/chat/language/french/lang_main.php
//Source-Language: english

$lang = array( 
	"chat" => 'Chat',
	"chat_short_desc" => 'Chat',
	"chat_long_desc" => 'Chattez avec une ou plusieurs personnes',
	"chat_view" => 'Chat',
	"chat_guildchat" => 'Chat de guilde',
	"chat_filter_user" => 'Filtrer les utilisateurs',
	"chat_all_conversations" => 'Toutes les conversations',
	"chat_conversation_with" => 'Conversation avec',
	"chat_user_online" => 'Utilisateur en ligne',
	"chat_conversation" => 'Conversation',
	"chat_no_unread" => 'Aucun message non lu',
	"chat_fs_ajax" => 'Ajax',
	"chat_f_reload_chat" => 'Fréquence de rafraîchissement du chat',
	"chat_f_help_reload_chat" => 'En secondes',
	"chat_f_reload_onlinelist" => 'Fréquence de rafraîchissement de la liste en ligne',
	"chat_f_help_reload_onlinelist" => 'En minutes',
	"chat_mod_pub" => 'Modérateur du chat public',
	"chat_read" => 'Lire',
	"chat_fs_sounds" => 'Sons',
	"chat_f_new_message_sound" => 'Nouveau message',
	
);

?>