<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:46
//File: plugins/donations/language/french/lang_main.php
//Source-Language: english

$lang = array( 
	"donations" => 'Donations',
	"donations_short_desc" => 'Gérer les dons de votre guilde',
	"donations_long_desc" => 'Une gestion des dons de votre guilde, qui autorise les paiements via PayPal',
	"donations_plugin_not_installed" => 'Le plugin Donations n\'est pas installé.',
	"donations_donate" => 'Donner',
	"donations_donationslist" => 'Voir la liste des dons',
	"donations_fs_general" => 'Généralités',
	"donations_f_min_value" => 'Montant minimum des dons',
	"donations_f_free_or_custom" => 'Montants sélectionnables',
	"donations_f_custom_values" => 'Montants prédéfinis',
	"donations_f_custom_free" => 'L\'utilisateur peut choisir librement le montant',
	"donations_f_custom_custom" => 'Montant des dons possibles',
	"donations_f_help_custom_values" => 'Saisissez les montants possibles pour les dons, séparés par des points-virgules',
	"donations_fs_goal" => 'Objectif des dons',
	"donations_f_goal_type" => 'Sélectionnez le type d\'objectif des dons',
	"donations_f_goal_no" => 'Pas d\'objectif',
	"donations_f_goal_monthly" => 'Montant mensuel',
	"donations_f_goal_fixedsum" => 'Montant total',
	"donations_f_goal_value" => 'Objectif des dons',
	"donations_f_goal_display_type" => 'Présentation de l\'état des dons',
	"donations_f_goal_display_type_progess" => 'Barre d\'avancement',
	"donations_f_goal_display_type_covered" => 'Mois couverts',
	"donations_fs_paypal" => 'PayPal',
	"donations_f_paypal_email" => 'Adresse du bénéficiaire',
	"donations_f_help_paypal_email" => 'Insérez votre adresse email PayPal. Vous pouvez également saisir votre adresse PayPal.me, par exemple paypal.me/EQdkpPlus. Les dons utilisant PayPal.me doivent être activés manuellement.',
	"donations_f_paypal_currency" => 'Devise',
	"donations_fs_texts" => 'Textes d\'information',
	"donations_f_donation" => 'Description sur la page des dons',
	"donations_f_thankyou" => 'Remerciements après un don réussi',
	"donations_f_cancel" => 'Signaler si un don est interrompu',
	"donations_f_goal_start" => 'Début de la campagne de dons',
	"donations_f_help_goal_start" => 'Sera utilisé pour calculer les mois couverts',
	"donations_menu" => 'Donations',
	"donation_success_message" => 'Merci beaucoup pour votre don ! Il apparaîtra ici dès qu\'il aura été vérifié.',
	"donation_cancel_message" => 'Dommage que vous ayez annulé votre don.',
	"donations_donate_button" => 'Faire un don',
	"plugin_statistics_donations" => 'Donations',
	"donations_covered_months_text" => '%d mois couverts',
	"donations_month" => 'Mois',
	"donations_months" => 'Mois',
	"donations_amount" => 'Montant',
	"donations_via_paypal" => 'Dons via PayPal',
	"donations_recent_goal" => 'Objectif de don récent',
	"donations_public" => 'Don public',
	"donations_wallofdonators" => 'Dons récents',
	"donations_hide_name" => 'Masquer le nom',
	"donations_manage" => 'Gérer les dons',
	"donations_add" => 'Ajouter un don/paiement',
	"donations_confirm_delete_donation" => 'Êtes-vous sûr de vouloir supprimer ces %s dons ?',
	"donation_incomplete_suc" => 'Ce don a bien été désactivé.',
	"donation_complete_suc" => 'Ce don a bien été activé.',
	"donation_complete_selected" => 'Activer la sélection',
	"donation_provider" => 'Mode de paiement',
	"donations_method_manual" => 'Manuel',
	"donations_ntfy_new_donation" => '{PRIMARY} a donné \'{ADDITIONAL}\'',
	"donations_ntfy_new_donation_grouped" => 'Il y a {COUNT} nouveaux dons',
	"user_sett_f_ntfy_donations_new_donation" => 'Nouveau don',
	"user_sett_f_ntfy_donations" => 'Donations',
	"donations_donations" => 'Donations',
	"donations_f_show_button" => ' Afficher le bouton de don',
	"donations_f_show_progress" => 'Montrer l\'évolution des dons',
	"donations_f_text" => 'Texte du don',
	"donations_months_short" => 'Mo.',
	"donations_f_show_count" => 'Recensement des derniers dons',
	"donations_f_text_latest" => 'Texte descriptif (facultatif)',
	"latestdonations" => 'Derniers dons',
	"user_sett_fs_notifications_donations" => 'Donations',
	
);

?>