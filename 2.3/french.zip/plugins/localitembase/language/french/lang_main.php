<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:46
//File: plugins/localitembase/language/french/lang_main.php
//Source-Language: english

$lang = array( 
	"localitembase" => 'Base locale d\'objets',
	"localitembase_short_desc" => 'Base locale d\'objets',
	"localitembase_long_desc" => 'Créez et gérer vos propres objets',
	"lit_plugin_not_installed" => 'Le plugin Base locale d\'objets n\'est pas installé.',
	"lit_config_saved" => 'La configuration a bien été enregistrée',
	"lit_fs_items" => 'Objets',
	"lit_f_base_layout" => 'Présentation HTML de base des infobulles d\'objets',
	"lit_f_base_css" => 'CSS du style des infobulles d\'objets',
	"lit_f_infotext" => 'Texte d\'information pour les utilisateurs',
	"lit_fs_export_import" => 'Importer & Exporter',
	"lit_f_export" => 'Exporter les objets',
	"lit_f_import" => 'Importer les objets',
	"lit_f_import_success" => 'Les objets ont été importés correctement ',
	"lit_add_item" => 'Ajouter un nouvel objet',
	"lit_delete_selected_items" => 'Supprimer les objets sélectionnés',
	"lit_delete_confirm" => 'Êtes-vous sûr(e) de vouloir supprimer les objets: %s',
	"lit_fs_general" => 'Général',
	"lit_f_item_gameid" => 'Identifiant en jeu',
	"lit_f_help_item_gameid" => 'Saisissez ici l\'identifiant de l\'objet dans le jeu. Celui-ci ne doit pas avoir de synonyme car il sert à identifier seulement cet objet.',
	"lit_f_quality" => 'Qualité d\'objet',
	"lit_f_help_quality" => 'Qualité de l\'objet. Sera utilisé pour colorer le nom de l\'objet.',
	"lit_f_item_text" => 'Description d\'objet',
	"lit_f_item_text_help" => 'Vous pouvez insérer l\'image de l\'objet dans votre texte en utilisant la variable {IMAGE}. Ce champs est au format HTML.',
	"lit_f_item_name" => 'Nom d\'objet',
	"lit_f_item_name_help" => 'Nom de l\'objet réellement utilisé',
	"lit_f_item_images" => 'Image de l\'objet',
	"lit_f_item_images_help" => 'Image de l\'objet, telle qu\'une copie d\'écran. Peut remplacer ou en compléter la description de l\'objet.',
	"lit_f_icon" => 'Icône de l\'objet',
	"lit_f_help_icon" => 'Icône de l\'objet, de 16px ou 32px normalement ',
	"lit_download" => 'Téléchargement',
	"lit_search_database" => 'Rechercher dans la base de données',
	"lit_edit_itembase" => 'Gérer la base de données locale des objets.',
	"lit_fs_manage" => 'Gérer les objets',
	
);

?>