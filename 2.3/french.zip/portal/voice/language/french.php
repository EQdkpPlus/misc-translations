<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:46
//File: portal/voice/language/french.php
//Source-Language: english

$lang = array( 
	"voice" => 'Observateur de serveur vocal',
	"voice_name" => 'Observateur de serveur vocal',
	"voice_desc" => 'Observateur de serveur vocal tels que Teamspeak3, Mumble ou Ventrilo',
	"voice_f_module" => 'Choisissez votre serveur vocal',
	"mumble" => 'Mumble',
	"voice_f_mumble_datauri" => 'Data URI',
	"voice_f_help_mumble_datauri" => 'Saisissez le CVP Uniform Resource Identifier fourni par votre hébergeur',
	"voice_f_mumble_dataformat" => 'Data Format',
	"voice_f_help_mumble_dataformat" => 'Choisissez le data format spécifié par votre hébergeur',
	"voice_f_mumble_linkuri" => 'Lien URI',
	"voice_f_help_mumble_linkuri" => 'Facultatif : Saisissez l\'adresse du lien mumble:// pour rejoindre votre serveur. Seulement utilisée si les données de votre serveur ne l\'incluent pas.',
	"voice_f_mumble_iconstyle" => 'Style d\'icônes',
	"voice_f_help_mumble_iconstyle" => 'Choisissez le style d\'icônes que vous préférez.',
	"ts3" => 'Teamspeak 3',
	"voice_f_ts3_ip" => 'L\'adresse IP ou le nom d\'hôte de votre serveur (sans port)',
	"voice_f_help_ts3_ip" => 'Ex: 127.0.0.0.1 ou votredomaine.com',
	"voice_f_ts3_port" => 'Le port',
	"voice_f_help_ts3_port" => 'Par défaut : 9987',
	"voice_f_help_ts3_telnetport" => 'Par défaut : 10011',
	"voice_f_ts3_telnetport" => 'Le port Telnet de votre serveur',
	"voice_f_ts3_id" => 'L\'ID de votre serveur virtuel',
	"voice_f_help_ts3_id" => 'Par défaut : 1. saisissez -1 pour utiliser le port du serveur pour la connexion au lieu de l\'identifiant du serveur.',
	"voice_f_ts3_cache" => 'Durée minimum entre les requêtes TS3 (en secondes)',
	"voice_f_help_ts3_cache" => 'Pendant combien de secondes les données de TS3 devront rester en cache avant d\'être rafraîchies. 0 pour désactiver le cache.',
	"voice_f_ts3_banner" => 'Afficher la bannière si son URL est disponible dans TS ?',
	"voice_f_ts3_join" => 'Afficher le lien pour rejoindre le serveur ?',
	"voice_f_ts3_jointext" => 'Lien texte permettant d\'accéder au serveur',
	"voice_f_ts3_legend" => 'Afficher les informations du groupe en dessous ?',
	"voice_f_ts3_cut_names" => 'Couper les noms d\'utilisateurs',
	"voice_f_help_ts3_cut_names" => 'Si vous voulez tronquer les noms d\'utilisateurs, indiquez la taille voulue - Aucune troncature = 0',
	"voice_f_ts3_cut_channel" => 'Couper les noms de canaux',
	"voice_f_help_ts3_cut_channel" => 'Si vous voulez tronquer les noms de canaux, indiquez la taille voulue - Aucune troncature = 0',
	"voice_f_only_populated_channel" => 'Ne montrer que les canaux occupés ?',
	"voice_f_ts3_useron" => 'Afficher les utilisateurs en ligne / Utilisateurs potentiels ?',
	"voice_f_ts3_stats" => 'Afficher une boite de statistique en dessous de l\'observateur de TS ?',
	"voice_f_ts3_stats_showos" => 'Afficher l\'OS faisant tourner TS3 ?',
	"voice_f_ts3_stats_version" => 'Afficher la version du serveur TS3 ?',
	"voice_f_ts3_stats_numchan" => 'Afficher le nombre de canaux ?',
	"voice_f_ts3_stats_uptime" => 'Afficher le temps écoulé depuis le dernier démarrage ?',
	"voice_f_ts3_stats_install" => 'Afficher la date d\'installation du serveur ?',
	"voice_f_ts3_timeout" => 'Timeout (NE PAS changer)',
	"voice_f_help_ts3_timeout" => 'Laissez cette valeur vide à moins de vraiment savoir ce que vous faites.',
	"voice_f_ts3_show_spacer" => 'Afficher les séparateurs de canaux',
	"lang_ts3_user_online" => 'Utilisateur en ligne',
	"lang_ts3_stats" => 'Statistiques',
	"lang_ts3_legend" => 'Légende',
	"lang_ts3_uptime" => array(
	0 => 'Jours',
	1 => 'Heures',
	2 => 'Min',
	),
	"voice_f_ts3_sshport" => 'Port SSH',
	"voice_f_help_ts3_sshport" => 'Par défaut : 10022',
	"voice_f_ts3_sshuser" => 'Utilisateur SSH',
	"voice_f_help_ts3_sshuser" => 'Insérez ici les informations d\'identification SSH du serveur TS3.',
	"voice_f_ts3_sshpass" => 'Mot de passe de l\'utilisateur SSH',
	"voice_f_ts3_query_type" => 'Protocole de requête du serveur',
	"voice_f_help_ts3_query_type" => 'Si votre serveur TS3 prend en charge les requêtes sur le serveur via SSH, sélectionnez l\'option SSH.',
	"ventrilo" => 'Ventrilo',
	"voice_f_ventrilo_server" => 'Saisissez l\'adresse du serveur ventrilo',
	"voice_f_ventrilo_port" => 'Saisissez le port du serveur Ventrilo',
	"voice_f_ventrilo_backgroundc" => 'Saisissez la couleur hexadécimale à 6 chiffres pour le FOND (TTTTTTTT = transparent (http://www.computerhope.com/htmcolor.htm))',
	"voice_f_ventrilo_channelc" => 'Saisissez les 6 caractères héxa du code de la couleur de CANAL ',
	"voice_f_ventrilo_servercolor" => 'Saisissez les 6 caractères héxa du code de la couleur de SERVEUR',
	"voice_f_ventrilo_usercolor" => 'Saisissez les 6 caractères héxa du code de la couleur de NOM D\'UTILISATEUR',
	"discord" => 'Discord',
	"voice_f_discord_serverid" => 'ID du serveur',
	"voice_f_discord_height" => 'Hauteur (en pixels)',
	"voice_f_discord_connect" => 'Connecter',
	"voice_f_discord_showonline" => 'Afficher les membres en ligne',
	"voice_f_discord_hideempty" => 'Masquer les canaux vocaux vides',
	"voice_f_discord_hidegame" => 'Masquer le jeu joué',
	
);

?>