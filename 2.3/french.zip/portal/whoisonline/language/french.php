<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:46
//File: portal/whoisonline/language/french.php
//Source-Language: english

$lang = array( 
	"whoisonline" => 'Utilisateur en ligne',
	"whoisonline_name" => 'Utilisateur en ligne',
	"whoisonline_desc" => 'Affiche les utilisateurs en ligne/hors ligne',
	"whoisonline_f_limit_total" => 'Nombres maximum d\'utilisateurs affichés',
	"whoisonline_f_help_limit_total" => 'Il n\'y aura pas plus d\'utilisateurs affichés que le nombre indiqué.',
	"whoisonline_f_limit_online" => 'Nombres maximum d\'utilisateurs en ligne affichés',
	"whoisonline_f_help_limit_online" => 'Saisissez 0 pour afficher tous les utilisateurs connectés',
	"whoisonline_f_limit_offline" => 'Nombres maximum d\'utilisateurs hors ligne affichés',
	"whoisonline_f_help_limit_offline" => 'Saisissez 0 pour afficher tous les utilisateurs hors ligne',
	"whoisonline_f_show_guests" => 'Afficher les Visiteurs',
	"wo_last_activity" => 'Dernière activité',
	"wo_type_options" => array(
	0 => 'Liste',
	1 => 'Avatars seulement',
	),
	"whoisonline_f_view" => 'Voir',
	"wo_and_guests" => 'Aucun utilisateur et %d visiteur(s)',
	
);

?>