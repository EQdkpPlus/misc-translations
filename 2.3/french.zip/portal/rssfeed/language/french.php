<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:46
//File: portal/rssfeed/language/french.php
//Source-Language: english

$lang = array( 
	"rssfeed" => 'Flux RSS',
	"rssfeed_name" => 'Module Flux RSS',
	"rssfeed_desc" => 'Afficher un flux RSS sur le Portail',
	"rssfeed_f_limit" => 'Nombre d\'éléments du flux à afficher',
	"rssfeed_f_url" => 'URL du flux RSS',
	"pk_rssfeed_nourl" => 'Merci de définir un flux en premier',
	"rssfeed_f_length" => 'Nombre de caractères devant être affichés dans le texte',
	"rssfeed_f_help_length" => 'La limite de caractère peut endommager un lien HTML si le flux est trop large. Une chaîne de caractères sans espace ne provoquera pas de retour à la ligne et la colonne de gauche deviendra très large.',
	"rssfeed_f_layout" => 'Présentation',
	
);

?>