<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:46
//File: language/french/lang_mmode.php
//Source-Language: english

$lang = array( 
	"click2show" => '(cliquez pour afficher)',
	"maintenance_mode" => 'Mode Maintenance',
	"task_manager" => 'Gestionnaire de tâches',
	"admin_acp" => 'Panneau d\'administration',
	"activate_info" => '<h1>Activer le mode de maintenance </h1><br />Avec cet outil de maintenance, vous pouvez facilement mettre à jour votre EQdkp et importer des données depuis une ancienne version.<br />Seuls une mise à jour ou une importation est possible, si le mode de maintenance est activé la connexion des utilisateurs est interdite pour prévenir les erreurs et problèmes.<br /><br />Motif qui sera montré aux utilisateurs (facultatif):<br />',
	"activate_mmode" => 'Activer le mode maintenance',
	"deactivate_mmode" => 'Fermer le mode de maintenance',
	"leave_mmode" => 'Annuler',
	"home" => 'Accueil',
	"no_leave" => 'Impossible de désactiver le mode de maintenance tant que des tâches doivent être exécutées.',
	"no_leave_accept" => 'Retour à la liste des tâches',
	"maintenance_message" => '<b>Le système EQdkp Plus fonctionne actuellement en mode maintenance.</b> Seuls les administrateurs peuvent se connecter.',
	"reason" => '<br /><b>Motif:</b>',
	"admin_login" => 'Connexion Administrateur',
	"login" => 'Connexion',
	"username" => 'Utilisateur',
	"password" => 'Mot de passe',
	"remember_password" => 'Se souvenir du mot de passe ?',
	"invalid_login_warning" => 'Erreur lors de la connexion ! Veuillez vérifier votre nom d\'utilisateur et votre mot de passe. Seuls les administrateurs peuvent se connecter !',
	"is_necessary" => 'Obligatoire ?',
	"is_applicable" => 'Applicable ? ',
	"name" => 'Nom',
	"version" => 'Version',
	"author" => 'Auteur',
	"link" => 'Exécuter la tâche',
	"description" => 'Description',
	"type" => 'Type de tâche',
	"yes" => 'Oui',
	"no" => 'Non',
	"click_me" => 'Exécuter la tâche',
	"mmode_info" => 'Votre système est actuellement en mode de maintenance, les connexions des utilisateurs normaux sont rejetées tant que ce mode est actif.',
	"necessary_tasks" => 'Opérations nécessaires',
	"applicable_tasks" => 'Tâches facultatives/déjà traitées',
	"not_applicable_tasks" => 'Opérations inapplicables',
	"no_nec_tasks" => 'Aucune opération n\'est nécessaire',
	"nec_tasks" => 'Les tâches suivantes sont nécessaires. Veuillez les soumettre pour maintenir votre système à jour.',
	"nec_tasks_available" => 'Merci de soumettre les tâches nécessaires à la mise à jour de votre système.',
	"applicable_warning" => 'Cette tâche n\'est pas applicable. Son exécution peut provoquer des pertes de données. Ne la lancez que si vous êtes absolument sûr de ce que vous faites.',
	"executed_tasks" => 'Les opérations suivantes ont été réalisées pour la tâche "%s"',
	"stepend_info" => 'La tâche est terminée. EQDKP Plus est toujours en mode de maintenance ce qui vous permet de tout tester tranquillement. Les utilisateurs ne pourront à nouveau se connecter que lorsque ce mode sera fermé.',
	"mmode_pfh_error" => 'Des erreurs se sont produites. Vous devez corriger ces erreurs pour pouvoir fermer le mode de maintenance.',
	"lib_cache_notwriteable" => 'Ecriture impossible dans le répertoire "data". Veuillez lui attribuer les permissions CHMOD 777.',
	"fix" => 'Réparer',
	"update" => 'Mise à jour du noyau',
	"import" => 'Importer',
	"plugin_update" => 'Mise à jour des Plugins',
	"game_update" => 'Mise à jour du jeu',
	"worker" => 'Travailleur',
	"unknown_task_warning" => 'Tâche inconnue !',
	"application_warning" => 'Une erreur d\'application empêche de traiter la tâche !',
	"dependency_warning" => 'Cette tâche est dépendante d\'autres. Exécutez-les en premier !',
	"start_here" => 'Commencez ici !',
	"following_updates_necessary" => 'Les mises à jour suivantes sont nécessaires:',
	"start_update" => 'Exécutez toutes les mises à jour nécessaires !',
	"only_this_update" => 'N\'exécuter que cette mise à jour:',
	"start_single_update" => 'Exécuter la mise à jour',
	"backup" => 'Sauvegarde de la base de données',
	"backup_note" => 'Une sauvegarde de la base de données a été réalisée le %s.',
	"support_eqdkplus" => 'Un projet tel qu\'EQdkp Plus ne peut exister que grâce à vos contributions en reconnaissance de nos efforts, du temps passé et de l\'amour que nous consacrons à EQdkp Plus. Vous pouvez participer de plusieurs façons: <ul> <li><i class="fa fa-puzzle-piece"></i> <a href="http://eqdkp-plus.eu/repository/">En publiant un Plugin ou une présentation que les autres utilisateurs d\'EQdkp Plus pourront utiliser</a></li> <li><i class="fa fa-comments"></i> <a href="http://eqdkp-plus.eu/forum/">En nous aidant sur notre forum</a></li> <li><i class="fa fa-cogs"></i> <a href="http://eqdkp-plus.eu/en/development.html">En prenant activement part au développement d\'EQdkp Plus</a></li> <li><i class="fa fa-usd"></i> <a href="http://eqdkp-plus.eu/en/donate.html">En nous soutenant financièrement pour que nous puissions continuer à vous offrir nos services</a></li> </ul> Alors si vous aimez EQdkp Plus autant que nous, pensez à nous aider !',
	
);

?>