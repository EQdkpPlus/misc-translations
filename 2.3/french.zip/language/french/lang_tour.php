<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:46
//File: language/french/lang_tour.php
//Source-Language: english

$lang = array( 
	"navi" => '<ul><li><a href="?tour=next"><b>Continuer vers l\'étape suivante</b></a></li><li><a href="?tour=reload" >Revoir cette étape</a></li><li><a href=" ? tour=cancel" >Quitter la visite</a></li></ul>',
	"navi_title" => 'Visite de EQdkp Plus',
	"steps" => 'Etape %d sur %d',
	"step_0" => 'Bienvenue dans la visite guidée d\'EQdkp Plus!<br /><br />Cette visite vous montrera les fonctionnalités les plus importantes de notre système CMS & DKP. <br /><ul><li>Réglages </li><li>Plugins </li><li>Modules </li><li>Modules </li><li>Gestion des utilisateurs </li><li>Gestion de Raid</li><li>Présentation/Système DKP</li><li>Création de pages de CMS</li><li>Sauvegarde</li></ul>',
	"step_0_title" => 'Commencer',
	"step_1" => 'Sur cette page vous pouvez configurer votre EQdkp Plus. Par exemple, vous verrez les paramètres pour <ul><li>Les présentations comme le titre de la page </li><li>Le jeu, comme le nom de votre guilde, le nom du serveur, ...</li><li>Les informations de contact</li><li>Les réglages d\'E-mail</li><li>Les réglages d\'enregistrement (ex: CAPTCHA)</li><li>Les réglages des statistiques des objets</li></ul>',
	"step_1_title" => 'Paramètres',
	"step_2" => 'Les plugins sont des extensions pour étendre les fonctionnalités de votre EQdkp Plus. Pour installer un plugin, cliquez simplement sur "Installer".<br /><br />Plugins suggéré:<ul><li>aidlogimport : importer les logs de raid depuis les addons en jeu </li></ul>.',
	"step_2_title" => 'Plugins',
	"step_3" => 'Avec les modules de CMS, vous pouvez mettre plusieurs informations intéressantes sur la page d\'accueil. Par exemple:<ul><li>Teamspeak ou autre serveur vocal </li><li>journaux de bataille récents </li><li>anniversaires à venir </li><li>prévisions météorologiques </li><li>etc...</li></ul> En utilisant l\'onglet "Positionnement", vous pouvez déplacer chaque module à l\'endroit où il doit s\'afficher sur la page. <br><br>Avec les réglages de l\'étape 1 vous pouvez également définir quelles colonnes doivent apparaître sur chaque page plutôt que seulement la page principale qui est utilisée par défaut.',
	"step_3_title" => 'Modules du portail',
	"step_4" => 'Voici la gestion des utilisateurs. Vous pouvez par exemple activer les utilisateurs qui sont encore inactifs en raison des paramètres d\'enregistrement. <br /><br />Un utilisateur ne peut demander un raid et accumuler des points DKP que si vous lui attribuez d\'abord un personnage.<br /><br /> Vous pouvez également gérer les autorisations des utilisateurs dans cet espace. Ce qui signifie que vous pouvez choisir ce que chaque utilisateur est autorisé à faire dans EQdkp Plus.<br />Vous pouvez le faire soit en lui assignant différents groupes d\'utilisateurs, soit en gérant individuellement ses permissions.<br /><br /> Les utilisateurs non enregistrés font partie du groupe d\'utilisateurs "Invités" dont vous pouvez aussi gérer les permissions. <br ><br > Si vous souhaitez avoir plus d\'informations sur les permissions, consultez <a href="http://eqdkp-plus.eu/wiki//de/index.php/Benutzergruppen" target="_blank" style="color:#000 ;">cette page du Wiki</a>',
	"step_4_title" => 'Gestion d\'utilisateur',
	"step_5" => 'Généralement, les raids sont utilisés pour attribuer des points DKP aux personnages. La date, l\'événement, la valeur DKP et bien sûr les participants (les personnages qui devraient obtenir des points DKP) sont définis dans un raid.<br>En outre, vous pouvez également distribuer les objets aux personnages et déduire les points correspondants de leur compte. Des ajustements individuels sont également possibles.<br /><br />Si vous utilisez un addon en jeu pour enregistrer le raid, le plugin "Raidlogimport" créera automatiquement les raids pour vous.<br /><br /> Si vous souhaitez plus d\'informations sur les raids, consultez <a href="http://eqdkp-plus.eu/wiki//de/index.php/Ein_Beispielraid" target="_blank" style="color:#000 ;">Cette page Wiki</a>.',
	"step_5_title" => 'Gestion des Raids',
	"step_6" => 'Comme chacun a ses propres exigences concernant l\'apparence de son EQdkp plus ou du système de points DKP à utiliser, vous pouvez sélectionner ici l\'apparence d\'EQdkp plus.<br /><br />Sous des modèles pré-établis comme "normal", "EPGP" ou "Suicide king" vous pouvez également organiser votre propre présentation.<br /><br/> Dans chaque onglet vous pouvez définir, pour la page respective, quelles colonnes doivent être affichées.',
	"step_6_title" => 'Gestion des tableaux et des points',
	"step_7" => 'Bien entendu, un CMS inclus la possibilité de créer son propre contenu.<br />Notre éditeur étendu et notre gestionnaire de médias satisfont les principaux besoins en la matière.<br /><br />De plus, vous pouvez définir les règles de votre guilde qui devront être acceptées pour pouvoir s\'enregistrer.',
	"step_7_title" => 'Création d\'articles',
	"step_8" => 'Beaucoup l\'ont vécu, personne n\'a apprécié - défaillance du système, perte de données et absence de sauvegarde <br /><br />Cela ne peut plus se produire!<br /><br /> En plus de la restauration depuis les sauvegardes, vous pouvez maintenant configurer des tâches de sauvegarde automatique. Allez dans "Gestion du Cronjob" pour définir les options.<br /><br />Si vous souhaitez plus d\'informations sur la sauvegarde, consultez <a href="http://eqdkp-plus.eu/wiki//de/index.php/Sicherung" target="_blank" style="color:#000 ;">cette page Wiki</a>.',
	"step_8_title" => 'Sauvegarde',
	"step_9" => 'Merci beaucoup d\'avoir participé à la visite d\'EQdkp Plus. <br /><br />Pour toute autre question, consultez:<ul><li>notre <a href="http://eqdkp-plus.eu/wiki/" style="color:#000">Wiki</a><li>notre <a href="http://eqdkp-pluseu/forum" style="color:#000">Forum</a>.</li></ul>Vous pouvez reprendre cette visite quand vous le souhaitez en allant sur l\'onglet "Support" de la page principale de la section admin.<br /><br />"Amusez-vous bien" - l\'équipe EQdkp Plus.',
	"step_9_title" => 'fin',
	
);

?>