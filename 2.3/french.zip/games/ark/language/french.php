<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:46
//File: games/ark/language/french.php
//Source-Language: english

$french_array = array( 
	"classes" => array(
	0 => 'Choisissez',
	1 => 'Femme',
	2 => 'Homme',
	),
	"races" => array(
	0 => 'Défaut',
	),
	"factions" => array(
	),
	"roles" => array(
	1 => 'Défaut',
	),
	"lang" => array(
	"ark" => 'ARK: Survival Evolved',
	"uc_level" => 'Niveau',
	"uc_class" => 'Sexe',
	"uc_stats" => 'Stats',
	"uc_dossier" => 'Dossier',
	"uc_resources" => 'Ressources',
	"uc_equip_offhand" => 'Équipement de main',
	"uc_cat_stats" => 'Stats',
	"uc_cat_equip" => 'Equipement',
	"uc_cat_engram" => 'Engrammes',
	"uc_cat_dossier" => 'Dossier',
	"uc_life" => 'Santé',
	"uc_stamina" => 'Endurance',
	"uc_oxygen" => 'Oxygène',
	"uc_food" => 'Nourriture',
	"uc_water" => 'Eau',
	"uc_weight" => 'Poids',
	"uc_damage" => 'Dégâts',
	"uc_speed1" => 'Vitesse de déplacement',
	"uc_speed2" => 'Vitesse de fabrication',
	"uc_resistance" => 'Résistance',
	"uc_torpor" => 'Torpeur',
	"uc_equip_head" => 'Tête',
	"uc_equip_body" => 'Poitrine',
	"uc_equip_leg" => 'Jambes',
	"uc_equip_feet" => 'Pieds',
	"uc_equip_hand" => 'Mains',
	"uc_engram_thatch" => 'Branchages',
	"uc_engrams" => 'Engrammes',
	"tab_engram" => 'Engrammes',
	"tab_dino" => 'Dossiers',
	"uc_resource" => 'Ressources',
	"uc_containers" => 'Conteneur',
	"uc_misc" => 'Divers',
	"uc_crafting_station" => 'Station d\'artisanat',
	"uc_thatch" => 'Branchages',
	"uc_wood" => 'Bois',
	"uc_stone" => 'Pierre',
	"uc_metal" => 'Métal',
	"uc_greenhouse" => 'Verre',
	"uc_turret" => 'Tourelles',
	"uc_vehicles" => 'Véhicules',
	"uc_tools" => 'Weapons/Tools',
	"uc_ammunition" => 'Munitions',
	"uc_explosives" => 'Explosifs',
	"uc_emplacements" => 'Emplacements',
	"uc_clothing" => 'Habillement',
	"uc_cloth" => 'Tissu',
	"uc_hide" => 'Peau',
	"uc_fur" => 'Fourrure',
	"uc_ghillie" => 'Camouflage',
	"uc_chitin" => 'Chitine',
	"uc_flak" => 'Métal',
	"uc_riot" => 'Anti-Émeute ',
	"uc_scuba" => 'Plongée',
	"uc_shields" => 'Boucliers',
	"uc_saddles" => 'Selles',
	),
	"equip_head" => array(
	"x" => '---',
	"Cloth_Hat" => 'Foulard en tissu',
	"Hide_Hat" => 'Casque en cuir',
	"Fur_Cap" => 'Capuche en fourrure',
	"Ghillie_Mask" => 'Masque de camouflage',
	"Chitin_Helmet" => 'Casque en Chitine',
	"Flak_Helmet" => 'Casque en métal',
	"Riot_Helmet" => 'Casque Anti-Émeute',
	"SCUBA_Mask" => 'Masque de Plongée',
	),
	"equip_body" => array(
	"x" => '---',
	"Cloth_Shirt" => 'Chemise en tissu',
	"Hide_Shirt" => 'Veste en cuir',
	"Fur_Chestpiece" => 'Veste en fourrure',
	"Ghillie_Chestpiece" => 'Veste de Camouflage',
	"Chitin_Chestpiece" => 'Veste en chitine',
	"Flak_Chestpiece" => 'Plastron en métal',
	"Riot_Chestpiece" => 'Veste Anti-Émeute',
	"SCUBA_Tank" => 'Bouteille de Plongée',
	),
	"equip_leg" => array(
	"x" => '---',
	"Cloth_Pants" => 'Pantalon en tissu',
	"Hide_Pants" => 'Pantalon en cuir',
	"Fur_Leggings" => 'Pantalon en fourrure',
	"Ghillie_Leggings" => 'Pantalon de Camouflage',
	"Chitin_Leggings" => 'Pantalon en chitine',
	"Flak_Leggings" => 'Pantalon en métal',
	"Riot_Leggings" => 'Pantalon Anti-Émeute',
	"SCUBA_Leggings" => 'Combinaison de Plongée',
	),
	"equip_feet" => array(
	"x" => '---',
	"Cloth_Boots" => 'Chaussures en tissu',
	"Hide_Boots" => 'Bottes en cuir',
	"Fur_Boots" => 'Chaussons en fourrure',
	"Ghillie_Boots" => 'Bottes de Camouflage',
	"Chitin_Boots" => 'Chaussures en chitine',
	"Flak_Boots" => 'Bottes en métal',
	"Riot_Boots" => 'Bottes Anti-Émeute',
	"SCUBA_Flippers" => 'Palmes de Plongée',
	),
	"equip_hand" => array(
	"x" => '---',
	"Cloth_Gloves" => 'Gants en tissu',
	"Hide_Gloves" => 'Gants en cuir',
	"Fur_Gauntlets" => 'Gants en fourrure',
	"Ghillie_Gauntlets" => 'Gants de Camouflage',
	"Chitin_Gauntlets" => 'Gantelets en chitine',
	"Flak_Gauntlets" => 'Gantelets en métal',
	"Riot_Gauntlets" => 'Gants Anti-Émeute',
	),
	"equip_offhand" => array(
	"x" => '---',
	"Wooden_Shield" => 'Bouclier en bois',
	"Metal_Shield" => 'Bouclier en métal',
	"Riot_Shield" => 'Bouclier Anti-Émeute',
	),
	"engram_resources" => array(
	"Sparkpowder" => 'Poudre-étincelle',
	"Gunpowder" => 'Poudre à Canon',
	"Cementing_Paste" => 'Ciment',
	"Polymer" => 'Polymère',
	"Electronics" => 'Électroniques',
	"Absorbent_Substrate" => 'Absorbant toxique',
	),
	"engram_misc" => array(
	"Hide_Sleeping_Bag" => 'Sac de couchage',
	"Single_Panel_Flag" => 'Drapeau (Zone de couleur unique)',
	"Multi-Panel_Flag" => 'Drapeau (Multiples zones de couleur)',
	"Standing_Torch" => 'Torche sur Pied',
	"Simple_Bed" => 'Lit ordinaire',
	"Wardrums" => 'Tambours de Guerre',
	"Small_Crop_Plot" => 'Carré de culture - Petit',
	"Medium_Crop_Plot" => 'Carré de culture - Moyen',
	"Large_Crop_Plot" => 'Carré de culture - Grand',
	"Stone_Fireplace" => 'Cheminée en pierre',
	"Bunk_Bed" => 'Lits superposés',
	),
	"engram_container" => array(
	"Storage_Box" => 'Caisse de stockage',
	"Feeding_Trough" => 'Mangeoire',
	"Compost_Bin" => 'Composteur',
	"Large_Storage_Box" => 'Grande armoire de stockage',
	"Preserving_Bin" => 'Armoire de conservation',
	"Bookshelf" => 'Bibliothèque',
	"Refrigerator" => 'Réfrigérateur',
	"Vault" => 'Coffre-fort',
	),
	"engram_crafting" => array(
	"Campfire" => 'Feu de Camp',
	"Mortar_And_Pestle" => 'Mortier et Pilon',
	"Cooking_Pot" => 'Marmite suspendue',
	"Refining_Forge" => 'Forge',
	"Smithy" => 'Atelier',
	"Beer_Barrel" => 'Tonneau de Bière',
	"Fabricator" => 'Centre d\'usinage',
	"Industrial_Grill" => 'Grill industriel',
	"Industrial_Cooker" => 'Cuisinière industrielle',
	"Industrial_Forge" => 'Forge industrielle',
	"Chemistry_Bench" => 'Labo de chimie',
	),
	"engram_thatch" => array(
	"Thatch_Foundation" => 'Fondation en chaume',
	"Thatch_Wall" => 'Mur en chaume',
	"Thatch_Roof" => 'Toit en chaume',
	"Thatch_Doorframe" => 'Cadre de porte en chaume',
	"Thatch_Door" => 'Porte en chaume',
	"Sloped_Thatch_Roof" => 'Toit incliné en chaume',
	"Sloped_Thatch_Wall_Left" => 'Demi-pignon en chaume (Gauche)',
	"Sloped_Thatch_Wall_Right" => 'Demi-pignon en chaume (Droite)',
	),
	"engram_wood" => array(
	"Dinosaur_Gateway" => 'Cadre Dino-Porte en pierre',
	"Dinosaur_Gate" => 'Dino-Porte en bois',
	"Sloped_Wooden_Roof" => 'Toit incliné en bois',
	"Sloped_Wood_Wall_Left" => 'Demi-pignon en bois (Gauche)',
	"Sloped_Wood_Wall_Right" => 'Demi-pignon en bois (Droite)',
	"Wooden_Bench" => 'Banc en bois',
	"Wooden_Billboard" => 'Grand panneau en bois',
	"Wooden_Catwalk" => 'Passerelle en bois',
	"Wooden_Ceiling" => 'Plafond en bois',
	"Wooden_Chair" => 'Chaise en bois',
	"Wooden_Door" => 'Porte en bois',
	"Wooden_Doorframe" => 'Cadre de porte en bois',
	"Wooden_Fence_Foundation" => 'Fondation en bois pour enclos',
	"Wooden_Foundation" => 'Fondation en bois',
	"Wooden_Hatchframe" => 'Cadre de trappe en bois',
	"Wooden_Ladder" => 'Échelle en bois',
	"Wooden_Pillar" => 'Pilier en bois',
	"Wooden_Railing" => 'Balustrade en bois',
	"Wooden_Ramp" => 'Rampe en bois',
	"Wooden_Shield" => 'Bouclier en bois',
	"Wooden_Sign" => 'Panneau en bois',
	"Wooden_Spike_Wall" => 'Mur de piques en bois',
	"Wooden_Table" => 'Table en bois',
	"Wooden_Trapdoor" => 'Trappe en bois',
	"Wooden_Wall" => 'Mur en bois',
	"Wooden_Wall_Sign" => 'Pancarte murale en bois',
	"Wooden_Window" => 'Volet en bois',
	"Wooden_Windowframe" => 'Cadre de fenêtre en bois',
	),
	"engram_stone" => array(
	"Basic_Gravestone" => 'Pierre tombale',
	"Behemoth_Reinforced_Dinosaur_Gate" => 'Porte Béhémoth en bois renforcée',
	"Behemoth_Stone_Dinosaur_Gateway" => 'Cadre Dino-Porte Béhémoth en pierre',
	"Reinforced_Dinosaur_Gate" => 'Dino-Porte en bois renforcée',
	"Reinforced_Trapdoor" => 'Trappe renforcée',
	"Reinforced_Window" => 'Fenêtre renforcée',
	"Reinforced_Wooden_Door" => 'Porte en bois renforcée',
	"Sloped_Stone_Roof" => 'Toit incliné en pierre',
	"Sloped_Stone_Wall_Left" => 'Demi-pignon en pierre (Gauche)',
	"Sloped_Stone_Wall_Right" => 'Demi-pignon en pierre (Droite)',
	"Stone_Ceiling" => 'Plafond en pierre',
	"Stone_Dinosaur_Gateway" => 'Cadre Dino-Porte en pierre',
	"Stone_Doorframe" => 'Cadre de porte, en pierre',
	"Stone_Fence_Foundation" => 'Fondation en pierre pour enclos',
	"Stone_Foundation" => 'Fondation en pierre',
	"Stone_Hatchframe" => 'Cadre de trappe en pierre',
	"Stone_Pillar" => 'Pilier en pierre',
	"Stone_Railing" => 'Balustrade en pierre',
	"Stone_Wall" => 'Mur en pierre',
	"Stone_Windowframe" => 'Cadre de fenêtre en pierre',
	),
	"engram_metal" => array(
	"Metal_Spike_Wall" => 'Mur de piques en métal',
	"Metal_Sign" => 'Pancarte en métal',
	"Metal_Doorframe" => 'Cadre de porte en métal',
	"Sloped_Metal_Roof" => 'Toit incliné en métal',
	"Sloped_Metal_Wall_Left" => 'Demi-pignon en métal (Gauche)',
	"Sloped_Metal_Wall_Right" => 'Demi-pignon en métal (Droite)',
	"Metal_Railing" => 'Balustrade en métal',
	"Metal_Foundation" => 'Fondation en métal',
	"Metal_Wall" => 'Mur en métal',
	"Metal_Wall_Sign" => 'Panneau mural en métal',
	"Metal_Door" => 'Porte en métal',
	"Metal_Ramp" => 'Rampe en métal',
	"Metal_Pillar" => 'Pilier en métal',
	"Metal_Ceiling" => 'Plafond en métal',
	"Metal_Hatchframe" => 'Cadre de trappe en métal',
	"Metal_Fence_Foundation" => 'Fondation en métal pour enclos',
	"Metal_Trapdoor" => 'Trappe en métal',
	"Metal_Dinosaur_Gateway" => 'Cadre Dino-Porte en métal',
	"Metal_Dinosaur_Gate" => 'Dino-Porte en métal',
	"Metal_Ladder" => 'Échelle en métal',
	"Metal_Windowframe" => 'Cadre de fenêtre en métal',
	"Metal_Billboard" => 'Panneau en métal',
	"Metal_Window" => 'Volet en métal',
	"Metal_Catwalk" => 'Passerelle en métal',
	"Behemoth_Gateway" => 'Cadre Dino-Porte Béhémoth
',
	"Behemoth_Gate" => 'Porte Béhémoth
',
	),
	"engram_greenhouse" => array(
	"Greenhouse_Window" => 'Volet en verre
',
	"Greenhouse_Wall" => 'Mur en verre
',
	"Greenhouse_Doorframe" => 'Cadre de porte en verre
',
	"Greenhouse_Ceiling" => 'Plafond en verre
',
	"Greenhouse_Door" => 'Porte en verre
',
	"Greenhouse_Roof" => 'Toit en verre
',
	"Sloped_Greenhouse_Roof" => 'Toit incliné en verre
',
	"Sloped_Greenhouse_Wall_Right" => 'Demi-pignon en verre (Droite)

',
	"Sloped_Greenhouse_Wall_Left" => 'Demi-pignon en verre (Gauche)',
	"" => '',
	),
	"engram_vehicles" => array(
	"Wooden_Raft" => 'Radeau en bois
',
	),
	"engram_tools" => array(
	"Torch" => 'Torche',
	"Stone_Pick" => 'Pioche en pierre
',
	"Note" => 'Note
',
	"Stone_Hatchet" => 'Hache en pierre
',
	"Waterskin" => 'Gourde en peau
',
	"Paintbrush" => 'Pinceau
',
	"Blood_Extraction_Syringe" => 'Kit de Transfusion
',
	"Compass" => 'Boussole
',
	"Flare_Gun" => 'Pistolet de Détresse
',
	"Spyglass" => 'Longue-vue
',
	"Fishing_Rod" => 'Canne à pêche
',
	"Magnifying_Glass" => 'Loupe
',
	"Radio" => 'Radio
',
	"Smoke_Grenade" => 'Grenade fumigène
',
	"Metal_Pick" => 'Pioche en métal
',
	"Metal_Hatchet" => 'Hache en métal
',
	"Water_Jar" => 'Bocal d\'eau
',
	"Metal_Sickle" => 'Faucille
',
	"GPS" => 'GPS
',
	"Canteen" => 'Gourde en polymère
',
	"Spray_Painter" => 'Pistolet à Peinture
',
	"Transponder_Tracker" => 'Récepteur pour Transpondeur
',
	"Transponder_Node" => 'Transpondeur
',
	"Spear" => 'Lance en bois
',
	"Wooden_Club" => 'Massue
',
	"Pike" => 'Lance en métal
',
	"Metal_Sword" => 'Épée en métal',
	"Electric_Prod" => 'Matraque électrique
',
	"Slingshot" => 'Lance-pierres
',
	"Bola" => 'Bolas
',
	"Bow" => 'Arc
',
	"Crossbow" => 'Arbalète
',
	"Simple_Pistol" => 'Révolver
',
	"Longneck_Rifle" => 'Fusil à canon long
',
	"Shotgun" => 'Fusil à canon scié
',
	"Fabricated_Pistol" => 'Pistolet semi-auto
',
	"Pump-Action_Shotgun" => 'Fusil à pompe
',
	"Assault_Rifle" => 'Fusil d\'assaut
',
	"Rocket_Launcher" => 'Lance-Roquettes
',
	"Compound_Bow" => 'Arc à poulie
',
	"Fabricated_Sniper_Rifle" => 'Fusil de précision
',
	),
	"engram_ammunition" => array(
	"Stone_Arrow" => 'Flèche en pierre
',
	"Tranquilizer_Arrow" => 'Flèches tranquillisantes
',
	"Ballista_Bolt" => 'Carreau de Baliste
',
	"Simple_Bullet" => 'Balle ordinaire
',
	"Simple_Rifle_Ammo" => 'Balle de fusil ordinaire
',
	"Cannon_Ball" => 'Boulet de canon
',
	"Simple_Shotgun_Ammo" => 'Cartouche de fusil
',
	"Chain_Bola" => 'Bolas en chaîne métallique
',
	"Grappling_Hook" => 'Grappin
',
	"Advanced_Bullet" => 'Balle améliorée
',
	"Advanced_Rifle_Bullet" => 'Balle de fusil améliorée
',
	"Rocket_Propelled_Grenade" => 'Roquette
',
	"Tranquilizer_Dart" => 'Fléchette tranquillisante
',
	"Metal_Arrow" => 'Flèche en métal
',
	"Advanced_Sniper_Bullet" => 'Balle de fusil de précision
',
	),
	"engram_explosives" => array(
	"Grenade" => 'Grenade',
	"Improvised_Explosive_Device" => 'Piège explosif
',
	"C4_Remote_Detonator" => 'Détonateur à distance pour explosifs C4
',
	"C4_Charge" => 'Charge de C4
',
	"Homing_Underwater_Mine" => 'Mines sous-marines
',
	),
	"engram_turret" => array(
	"Ballista_Turret" => 'Tourelle Baliste
',
	"Catapult_Turret" => 'Tourelle Catapulte
',
	"Primitive_Cannon" => 'Canon',
	"Auto_Turret" => 'Tourelle Automatique
',
	"Minigun_Turret" => 'Tourelle Minigun
',
	"Rocket_Turret" => 'Tourelle Lance-Roquettes
',
	),
	"dossiers" => array(
	"Allosaurus" => 'Allosaure
',
	"Angler" => 'Angler
',
	"Ankylosaurus" => 'Ankylosaure',
	"Araneo" => 'Araneo',
	"Argentavis" => 'Argentavis',
	"Arthropluera" => 'Arthropleura',
	"Beelzebufo" => 'Beelzebufo 	
',
	"Brontosaurus" => 'Brontosaurus',
	"Carbonemys" => 'Carbonemys',
	"Carnotaurus" => 'Carnotaurus',
	"Castoroides" => 'Castoroides',
	"Coelacanth" => 'Coelacanth',
	"Compy" => 'Compy',
	"Dilophosaur" => 'Dilophosaurus',
	"Dimetrodon" => 'Dimetrodon',
	"Dimorphodon" => 'Dimorphodon',
	"Diplodocus" => 'Diplodocus',
	"Direbear" => 'Ours Sinistre',
	"Direwolf" => 'Loup Sinistre
',
	"Dodo" => 'Dodo',
	"Doedicurus" => 'Doedicurus',
	"Dunkleosteus" => 'Dunkleosteus',
	"Gigantosaurus" => 'Giganotosaurus',
	"Gigantopithecus" => 'Gigantopithecus',
	"Ichthyornis" => 'Ichthyosaurus',
	"Kairuku" => 'Kairuku',
	"Leech" => 'Sangsue
',
	"Lystrosaurus" => 'Lystrosaurus',
	"Mammoth" => 'Mammouth
',
	"Manta" => 'Manta
',
	"Megaloceros" => 'Megaloceros
',
	"Megalodon" => 'Mégalodon
',
	"Meganeura" => 'Meganeura
',
	"Mesopithecus" => 'Mesopithecus
',
	"Mosasaurus" => 'Mosasaurus',
	"Onyc" => 'Onyc
',
	"Oviraptor" => 'Oviraptor
',
	"Pachy" => 'Pachy
',
	"Paracer" => 'Paracer',
	"Parasaur" => 'Parasaure',
	"Pelagornis" => 'Pelagornis
',
	"Phiomia" => 'Phiomia
',
	"Piranha" => 'Piranha
',
	"Plesiosaur" => 'Plésiosaure
',
	"Procoptodon" => 'Procoptodon
',
	"Pteranodon" => 'Ptéranodon
',
	"Pulmonoscorpius" => 'Scorpion
',
	"Quetzal" => 'Quetzal
',
	"Raptor" => 'Raptor
',
	"Rex" => 'T-Rex
',
	"Sabertooth" => 'Sabertooth
',
	"Sabertooth_Salmon" => 'Sabertooth Salmon
',
	"Sarcosaurus" => 'Sarcosuchus
',
	"Spinosaur" => 'Spinosaurus
',
	"Stegosaurus" => 'Stegosaurus
',
	"Terror_Bird" => 'Terror Bird
',
	"Titanoboa" => 'Titanoboa
',
	"Titanomyrma" => 'Titanomyrma
',
	"Titanosaur" => 'Titanosaure
',
	"Triceratops" => 'Tricératops
',
	"Trilobite" => 'Trilobite
',
	"Woolly_Rhino" => 'Rhinocéros laineux
',
	),
	
);

?>