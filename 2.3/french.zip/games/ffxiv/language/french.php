<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:46
//File: games/ffxiv/language/french.php
//Source-Language: english

$french_array = array( 
	"classes" => array(
	0 => 'Inconnu',
	1 => 'Mage Noir',
	2 => 'Guerrier',
	3 => 'Chevalier Dragon',
	4 => 'Moine',
	5 => 'Paladin',
	6 => 'Barde',
	7 => 'Mage Blanc',
	8 => 'Invocateur',
	9 => 'Erudit',
	10 => 'Ninja',
	11 => 'Chevalier noir',
	12 => 'Astrologue',
	13 => 'Machiniste',
	14 => 'Samouraï',
	15 => 'Mage Rouge',
	16 => 'Gunbreaker',
	17 => 'Dancer',
	18 => 'Bluemage',
	),
	"races" => array(
	0 => 'Inconnu',
	1 => 'Elézen',
	2 => 'Roegadyn',
	3 => 'Hyur',
	4 => 'Miqo\'te',
	5 => 'Lalafell',
	6 => 'Ao Ra',
	7 => 'Viara',
	),
	"factions" => array(
	"twin_adder" => 'Ordre des deux vipères',
	"maelstrom" => 'Maelstrom',
	"flames" => 'Les Immortels',
	),
	"lang" => array(
	"ffxiv" => 'Final Fantasy XIV',
	"tank" => 'Tank',
	"support" => 'Guérisseur',
	"damage_dealer" => 'DPS',
	"uc_gender" => 'Sexe',
	"uc_male" => 'Masculin',
	"uc_female" => 'Féminin',
	"uc_guild" => 'Compagnie Libre',
	"uc_race" => 'Race',
	"uc_class" => 'Classe',
	"uc_cat_berufe" => 'Professions',
	"uc_level" => 'Niveau',
	"uc_grandcompany" => 'Grande Compagnie',
	"uc_twinadder" => 'Ordre des deux vipères',
	"uc_maelstrom" => 'Maelstrom',
	"uc_flames" => 'Les Immortels',
	"uc_city" => 'Cité',
	"uc_uldah" => 'Ul\'dah',
	"uc_limsa" => 'Limsa Lominsa',
	"uc_gridania" => 'Gridania',
	"up_alchemist" => 'Alchimiste',
	"up_leatherworker" => 'Tanneur',
	"up_goldsmith" => 'Orfèvre',
	"up_culinarian" => 'Cuisinier',
	"up_blacksmith" => 'Forgeron',
	"up_armorer" => 'Armurier',
	"up_weaver" => 'Couturier',
	"up_carpenter" => 'Menuisier',
	"up_fisher" => 'Pêcheur',
	"up_botanist" => 'Botaniste',
	"up_miner" => 'Mineur',
	"core_sett_fs_gamesettings" => 'Réglages de Final Fantasy XIV',
	"uc_faction" => 'Grande Compagnie',
	"uc_faction_help" => 'Choisissez la Grande Compagnie correspondant à votre compagnie libre.',
	),
	
);

?>