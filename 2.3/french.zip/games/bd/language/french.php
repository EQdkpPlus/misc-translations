<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:46
//File: games/bd/language/french.php
//Source-Language: english

$french_array = array( 
	"classes" => array(
	1 => 'Guerrier',
	2 => 'Valkyrie',
	3 => 'Magicien',
	4 => 'Magicienne',
	5 => 'Rôdeuse',
	6 => 'Berserker',
	7 => 'Tamer',
	8 => 'Sorcière',
	9 => 'Maehwa',
	10 => 'Musa',
	11 => 'Kunoichi',
	12 => 'Ninja',
	),
	"professions" => array(
	"primary" => array(
	1 => 'Récolte',
	2 => 'Transformation',
	3 => 'Cuisine',
	4 => 'Alchimie',
	5 => 'Domptage',
	6 => 'Pêche',
	7 => 'Chasse',
	8 => 'Commerce',
	9 => 'Agriculture',
	),
	"secondary" => array(
	1 => 'Points de connaissances',
	2 => 'Points de contribution',
	),
	),
	"roles" => array(
	1 => 'Tank',
	2 => 'Soutien',
	3 => 'Dégâts',
	),
	"lang" => array(
	"bd" => 'Black Desert',
	"tank" => 'Tank',
	"support" => 'Guerrisseur',
	"damage_dealer" => 'Dégats',
	"uc_class" => 'Classe',
	"uc_level" => 'Niveau',
	"uc_cat_profession" => 'Professions',
	"uc_prof1_name" => 'Profession: Nom',
	"uc_prof1_value" => 'Profession: Niveau',
	"uc_prof2_name" => 'Points',
	"uc_prof2_value" => 'Valeur',
	),
	
);

?>