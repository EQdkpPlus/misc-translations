<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:46
//File: games/revelation/language/french.php
//Source-Language: english

$french_array = array( 
	"classes" => array(
	0 => 'Inconnue',
	1 => 'Magépée',
	2 => 'Invocateur',
	3 => 'Hoplite',
	4 => 'Maître d\'armes',
	5 => 'Franc-tireur',
	6 => 'Occultiste',
	),
	"races" => array(
	1 => 'Humain',
	),
	"roles" => array(
	1 => 'Soin',
	2 => 'Tank',
	3 => 'DPS',
	),
	"lang" => array(
	"revelation" => 'Revelation',
	"uc_gender" => 'Genre',
	"uc_male" => 'Masculin',
	"uc_female" => 'Féminin',
	"uc_race" => 'Race',
	"uc_class" => 'Classe',
	"uc_level" => 'Niveau',
	"uc_guild" => 'Guilde',
	"darkfall" => 'Chute sombre',
	"deserted_shrine" => 'Sanctuaire déserté',
	"misty_hallow" => 'Vallon brumeux',
	"grand_bulwark" => 'Grand rempart',
	"scour_dungeon" => 'Donjon écumable',
	"mech_citadel" => 'Citadelle méca',
	"bounty_hunter" => 'Chasseur de primes',
	"clanwar" => 'Guerre de Guilde',
	),
	
);

?>