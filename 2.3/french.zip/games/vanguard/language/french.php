<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:46
//File: games/vanguard/language/french.php
//Source-Language: english

$french_array = array( 
	"classes" => array(
	0 => 'Inconnue',
	1 => 'Barde',
	2 => 'Blood Mage',
	3 => 'Clerc',
	4 => 'Disciple',
	5 => 'Dread Knight',
	6 => 'Druide',
	7 => 'Inquisiteur',
	8 => 'Moine',
	9 => 'Nécromancien',
	10 => 'Paladin',
	11 => 'Psioniste',
	12 => 'Rôdeur',
	13 => 'Roublard',
	14 => 'Chamane',
	15 => 'Sorcier',
	16 => 'Guerrier',
	),
	"races" => array(
	0 => 'Inconnue',
	1 => 'Elfe noir',
	2 => 'Nain',
	3 => 'Gnome',
	4 => 'Gobelin',
	5 => 'Semi-Elfe',
	6 => ' Hobbit',
	7 => 'Grand Elfe',
	8 => 'Kojani',
	9 => 'Kurashasa',
	10 => 'Géant',
	11 => 'Mordebi',
	12 => 'Orc',
	13 => 'Qaliathari',
	14 => 'Raki',
	15 => 'Thestran',
	16 => 'Varanjar',
	17 => 'Varanthari',
	18 => 'Vulmane',
	19 => 'Elfe des bois',
	),
	"roles" => array(
	1 => 'Guérisseur',
	2 => 'Tank',
	3 => 'Distant',
	4 => 'Mélée',
	),
	"lang" => array(
	"vanguard" => 'Vanguard: Saga of Heroes',
	"unknown" => 'Inconnue',
	"cloth" => 'Tissu',
	"leather" => 'Cuir',
	"chain" => 'Mailles',
	"plate" => 'Plaque',
	"uc_race" => 'Race',
	"uc_class" => 'Classe',
	),
	
);

?>