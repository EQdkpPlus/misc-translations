<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:46
//File: games/wildstar/language/french.php
//Source-Language: english

$french_array = array( 
	"factions" => array(
	"exile" => 'Exilé',
	"dominion" => 'Dominion',
	),
	"classes" => array(
	0 => 'Inconnue',
	1 => 'Guerrier',
	2 => 'Arcanero',
	3 => 'Rôdeur',
	4 => 'Esper',
	5 => 'Toubib',
	6 => 'Ingénieur',
	),
	"races" => array(
	0 => 'Inconnue',
	1 => 'Humain',
	2 => 'Cassien',
	3 => 'Granok',
	4 => 'Draken',
	5 => 'Aurin',
	6 => 'Mechari',
	7 => 'Mordesh',
	8 => 'Chua',
	),
	"roles" => array(
	1 => 'Guérisseur',
	2 => 'Tank',
	3 => 'Dégat',
	),
	"lang" => array(
	"wildstar" => 'Wildstar Online',
	"game_language" => 'Langue du jeu',
	"heavy" => 'Armure puissante',
	"medium" => 'Armure moyenne',
	"light" => 'Armure légère',
	"uc_path" => 'Vocation',
	"uc_gender" => 'Sexe',
	"uc_male" => 'Male',
	"uc_female" => 'Femelle',
	"uc_guild" => 'Guilde',
	"uc_race" => 'Race',
	"uc_class" => 'Classe',
	"core_sett_fs_gamesettings" => 'Paramètres de Wildstar Online',
	"uc_faction" => 'Faction',
	"uc_faction_help" => 'Choisissez la faction par défaut',
	"uc_path_0" => '-',
	"uc_path_1" => 'Explorateur',
	"uc_path_2" => 'Savant',
	"uc_path_3" => 'Soldat',
	"uc_path_4" => 'Colon',
	"wildstar_event_warplots" => 'Terrains de guerre (PVP)',
	"wildstar_event_adventure" => 'Aventures (5 personnes)',
	),
	
);

?>