<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: French	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:46
//File: games/akd/language/french.php
//Source-Language: english

$french_array = array( 
	"races" => array(
	0 => '',
	1 => 'Gardien',
	2 => 'Duelliste',
	3 => 'Ravageur',
	4 => 'Assassin',
	5 => 'Samouraï',
	6 => 'Bandit',
	7 => 'Canonnier',
	8 => 'Archer',
	9 => 'Magicien',
	10 => 'Sorcier',
	11 => 'Barde',
	12 => 'Nécromancien',
	13 => 'Paladin',
	),
	"classes" => array(
	0 => '',
	1 => 'Gardien',
	2 => 'Duelliste',
	3 => 'Ravageur',
	4 => 'Assassin',
	5 => 'Samouraï',
	6 => 'Bandit',
	7 => 'Canonnier',
	8 => 'Archer',
	9 => 'Magicien',
	10 => 'Sorcier',
	11 => 'Barde',
	12 => 'Nécromancien',
	13 => 'Paladin',
	),
	"roles" => array(
	1 => 'Tank',
	2 => 'Guérisseur',
	3 => 'Distance',
	4 => 'Mélée',
	),
	"eidolons" => array(
	0 => 'Choisissez',
	1 => 'Astro',
	2 => 'Evie',
	3 => 'Zhulong',
	4 => 'Lina',
	5 => 'Nephilim',
	6 => 'Solénus',
	7 => 'Hypérion',
	8 => 'Benkei',
	9 => 'Faust',
	10 => 'Gilgamesh',
	11 => 'Valkyrie',
	12 => 'Nalani',
	13 => 'Gabrièle',
	14 => 'Hera',
	15 => 'Isis',
	16 => 'Shiva',
	17 => 'Yinglong',
	18 => 'Léviathan',
	19 => 'Garuda',
	20 => 'Fafnir',
	21 => 'Hydre',
	22 => 'Efrit',
	23 => 'Arthur',
	24 => 'Kitsune',
	25 => 'Thanator',
	26 => 'Minos',
	27 => 'Mochizuki',
	28 => 'Cléopâtre',
	29 => 'Yuna',
	30 => 'Lilith',
	31 => 'Sheherazade',
	32 => 'Yukime',
	33 => 'Alucard',
	34 => 'Balder',
	35 => 'Hansel et Gretel',
	36 => 'Athena',
	37 => 'Ostara',
	),
	"eidolons2" => array(
	0 => 'Choisissez',
	1 => 'Astro',
	2 => 'Evie',
	3 => 'Zhulong',
	4 => 'Lina',
	5 => 'Nephilim',
	6 => 'Solénus',
	7 => 'Hypérion',
	8 => 'Benkei',
	9 => 'Faust',
	10 => 'Gilgamesh',
	11 => 'Valkyrie',
	12 => 'Nalani',
	13 => 'Gabrièle',
	14 => 'Hera',
	15 => 'Isis',
	16 => 'Shiva',
	17 => 'Yinglong',
	18 => 'Léviathan',
	19 => 'Garuda',
	20 => 'Fafnir',
	21 => 'Hydre',
	22 => 'Efrit',
	23 => 'Arthur',
	24 => 'Kitsune',
	25 => 'Thanator',
	26 => 'Minos',
	27 => 'Mochizuki',
	28 => 'Cléopâtre',
	29 => 'Yuna',
	30 => 'Lilith',
	31 => 'Sheherazade',
	32 => 'Yukime',
	33 => 'Alucard',
	34 => 'Balder',
	35 => 'Hansel et Gretel',
	36 => 'Athena',
	37 => 'Ostara',
	),
	"eidolons3" => array(
	0 => 'Choisissez',
	1 => 'Astro',
	2 => 'Evie',
	3 => 'Zhulong',
	4 => 'Lina',
	5 => 'Nephilim',
	6 => 'Solénus',
	7 => 'Hypérion',
	8 => 'Benkei',
	9 => 'Faust',
	10 => 'Gilgamesh',
	11 => 'Valkyrie',
	12 => 'Nalani',
	13 => 'Gabrièle',
	14 => 'Hera',
	15 => 'Isis',
	16 => 'Shiva',
	17 => 'Yinglong',
	18 => 'Léviathan',
	19 => 'Garuda',
	20 => 'Fafnir',
	21 => 'Hydre',
	22 => 'Efrit',
	23 => 'Arthur',
	24 => 'Kitsune',
	25 => 'Thanator',
	26 => 'Minos',
	27 => 'Mochizuki',
	28 => 'Cléopâtre',
	29 => 'Yuna',
	30 => 'Lilith',
	31 => 'Sheherazade',
	32 => 'Yukime',
	33 => 'Alucard',
	34 => 'Balder',
	35 => 'Hansel et Gretel',
	36 => 'Athena',
	37 => 'Ostara',
	),
	"lang" => array(
	"akd" => 'Aura Kingdom',
	"uc_level" => 'Niveau',
	"uc_race" => 'Classe secondaire',
	"uc_class" => 'Classe principale',
	"uc_eidolon" => '1. Eidolon',
	"uc_eidolon2" => '2. Eidolon',
	"uc_eidolon3" => '3. Eidolon',
	),
	
);

?>