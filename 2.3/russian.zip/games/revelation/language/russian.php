<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Russian	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:47
//File: games/revelation/language/russian.php
//Source-Language: english

$russian_array = array( 
	"classes" => array(
	0 => 'Неизвестно',
	1 => 'Маг',
	2 => 'Друид',
	3 => 'Страж',
	4 => 'Рыцарь',
	5 => 'Стрелок',
	6 => 'Жнец',
	),
	"races" => array(
	1 => 'Человек',
	),
	"roles" => array(
	1 => 'Хил',
	2 => 'Танк',
	3 => 'ДД',
	),
	"lang" => array(
	"revelation" => 'Revelation',
	"uc_gender" => 'Пол',
	"uc_male" => 'Мужской',
	"uc_female" => 'Женский',
	"uc_race" => 'Раса',
	"uc_class" => 'Класс',
	"uc_level" => 'Уровень',
	"uc_guild" => 'Гильдия',
	"darkfall" => 'Darkfall',
	"deserted_shrine" => 'Пустынная гробница',
	"misty_hallow" => 'Туманная реликвия',
	"grand_bulwark" => 'Большой бастион',
	"scour_dungeon" => 'Размытое подземелье',
	"mech_citadel" => 'Механическая цитадель',
	"bounty_hunter" => 'Охотник за головами',
	"clanwar" => 'Клановая война',
	),
	
);

?>