<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Russian	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:47
//File: games/bd/language/russian.php
//Source-Language: english

$russian_array = array( 
	"classes" => array(
	1 => 'Воин',
	2 => 'Валькирия',
	3 => 'Волшебник',
	4 => 'Колдунья',
	5 => 'Лучница',
	6 => 'Варвар',
	7 => 'Мистик',
	8 => 'Волшебница',
	9 => 'Маэва',
	10 => 'Мастер меча',
	11 => 'Куноичи',
	12 => 'Ниндзя',
	),
	"professions" => array(
	"primary" => array(
	1 => 'Сбор',
	2 => 'Изготовление',
	3 => 'Кулинария',
	4 => 'Алхимия',
	5 => 'Укрощение',
	6 => 'Рыбалка',
	7 => 'Охота',
	8 => 'Торговля',
	9 => 'Огород',
	),
	"secondary" => array(
	1 => 'Очки знаний',
	2 => 'Очки взноса',
	),
	),
	"roles" => array(
	1 => 'Танк',
	2 => 'Саппорт',
	3 => 'ДД',
	),
	"lang" => array(
	"bd" => 'Black Desert',
	"tank" => 'Танк',
	"support" => 'Хил',
	"damage_dealer" => 'ДД',
	"uc_class" => 'Класс',
	"uc_level" => 'Уровень',
	"uc_cat_profession" => 'Профессии',
	"uc_prof1_name" => 'Профессия: Имя',
	"uc_prof1_value" => 'Профессия: Уровень',
	"uc_prof2_name" => 'Очки',
	"uc_prof2_value" => 'Значение',
	),
	
);

?>