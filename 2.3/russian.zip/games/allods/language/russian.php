<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Russian	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:47
//File: games/allods/language/russian.php
//Source-Language: english

$russian_array = array( 
	"classes" => array(
	0 => 'Неизвестно',
	1 => 'Воин',
	2 => 'Храмовник',
	8 => 'Скаут',
	3 => 'Жрец',
	6 => 'Язычник',
	5 => 'Волшебник',
	4 => 'Некромант',
	7 => 'Мистик',
	9 => 'Бард',
	10 => 'Инженер',
	),
	"races" => array(
	0 => 'Неизвестно',
	1 => 'Кания',
	2 => 'Эльфы',
	3 => 'Гибберлинги',
	4 => 'Хадаган',
	5 => 'Орки',
	6 => 'Восставшие',
	7 => 'Прайдены',
	),
	"lang" => array(
	"allods" => 'Аллоды Онлайн',
	"plate" => 'Латы',
	"cloth" => 'Ткань',
	"leather" => 'Кожа',
	"uc_gender" => 'Пол',
	"uc_male" => 'Мужской',
	"uc_female" => 'Женский',
	"uc_branch" => 'Архетип',
	"uc_guild" => 'Гильдия',
	"uc_race" => 'Раса',
	"uc_class" => 'Класс',
	"core_sett_fs_gamesettings" => 'Настройки Аллодов Онлайн',
	"uc_faction" => 'Фракция',
	"uc_faction_help" => 'Выберите фракцию по умолчанию',
	"uc_abranch_0" => '-',
	"uc_abranch_1" => 'Вояка',
	"uc_abranch_2" => 'Ратник',
	"uc_abranch_3" => 'Паладин',
	"uc_abranch_4" => 'Храмовник',
	"uc_abranch_5" => 'Проныра',
	"uc_abranch_6" => 'Лучник',
	"uc_abranch_7" => 'Капеллан',
	"uc_abranch_8" => 'Священник',
	"uc_abranch_9" => 'Знахарь',
	"uc_abranch_10" => 'Друид',
	"uc_abranch_11" => 'Магистр',
	"uc_abranch_12" => 'Чародей',
	"uc_abranch_13" => 'Чернокнижник',
	"uc_abranch_14" => 'Провидец',
	"uc_abranch_15" => 'Солдат',
	"uc_abranch_16" => 'Боец',
	"uc_abranch_17" => 'Комиссар',
	"uc_abranch_18" => 'Каратель',
	"uc_abranch_19" => 'Диверсант',
	"uc_abranch_20" => 'Головорез',
	"uc_abranch_21" => 'Политрук',
	"uc_abranch_22" => 'Настоятель',
	"uc_abranch_23" => 'Шаман',
	"uc_abranch_24" => 'Заклинатель',
	"uc_abranch_25" => 'Реаниматор',
	"uc_abranch_26" => 'Целитель',
	"uc_abranch_27" => 'Адепт',
	"uc_abranch_28" => 'Мыслитель',
	"uc_abranch_29" => 'Барабанщик',
	"uc_abranch_30" => 'Певчий',
	"uc_abranch_31" => '**временное значение**',
	"uc_abranch_32" => '**временное значение**',
	"uc_abranch_33" => '**временное значение**',
	"uc_abranch_34" => '**временное значение**',
	),
	
);

?>