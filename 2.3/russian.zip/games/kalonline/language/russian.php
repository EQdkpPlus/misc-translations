<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Russian	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:47
//File: games/kalonline/language/russian.php
//Source-Language: english

$russian_array = array( 
	"classes" => array(
	0 => 'Неизвестно',
	1 => 'Вор',
	2 => 'Воин',
	3 => 'Маг',
	4 => 'Лучник',
	),
	"races" => array(
	0 => 'Неизвестно',
	1 => 'Человек',
	),
	"roles" => array(
	1 => array(
	0 => '3',
	),
	2 => array(
	0 => '2',
	),
	3 => array(
	0 => '2',
	1 => '3',
	),
	4 => array(
	0 => '1',
	1 => '4',
	),
	5 => array(
	0 => '1',
	1 => '4',
	),
	),
	"lang" => array(
	"kalonline" => 'KalOnline',
	"role1" => 'Лекарь',
	"role2" => 'Танк',
	"role3" => 'Атакующий',
	"role4" => 'Дебафер',
	"role5" => 'Боец',
	"uc_race" => 'Раса',
	"uc_class" => 'Класс',
	"core_sett_fs_gamesettings" => 'Настройки KalOnline',
	),
	
);

?>