<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Russian	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:47
//File: games/cex/language/russian.php
//Source-Language: english

$russian_array = array( 
	"servers" => array(
	0 => 'выберите сервер',
	1 => 'Пурист',
	2 => 'Расслабленный',
	3 => 'Хардкор',
	4 => 'Ролевая игра',
	5 => 'Экспериментальный',
	6 => 'Случайный',
	7 => 'Частный сервер',
	),
	"classes" => array(
	0 => 'выберите оружие',
	1 => 'Меч',
	2 => 'Молот',
	3 => 'Лук',
	4 => 'Ближний бой',
	5 => 'Вытягивание жизни',
	),
	"religions" => array(
	0 => 'выберите религию',
	1 => 'Кром',
	2 => 'Сет',
	3 => 'Митра',
	4 => 'Йог',
	),
	"races" => array(
	0 => 'Неизвестно',
	1 => 'Хайбориец',
	2 => 'Киммериец',
	3 => 'Стигиец',
	4 => 'Племя химелийцев',
	5 => 'Гирканиец/Тураниец',
	6 => 'Кхитан',
	7 => 'Кушит',
	8 => 'Нордхеймер',
	9 => 'Пикт',
	10 => 'Шемит',
	11 => 'Дарфари',
	12 => 'Вендианец',
	13 => 'Замориец',
	14 => 'Зингариец',
	),
	"roles" => array(
	0 => 'Хил',
	1 => 'Танк',
	2 => 'ДД',
	3 => 'Ближний бой',
	),
	"lang" => array(
	"cex" => 'Conan Exiles',
	"uc_race" => 'раса',
	"uc_class" => 'Предпочитаемое оружие',
	"uc_religion" => 'Религия',
	"uc_cat_misc" => 'разное',
	"uc_cat_stats" => 'Характеристики персонажа',
	"uc_yes" => 'Да',
	"uc_no" => 'Нет',
	"uc_unknown" => 'неизвестно',
	"uc_guild" => 'Кабал',
	"uc_level" => 'Уровень',
	"uc_testlive" => 'Доступ к Testlive',
	"uc_server" => 'Сервер',
	"uc_health" => 'Здоровье',
	"uc_stamina" => 'Выносливость',
	"uc_ecumbrance" => 'Максимальный вес',
	"uc_might" => 'Сила',
	"uc_accuracy" => 'Точность',
	"uc_atleticism" => 'Атлетизм',
	"uc_metabolism" => 'Метаболизм',
	"uc_resilience" => 'Стойкость',
	"T1" => 'Т1',
	"core_sett_fs_gamesettings" => 'Настройки Conan Exiles',
	),
	
);

?>