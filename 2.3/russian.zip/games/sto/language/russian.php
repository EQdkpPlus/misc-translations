<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Russian	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:47
//File: games/sto/language/russian.php
//Source-Language: english

$russian_array = array( 
	"factions" => array(
	1 => 'Федерация',
	2 => 'Федерация (The Original Series)',
	3 => 'Клингонская Империя',
	4 => 'Ромуланская Республика',
	5 => 'Доминион',
	),
	"classes" => array(
	0 => 'Неизвестно',
	1 => 'Инженерия',
	2 => 'Наука',
	3 => 'Тактика',
	),
	"races" => array(
	0 => 'Неизвестно',
	1 => 'Андорианец',
	2 => 'Баджорец',
	3 => 'Бензит',
	4 => 'Бетазоид',
	5 => 'Болианец',
	6 => 'Человек',
	7 => 'Саурианец',
	8 => 'Трилл',
	9 => 'Соединенный трилл',
	10 => 'Вулканец',
	11 => 'Телларит',
	12 => 'Каитианин',
	13 => 'Регилианин',
	14 => 'Паклид',
	15 => 'Клингон',
	16 => 'Ференги',
	17 => 'Талаксианец',
	18 => 'Освобожденный борг',
	19 => 'Кардассианец',
	20 => 'Андорианец',
	21 => 'Человек',
	22 => 'Телларит',
	23 => 'Вулканец',
	24 => 'Горн',
	25 => 'Клингон',
	26 => 'Летианин',
	27 => 'Наусикаанец',
	28 => 'Орионец',
	29 => 'Соединенный трилл',
	30 => 'Ферасанин',
	31 => 'Талаксианец',
	32 => 'Освобожденный борг',
	33 => 'Кардассианец',
	34 => 'Ромуланец',
	35 => 'Ремианец',
	36 => 'Освобожденный борг',
	37 => 'Джем\'хадар',
	38 => 'Авангард Джем\'хадар',
	),
	"lang" => array(
	"sto" => 'Star Trek Online',
	"uc_race" => 'Раса',
	"uc_class" => 'Класс',
	"uc_faction" => 'Фракция',
	"uc_ruf" => 'Репутация',
	"uc_cat_uc_ruf" => 'Репутация',
	"uc_level" => 'Уровень',
	"uc_ruf_1" => 'Оперативная группа Омега',
	"uc_ruf_2" => 'Новый Ромулус',
	"uc_ruf_3" => 'Ударные силы Нукара',
	"uc_ruf_4" => 'Объединённое командование Дайсона',
	"uc_ruf_5" => 'Контр-командование 8472',
	"uc_ruf_6" => 'Альянс Дельта',
	"uc_ruf_7" => 'Иконианское сопротивление',
	"uc_ruf_8" => 'Оперативная группа землян',
	"uc_ruf_9" => 'Временная оборонная инициатива',
	"uc_ruf_10" => 'Восстановительная инициатива Лукари',
	"uc_ruf_11" => 'Конкурентные игры',
	"uc_ruf_12" => 'Оперативная группа Гамма',
	"uc_ruf_13" => 'События',
	),
	
);

?>