<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Russian	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:47
//File: games/bs/language/russian.php
//Source-Language: english

$russian_array = array( 
	"factions" => array(
	"cerulean_order" => 'Лазурный Орден',
	"crimson_legion" => 'Багровый Легион',
	),
	"regions" => array(
	"eu" => 'Европа',
	"na" => 'Северная Америка',
	),
	"races" => array(
	0 => 'Неизвестно',
	1 => 'Ван',
	2 => 'Лин',
	3 => 'Фэн',
	4 => 'Шэн',
	),
	"classes" => array(
	0 => 'Неизвестно',
	1 => 'Мастер клинка',
	2 => 'Мастер секиры',
	3 => 'Мастер призыва',
	4 => 'Мастер стихий',
	5 => 'Мастер кунг-фу',
	6 => 'Мастер тени',
	7 => 'Мастер клинка линов',
	8 => 'Мастер духов',
	9 => 'Мастер Ци',
	10 => 'Мастер стрельбы',
	11 => 'Мастер гнева',
	12 => 'Мастер лука',
	),
	"genders" => array(
	0 => 'Мужчина',
	1 => 'Женщина',
	),
	"lang" => array(
	"bs" => 'Blade & Soul',
	"core_sett_fs_gamesettings" => 'Настройки Blade & Soul',
	"uc_faction" => 'Фракция',
	"uc_gender" => 'Пол',
	"uc_guild" => 'Клан',
	"uc_race" => 'Раса',
	"uc_class" => 'Класс',
	"uc_level" => 'Уровень',
	"uc_hongmoon" => 'Уровень Пути Хона',
	"uc_region" => 'Регион',
	"raid_bt" => 'Skybreak Spire',
	"raid_vt" => 'Temple of Eluvium',
	"raid_sk" => 'Scion\'s Keep',
	"raid_tt" => 'Nightfall Sanctuary',
	"raid_et" => 'Scarlet Conservatory',
	"raid_ia" => 'Steelbreaker',
	),
	
);

?>