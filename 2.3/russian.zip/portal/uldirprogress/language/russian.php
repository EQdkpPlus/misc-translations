<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Russian	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:47
//File: portal/uldirprogress/language/russian.php
//Source-Language: english

$lang = array( 
	"uldirprogress" => 'Фактический прогресс Ульдира',
	"uldirprogress_name" => 'Прогресс Ульдира',
	"uldirprogress_desc" => 'Берите здесь правильное значение вашего прогресса для каждого босса.',
	"uldirprogress_f_boss1" => 'Талок',
	"uldirprogress_f_boss2" => 'МАТРИАРХ',
	"uldirprogress_f_boss3" => 'Зловонный пожиратель',
	"uldirprogress_f_boss4" => 'Зек\'воз',
	"uldirprogress_f_boss5" => 'Вектис',
	"uldirprogress_f_boss6" => 'Зул',
	"uldirprogress_f_boss7" => 'Митракс Развоплотитель',
	"uldirprogress_f_boss8" => 'Г\'уун',
	"uldir_no" => 'открытый',
	"uldir_nhc" => 'нормальный',
	"uldir_hc" => 'героический',
	"uldir_myth" => 'мифический',
	"test" => array(
	0 => 'Открытый',
	1 => 'Нормальный',
	2 => 'Героический',
	3 => 'Мифический',
	),
	
);

?>