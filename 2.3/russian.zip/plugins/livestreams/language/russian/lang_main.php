<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Russian	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:47
//File: plugins/livestreams/language/russian/lang_main.php
//Source-Language: english

$lang = array( 
	"livestreams" => 'Прямые трансляции',
	"livestreams_short_desc" => 'Прямые трансляции',
	"livestreams_long_desc" => 'Показывает прямые трансляции ваших пользователей или других стримеров.',
	"ls_plugin_not_installed" => 'Плагин "Прямые трансляции" не установлен.',
	"ls_config_saved" => 'Настройки были успешно сохранены.',
	"ls_livestreams" => 'Прямые трансляции',
	"ls_fs_general" => 'Общие',
	"ls_fs_twitch" => 'Twitch',
	"ls_f_twitch_streams" => 'Трансляции на Twitch',
	"ls_f_help_twitch_streams" => 'Вставьте сюда других стримеров на Twitch, по одного на строку',
	"ls_f_show_offline" => 'Показывать оффлайн-трансляции',
	"ls_f_open_platform" => 'Открывать трансляции прямо на платформах',
	"ls_f_twitch_clientid" => 'ID клиента приложения Twitch',
	"ls_f_help_twitch_clientid" => 'Создайте новое приложение на https://dev.twitch.tv/console/apps и вставьте сюда ID клиента. Вы можете ввести http://localhost в Redirect-URL.',
	"ls_f_twitch_clientsecret" => 'Client-Secret приложения Twitch',
	"ls_f_help_twitch_clientsecret" => 'Вы можете создать Client-Secret с помощью кнопки "New Secret".',
	"ls_viewer" => 'Просмотр',
	"ls_fs_youtube" => 'YouTube',
	"ls_f_youtube_streams" => 'Трансляции на YouTube',
	"ls_f_help_youtube_streams" => 'Вставьте сюда другие каналы YouTube, по одному на строку',
	"ls_f_youtube_clientid" => 'YouTube API-Key',
	"ls_f_help_youtube_clientid" => 'Создайте новый проект по ссылке https://console.developers.google.com/apis/ и добавьте "YouTube Data API v3" в ваш проект. Затем создайте учётные данные и добавьте API-Key в это поле.',
	
);

?>