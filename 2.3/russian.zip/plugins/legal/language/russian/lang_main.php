<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Russian	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:47
//File: plugins/legal/language/russian/lang_main.php
//Source-Language: english

$lang = array( 
	"legal" => 'Правовая информация',
	"legal_short_desc" => 'Правовые вещи, такие как данные карточек, отказ от ответственности и политика конфиденциальности',
	"legal_long_desc" => 'Этот плагин добавляет правовые вещи, такие как данные карточек, отказ от ответственности и политика конфиденциальности.',
	"lg_plugin_not_installed" => 'Плагин "Правовая информация" не установлен.',
	"lg_fs_general" => 'Общие',
	"lg_f_version" => 'Версия',
	"lg_f_show_eu_cookiehint" => 'Уведомление пользователя об использовании cookie-файлов',
	"lg_f_help_show_eu_cookiehint" => 'В соответствии с директивой ЕС 2009/136/EG веб-сайты обязаны информировать посетителей об использовании ими cookie-файлов.',
	"lg_f_contact" => 'Контактные данные владельца веб-сайта',
	"lg_f_add_privacy" => 'Дополнительный текст для политики конфиденциальности',
	"lg_f_add_disclaimer" => 'Дополнительный текст для отказа от ответственности',
	"lg_privacypolicy" => 'Политика конфиденциальности',
	"lg_notice" => 'Данные карточек',
	
);

?>