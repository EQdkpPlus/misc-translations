<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Russian	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:47
//File: plugins/chat/language/russian/lang_main.php
//Source-Language: english

$lang = array( 
	"chat" => 'Чат',
	"chat_short_desc" => 'Чат',
	"chat_long_desc" => 'Чат с другими людьми, с одним или больше человек',
	"chat_view" => 'Чат',
	"chat_guildchat" => 'Чат гильдии',
	"chat_filter_user" => 'Фильтровать пользователей',
	"chat_all_conversations" => 'Все беседы',
	"chat_conversation_with" => 'Беседа с',
	"chat_user_online" => 'Пользователь онлайн',
	"chat_conversation" => 'Беседа',
	"chat_no_unread" => 'Непрочитанных сообщений нет',
	"chat_fs_ajax" => 'Ajax',
	"chat_f_reload_chat" => 'Время обновления чата',
	"chat_f_help_reload_chat" => 'В секундах',
	"chat_f_reload_onlinelist" => 'Время обновления онлайн-списка',
	"chat_f_help_reload_onlinelist" => 'В минутах',
	"chat_mod_pub" => 'Модератор публичного чата',
	"chat_read" => 'Читать',
	"chat_fs_sounds" => 'Звуки',
	"chat_f_new_message_sound" => 'Новое сообщение',
	
);

?>