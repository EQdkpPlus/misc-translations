<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Russian	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:47
//File: plugins/donations/language/russian/lang_main.php
//Source-Language: english

$lang = array( 
	"donations" => 'Пожертвования',
	"donations_short_desc" => 'Управление пожертвованиями для вашей гильдии',
	"donations_long_desc" => 'Управление пожертвованиями для вашей гильдии, которая принимает платежи через PayPal.',
	"donations_plugin_not_installed" => 'Плагин "Пожертвования" не установлен.',
	"donations_donate" => 'Пожертвовать',
	"donations_donationslist" => 'Смотреть список пожертвований',
	"donations_fs_general" => 'Общие',
	"donations_f_min_value" => 'Минимальное значение для пожертвований',
	"donations_f_free_or_custom" => 'Выбираемые значения',
	"donations_f_custom_values" => 'Заранее определённые значения',
	"donations_f_custom_free" => 'Пользователь может выбирать любое значение',
	"donations_f_custom_custom" => 'Возможные значения пожертвований',
	"donations_f_help_custom_values" => 'Вставить возможные значения для пожертвований, разделенные точкой с запятой',
	"donations_fs_goal" => 'Цель пожертвований',
	"donations_f_goal_type" => 'Выберите тип цели для пожертвований',
	"donations_f_goal_no" => 'Нет цели',
	"donations_f_goal_monthly" => 'Месячная сумма',
	"donations_f_goal_fixedsum" => 'Общая сумма',
	"donations_f_goal_value" => 'Цель пожертвований',
	"donations_f_goal_display_type" => 'Представление статуса пожертвований',
	"donations_f_goal_display_type_progess" => 'Индикатор прогресса',
	"donations_f_goal_display_type_covered" => 'Покрытые месяцы',
	"donations_fs_paypal" => 'PayPal',
	"donations_f_paypal_email" => 'Адреса получателей',
	"donations_f_help_paypal_email" => 'Введите адрес электронной почты PayPal. Также вы можете ввести адрес PayPal.me, например paypal.me/EQdkpPlus. Пожертвования через PayPal.me должны быть активированы вручную.',
	"donations_f_paypal_currency" => 'Валюта',
	"donations_fs_texts" => 'Информационный текст',
	"donations_f_donation" => 'Описание на странице пожертвований',
	"donations_f_thankyou" => 'Уведомление о подтверждении после успешного пожертвования',
	"donations_f_cancel" => 'Предупреждение о том, пожертвование прервалось',
	"donations_f_goal_start" => 'Начало кампании по сбору пожертвований',
	"donations_f_help_goal_start" => 'Будет использована для расчета покрываемых месяцев',
	"donations_menu" => 'Пожертвования',
	"donation_success_message" => 'Большое спасибо за ваше пожертвование! Оно будет видно здесь, как только будет проверено.',
	"donation_cancel_message" => 'Жаль, что вы отменили свое пожертвование.',
	"donations_donate_button" => 'Пожертвовать сейчас',
	"plugin_statistics_donations" => 'Пожертвования',
	"donations_covered_months_text" => 'Покрытых месяцев - %d',
	"donations_month" => 'Месяц',
	"donations_months" => 'Месяцы',
	"donations_amount" => 'Значение',
	"donations_via_paypal" => 'Пожертвование через PayPal',
	"donations_recent_goal" => 'Недавняя цель для пожертвований',
	"donations_public" => 'Публичное пожертвование',
	"donations_wallofdonators" => 'Недавние пожертвования',
	"donations_hide_name" => 'Скрыть имя',
	"donations_manage" => 'Управление пожертвованиями',
	"donations_add" => 'Добавить пожертвование/платёж',
	"donations_confirm_delete_donation" => 'Вы уверены, что хотите удалить эти пожертвования %s?',
	"donation_incomplete_suc" => 'Это пожертвование было успешно отключено.',
	"donation_complete_suc" => 'Это пожертвование было успешно включено.',
	"donation_complete_selected" => 'Включить выбранные',
	"donation_provider" => 'Метод оплаты',
	"donations_method_manual" => 'Вручную',
	"donations_ntfy_new_donation" => '{PRIMARY} пожертвовал \'{ADDITIONAL}\'',
	"donations_ntfy_new_donation_grouped" => 'Новых пожертвований - {COUNT}',
	"user_sett_f_ntfy_donations_new_donation" => 'Новое пожертвование',
	"user_sett_f_ntfy_donations" => 'Пожертвования',
	"donations_donations" => 'Пожертвования',
	"donations_f_show_button" => 'Показать кнопку для пожертвований',
	"donations_f_show_progress" => 'Показать прогресс для пожертвований',
	"donations_f_text" => 'Текст пожертвования',
	"donations_months_short" => 'мес.',
	"donations_f_show_count" => 'Число последних пожертвований',
	"donations_f_text_latest" => 'Текст описания (необязательно)',
	"latestdonations" => 'Последние пожертвования',
	"user_sett_fs_notifications_donations" => 'Пожертвования',
	
);

?>