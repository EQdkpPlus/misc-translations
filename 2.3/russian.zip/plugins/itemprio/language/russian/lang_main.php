<?php
/*	Project:	EQdkp-Plus
 *	Package:	EQdkp-Plus Language File
 *	Link:		http://eqdkp-plus.eu
 *
 *	Copyright (C) 2006-2015 EQdkp-Plus Developer Team
 *
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU Affero General Public License as published
 *	by the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU Affero General Public License for more details.
 *
 *	You should have received a copy of the GNU Affero General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 
if (!defined('EQDKP_INC')) {
	die('You cannot access this file directly.');
}

//Language: Russian	
//Created by EQdkp Plus Translation Tool on  2020-12-05 07:47
//File: plugins/itemprio/language/russian/lang_main.php
//Source-Language: english

$lang = array( 
	"itemprio" => 'Список приоритета предметов',
	"itemprio_short_desc" => 'Список приоритета предметов',
	"itemprio_long_desc" => 'Персонажи могут добавлять приоритет нужных предметов',
	"ip_itemprios" => 'Список приоритета предметов',
	"ip_myitemprios" => 'Мои списки приоритета предметов',
	"ip_config_saved" => 'Настройки были успешно сохранены.',
	"ip_fs_general" => 'Общее',
	"ip_fs_items" => 'Предметы',
	"ip_f_item_count" => 'Число предметов за событие',
	"ip_f_item_new_allgone" => 'Новые предметы могут быть добавлены, когда все предметы из списка будут назначены.',
	"ip_f_events" => 'Выбранные события',
	"ip_f_twinks" => 'Список предметов для твинков',
	"ip_view" => 'Вид',
	"ip_use" => 'Создать списки приоритета',
	"ip_change_items" => 'Изменить предметы в списке',
	"ip_change_order" => 'Изменить приоритет предметов',
	"ip_distribute" => 'Распределить предметы',
	"ip_plugin_not_installed" => 'Этот плагин не установлен.',
	"ip_itemname" => 'Название предмета',
	"ip_itemid" => 'Игровой ID предмета',
	"ip_searchitem" => 'Искать предмет',
	"ip_hint_allgone" => 'Вы не можете добавлять новые предметы, пока не получите все предметы из списка приоритета.',
	"ip_dragndrop" => 'Удерживайте и переместите на нужную позицию',
	"ip_given_success" => 'Предмет \'%1$s\' был отдан %2$s.',
	"ip_notify_new_item" => 'Вы получили предмет \'{PRIMARY}\' из вашего списка приоритета.',
	"ip_notify_new_item_grouped" => 'Вы получили {COUNT} из ваших списков приоритета.',
	"ip_throw" => 'Случайно отдать предмет',
	"ip_give" => 'Отдать предмет',
	"ip_f_item_new_allrequired" => 'Требуются все предметы за событие',
	"ip_additional_buyers" => 'Другие заинтересованные персонажи',
	"ip_f_show_additional_buyers" => 'Показать всех заинтересованных в этом предмете персонажей',
	"ip_no_chars" => 'Вы должны создать персонажа, чтобы добавить предметы для вашего персонажа в список приоритета.',
	"user_sett_fs_notifications_itemprio" => 'Список приоритета предметов',
	"user_sett_f_ntfy_itemprio_new_item" => 'Предмет получен',
	
);

?>